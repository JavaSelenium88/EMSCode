/*
 *  Copyright 2017, PTC, Inc.
 *
 *  This software is distributed under a license. The full license
 *  agreement can be found in the file LICENSE in this distribution.
 *  This software may not be copied, modified, sold or distributed
 *  other than expressed in the named license agreement.
 *
 *  This software is distributed without any warranty.
 *
 *  Version header file.
 */

#ifndef C_SDK_VERSION
#define C_SDK_VERSION "2.1.2"
#endif