The ./src/stubs directory contains code for mocking out API calls during the unit testing
process and is required to compile but provides no new features or capabilities in the released
product.