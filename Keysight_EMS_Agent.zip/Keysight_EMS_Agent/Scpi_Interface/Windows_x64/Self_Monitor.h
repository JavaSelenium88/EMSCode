#ifndef __SELFMONITOR_H
#define __SELFMONITOR_H

#define EMS_AGENT_VERSION "01.03.02"

#ifdef _WIN32
#if WINVER > 0x0602 // WIN 7
#define EMS_AGENT_PLATFORM "S."
#else // WIN XP
#define EMS_AGENT_PLATFORM "X."
#endif
#else // Linux
#ifdef PLUM_OS
#define EMS_AGENT_PLATFORM "P."
#else
#define EMS_AGENT_PLATFORM "L."
#endif
#endif

enum SelfMonitorErrorCode
{
	ERR_SELF_MONITOR_OK = 0,
	ERR_SELF_MONITOR_NO_DATA,
	ERR_SELF_MONITOR_CANNOT_CREATE_FILE_MAPPING,
	ERR_SELF_MONITOR_REACH_MAX_BUFFER_SIZE,
	ERR_SELF_MONITOR_CANNOT_GET_HANDLE,
    ERR_SELF_MONITOR_INIT_SENSOR_ERROR,
	ERR_SELF_MONITOR_GET_NETWORK_ERROR
};

#ifdef __cplusplus
#include <string>
#include <thread>
#include <mutex>
#include "../../AssetDataWrapper/AssetDataPayloadGen/AssetDataWrapper.h"
#include "../../AssetDataWrapper/AssetDataPayloadGen/FactType_Health.h"
#include "../../AssetDataWrapper/AssetDataPayloadGen/FactType_Info.h"
#include "../../AssetDataWrapper/AssetDataPayloadGen/FactType_Environment.h"
#include "../../AssetDataWrapper/AssetDataPayloadGen/FactType_Utilization.h"

	using namespace std;
	using namespace AssetDataWrapper;


	class SelfMonitor
	{
	public:
		SelfMonitor();
		~SelfMonitor();

		void InitSensors();

        void SetConfig(	string com_addr,
						double volt_ref,
						int util_flag,
						unsigned long health_interval,
						unsigned long env_interval,
						unsigned long util_interval,
						unsigned long info_interval,
						double cur_util_threshold,
						double cur_margin
					);

		void SetKeyboardTimeStamp(string kb_timeStamp);
		void SetMouseTimeStamp(string ms_timeStamp);

		SelfMonitorErrorCode GetEnvironmentData(unsigned char** output, int* buffSize);
		SelfMonitorErrorCode GetHealthData(unsigned char** output, int* buffSize);
		SelfMonitorErrorCode GetInformationData(unsigned char** output, int* buffSize);
		SelfMonitorErrorCode GetUtilizationData(unsigned char** output, int* buffSize);

		void RunEventHook(); // Use thread to run this method to listen to the hook and event
		void RunGpibEvent(); // Usethread to run this for plum gpib
		void RunAppUtilization(string appName); // Use thread to run this method to monitor app utilization
		void RunAppRemoteUtilization(); // Monitor Remote Activity

	private:

		// Keyboard Mouse Event Hook
		bool eventHookIsInstalled;
		bool appUtilizationIsInstalled;
		bool appRemoteUtilizationIsInstalled;
		bool isUtilized_plum;

		string heal_last_query_time;
		string util_last_query_time;
		string info_last_query_time;
		string env_last_query_time;
		string utilizationTimeStamp_plum;
		string utilizationTimeStamp_plum_gpib;
		string env_plum_accel_timestamp;
		string env_plum_accel_x_val;
		string env_plum_accel_y_val;
		string env_plum_accel_z_val;
		string mPlumFwVersion;
		unsigned int mPlumGpibAddress;
		double mPlumVoltRef;
		int mPlumUtilFlag; // 0: all, 1: gpib_only 2: poisson algo
		double mPlumCurrentThreshold;
		double mPlumCurrentMargin;
		unsigned int mPlumAdxlInterval;
		unsigned int mPlumAdxlThreshold;
		unsigned int mPlumAdxlCutoff;
		unsigned long mHealthInterval;
		unsigned long mEnvInterval;
		unsigned long mUtilInterval;
		unsigned long mInfoInterval;
		unsigned int mPlumBootupFlag;
		unsigned int mWindowsBootupFlag;
		mutex mMutex;

#ifdef _WIN32
		HHOOK hhook_Keyboard;
		HHOOK hhook_Mouse;
#endif /**_WIN32**/

		SelfMonitorErrorCode InstallEventHook();
		SelfMonitorErrorCode RemoveEventHook();

		SelfMonitorErrorCode InstallAppUtilization();
		SelfMonitorErrorCode RemoveAppUtilization();
		SelfMonitorErrorCode LoopAppUtilizationDetection(string appName);

		SelfMonitorErrorCode InstallAppRemoteUtilization();
		SelfMonitorErrorCode RemoveAppRemoteUtilization();
		SelfMonitorErrorCode LoopAppRemoteUtilizationDetection();

		SelfMonitorErrorCode RunPlumUtilizationThread();
		SelfMonitorErrorCode RunPlumGpibUtilizationThread();
		SelfMonitorErrorCode GetUtilizationDataForPlum(vector<UtilizationStruct>* myUtilVector);
		SelfMonitorErrorCode GetEnvironmentDataForPlum(vector<EnvironmentStruct>* myEnvVector);
		SelfMonitorErrorCode GetInforamtionDataForPlum(vector<InformationStruct>* myInfoVector);
		SelfMonitorErrorCode GetHealthDataForPlum(vector<HealthStruct>* myHealthVector);

		SelfMonitorErrorCode GetLocalHostInformation(vector<InformationStruct>* myInfoVector);
		SelfMonitorErrorCode GetLocalHostNetworkInfo(vector<string> *interface_ip, vector<string> *interface_name, vector<string> *interface_mac);
		SelfMonitorErrorCode GetSysUpUsage(vector<HealthStruct>* myHealthVector);
	};

#endif

//******************************* C Define ********************************//
#ifdef __cplusplus
	extern "C" {
#endif
		struct selfMonitor;

		struct selfMonitor* selfMonitor_Create();
		void selfMonitor_SetConfig(	struct selfMonitor* myMonitor,
									char* com_addr,
									double volt_ref,
									int util_flag,
									unsigned long health_interval,
									unsigned long env_interval,
									unsigned long util_interval,
									unsigned long info_interval,
									double cur_util_threshold,
									double cur_margin
								);
		void selfMonitor_InitSensors(struct selfMonitor* myMonitor);
		void selfMonitor_SetMisc(struct selfMonitor* myMonitor, const char *kb_timeStamp, const char *ms_timeStamp);

		void selfMonitor_Destroy(struct selfMonitor* myMonitor);
		void selfMonitor_RunEventHook(struct selfMonitor* myMonitor);
		void selfMonitor_RunAppUtilization(struct selfMonitor* myMonitor, const char* appName);
		void selfMonitor_RunAppRemoteUtilization(struct selfMonitor* myMonitor);

		enum SelfMonitorErrorCode selfMonitor_GetEnvironmentData(struct selfMonitor* myMonitor, unsigned char** output, int* buffSize);
		enum SelfMonitorErrorCode selfMonitor_GetHealthData(struct selfMonitor* myMonitor, unsigned char** output, int* buffSize);
		enum SelfMonitorErrorCode selfMonitor_GetUtilizationData(struct selfMonitor* myMonitor, unsigned char** output, int* buffSize);
		enum SelfMonitorErrorCode selfMonitor_GetInformationData(struct selfMonitor* myMonitor, unsigned char** output, int* buffSize);

		void combineCharArraysWithHeader(	unsigned char* headerStr,
											unsigned char* osStr,
											int osBufSize,
											unsigned char* scpiStr,
											int scpiBufSize,
											unsigned char** output,
											int* retTotalSize);
#ifdef __cplusplus
	}
#endif

#endif
