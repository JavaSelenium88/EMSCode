#ifndef SCPI_CLIENT_C_H
#define SCPI_CLIENT_C_H

#define SCPI_CLENT_MSG_HEADER "<SCPI_CLIENT>"

enum ComType
{
	Com_Socket = 0,
	Com_GPIB
};

enum ScpiClientErrorCode
{
	ERR_OK = 0,
	ERR_NO_CONNECTION,
	ERR_SOCKET_ERROR,
	ERR_NO_DATA,
	ERR_REACH_MAX_BUFFER_SIZE
};

#ifdef __cplusplus
extern "C" {
#endif
	struct scpi_Client;

	struct scpi_Client* scpi_Client_Create(enum ComType comType);
	void scpi_Client_Destroy(struct scpi_Client* myClient);

	int scpi_Client_Connect(struct scpi_Client* myClient);
	int scpi_Client_Disconnect(struct scpi_Client* myClient);

	int scpi_Client_SetCom(struct scpi_Client* myClient, enum ComType comType);
	int scpi_Client_SetConfig(struct scpi_Client* myClient, char* port, char* ipAddress);

	int scpi_Client_GetSerialNumber(struct scpi_Client* myClient, char** output, int* retBufSize);
	int scpi_Client_GetEnvironmentData(struct scpi_Client* myClient, char** output, int* retBufSize);
	int scpi_Client_GetHealthData(struct scpi_Client* myClient, char** output, int* retBufSize);
	int scpi_Client_GetInformationData(struct scpi_Client* myClient, char** output, int* retBufSize);
	int scpi_Client_GetUtilizationData(struct scpi_Client* myClient, char** output, int* retBufSize);

#ifdef __cplusplus
}
#endif

#endif