--> Steps to be followed to enable SCPI dynamic payloads <--

NOTE: The following changes will only work in Visual Studio 2015 with x64 and x86 Project.

1. Make the following three additions in Keysight_EMS_Agent project Property Pages
	A. Under C/C++ -> General tab add the location of the folder containing the SCPI header files in Additional Include Directories.
	   It should be like ..\..\Scpi_Interface\Windows_x64\ for x64 project or ..\..\Scpi_Interface\Windows_x86\ for x86 project.
	B. Under C/C++ -> Preprocessor tab add SCPI_ENABLE under Preprocessor Definitions.
	C. Under Linker -> Input tab add location of two new libraries needed for SCPI. This needs to be added in Additional Dependencies.
	   The new libraries are:
		I. ..\..\Scpi_Interface\Windows_x64\Scpi_Client.lib for x64 project or ..\..\Scpi_Interface\Windows_x86\Scpi_Client.lib for x86 project.
		II. ..\..\Scpi_Interface\Windows_x64\Self_Monitor.lib for x64 project or ..\..\Scpi_Interface\Windows_x86\Self_Monitor.lib for x86 project.

2. Go to the location <Project base>\Keysight_EMS_Agent\Scpi_Interface\Emulator\. Run InstrumentEmulator.exe
3. The exe will run providing list of options, Select the option 3 which is for the localhost Connection.
4. THe exe will provide multiple port number for the localhost connection. Select any one port number 
& add that in Config.json under "asset_com_port".
5. Run our application with InstrumentEmulator.exe already running to get the Scpi payload.