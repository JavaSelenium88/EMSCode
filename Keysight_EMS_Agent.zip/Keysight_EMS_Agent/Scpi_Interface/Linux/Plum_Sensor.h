#ifndef __PLUM_SENSOR_H
#define __PLUM_SENOSR_H

#define PLUM_SENSOR_BUFFER_SIZE 128
#define ADXL_ARRAY_SIZE         50000
#define ADXL_TIMESTAMP_BUF_SIZE 128
#define PLUM_GPIB_ADDRESS_MAX_SIZE 1000

void Sensor_Init_Once(const unsigned int adxl_time_interval, const unsigned int adxl_threshold, const unsigned int adxl_cutoff);

void Sensor_Destroy_Once();

void Sensor_Set_Gpib_Addr(const unsigned int gpib_addr);

// no use
void Sensor_Set_Adxl_Threshold(const unsigned int adxl_threshold, const unsigned int adxl_cutoff);

void Sensor_Set_Adxl_Fullscale(const unsigned int adxl_fullscale);

void Sensor_Read_Serial_Number(char *serial_number, const unsigned int char_size);

void Sensor_Read_Voltage(int *ac_voltage);

void Sensor_Read_Current(float *ac_current);

void Sensor_Read_Temperature_Humidity(float *temp, double *humidity);

void Sensor_Read_Ip_Address(char *ip_address, const unsigned int char_size, const char *interface);

void Sensor_Read_Adxl_Event(int *x_values,
                            int *y_values,
                            int *z_values,
                            char timestamps[][PLUM_SENSOR_BUFFER_SIZE],
                            const unsigned int size_timestamp,
                            const unsigned int array_size,
                            unsigned int *num_event,
                            unsigned int *num_samples);

void Sensor_Read_Hw_Version(char *hw_version, const unsigned int char_size);

void Sensor_Read_Line_Freq(float *line_freq);

// no use
void Sensor_Clear_Adxl_Event_Count();

void Sensor_Read_Gpib_Event(char *last_used_timestamp, const unsigned int char_size);

void Sensor_Read_Gpib_Activity(char *gpib_address_list, const unsigned int char_size, int *address_cnt);

#endif // __PLUM_SENSOR_H
