/*****************************************************************************
//  Copyright � 2016 ITC .  All rights reserved.
//
******************************************************************************
//
//  Filename   : Native_Agent.c
//
//  Subsystem  : KeySight
//
//  Author     : Soumya Ranjan Bej
//
//  Description: Defines the entry point for the console application.
//
******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

#include "cJSON.h"
#include  "OS_Utilities.h"
#include "Systypes.h"
#include "Sysapi.h"
#include "SysLog.h"
#include "SysEvent.h"
#include "Native_Agent.h"
#include "Native_Agent_Utils.h"


#ifdef KEYHOOK_PROC /*Enable this flag to get the Keyboard and Mouse Hook from Keysight_EMSHelper Application.*/
	//************************************************************************
	//					SOCKET Variables
#include <ws2tcpip.h>
	WSADATA wsaData;
	SOCKET ConnectSocket = INVALID_SOCKET;

#define DEFAULT_BUFLEN 512

	/**********************************************************************/
#endif /*KEYHOOK_PROC*/

#ifndef _WIN32
#define strtok_s strtok_r
#endif /*_WIN32 */
Sys_Char *pszSCPIUtils = NULL;
Sys_Char *pszSCPIHealth = NULL;
Sys_Char *pszSCPIENV = NULL;
Sys_Char *pszSCPIInfo = NULL;

static Sys_Bool SCPIStatus = SYS_TRUE;

// to turn ON/OFF SCPI Interface. OFF to use default payload
//#define SCPI_ENABLE //Define it in Project setting.
//#define DEBUG_WITHOUT_HOOK //Define it in Project setting.
//TODO: Abhishek Need to validate the use of this #pragma
#pragma region Fixed_Payload
NativeErrCodes   ReadDevicePropertyFile(Sys_Char *pszFileName, Sys_Char **pszBufWS)
{
	Sys_Char *function = "ReadDevicePropertyFile";
	Sys_Char *pszFilePath = NULL;
	NativeErrCodes retVal = NATIVE_SUCCESS;

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: entered.", function);

	pszFilePath = GetFilePathByName(PAYLOAD_FOLDER_NAME, pszFileName);
	if (pszFilePath == NULL) {
		retVal = NATIVE_WRONG_IP_PARAMS;
	}

	*pszBufWS = ReadFileContent(pszFilePath);
	if (pszBufWS == NULL) {
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Insufficient Memory!", function);
	}

	if (pszFilePath) {
		Sys_Free(pszFilePath);
		pszFilePath = NULL;
	}

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: exited.", function);

	return retVal;
}

#pragma endregion Fixed_Payload

#ifdef WIN32
#ifndef WINXP
//************************************************************************
//					SOCKET 
#include <ws2tcpip.h>
WSADATA wsaData;
//SOCKET ConnectSocket = INVALID_SOCKET;
struct addrinfo *result = NULL, *ptr = NULL, hints;
Sys_Int iResult;
#define DEFAULT_PORT "27015"
#define DEFAULT_BUFLEN 512
Sys_Char recvbuf[DEFAULT_BUFLEN] = "\0";

#pragma comment(lib, "user32.lib")
#pragma comment (lib, "Ws2_32.lib")   // Need to link with Ws2_32.lib, Mswsock.lib, and Advapi32.lib
#pragma comment (lib, "Mswsock.lib")
#pragma comment (lib, "AdvApi32.lib")

/**********************************************************************/
#endif
#endif

#ifdef KEYHOOK_PROC /*Enable this flag to get the Keyboard and Mouse Hook from Keysight_EMSHelper Application.*/
NativeErrCodes KeyMouseHook(Sys_Char *recvBuf) {

	Sys_Char *function = "KeyMouseHook";
	Sys_Int iResult = 0;
	Sys_Char sendAck[1];
	sendAck[0] = 'y';
	Sys_Int retry = 1;
	Sys_Int returnValue = NATIVE_SUCCESS;

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Entered.", function);

	if (ConnectSocket == INVALID_SOCKET) {
		SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Socket could not be conneted.", function);
		SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Trying to re-connect with Keysight_EMSHelper count = %d", function, retry);
		iResult = Socket_Init();

		while (retry<3 && iResult != 0) {
			retry++;
			Sleep(3000);
			SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Trying to re-connect with Keysight_EMSHelper count = %d", function, retry);
			iResult = Socket_Init();
		}
		if (!iResult)
			SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Socket Connected with Keysight_EMSHelper.", function);
	}

	if (ConnectSocket != INVALID_SOCKET) {

		iResult = send(ConnectSocket, sendAck, sizeof(sendAck), 0);
		if (iResult == SOCKET_ERROR) {
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Request failed for timestamp to Keysight_EMSHelper with error:%ld", function, WSAGetLastError());
			iResult = Socket_UnInit();
			if (iResult)
				SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Socket_UnInit failed.", function);
			returnValue = NATIVE_KEYHOOK_SOCKET_ERROR;
		}
		else
			SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Request has been sent for last input event to Keysight_EMSHelper.", function);

		if (ConnectSocket != INVALID_SOCKET) {

			iResult = recv(ConnectSocket,recvBuf, DEFAULT_BUFLEN, 0);
			if (iResult > 0) {
				SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Last Input timestamp received from Keysight_EMSHelper.", function);
			}
			else if (iResult == 0) {
				SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Socket Connection closed.", function);
				iResult = Socket_UnInit();
				if (iResult)
					SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Socket_UnInit failed.", function);
				returnValue = NATIVE_KEYHOOK_SOCKET_ERROR;
			}
			else {
				SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Recv failed with error:%ld", function, WSAGetLastError());
				returnValue = NATIVE_KEYHOOK_SOCKET_ERROR;
			}
		}
	}

	if (ConnectSocket == INVALID_SOCKET) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Keysight_EMSHelper server socket not reachable.", function);
		returnValue = NATIVE_KEYHOOK_SOCKET_ERROR;
	}

	SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Exited.", function);
	return returnValue;

}
#endif

#ifdef KEYHOOK_PROC /*Enable this flag to get the Keyboard and Mouse Hook from Keysight_EMSHelper Application.*/
NativeErrCodes Socket_Init(void) {

	Sys_Char *port = "27015";
	Sys_Char *function = "Socket_Init";
	Sys_Int iResult = 0, iResult_Connect =0;
	Sys_Int retValSockInit = NATIVE_SUCCESS;
	Sys_Int reTrySockConn = 2;
	struct addrinfo *result = NULL, *ptr = NULL, hints;
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Entered.", function);

	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);						// Initialize Winsock
	if (iResult != NATIVE_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: WSAStartup failed with Error :  %ld", function, WSAGetLastError());
		retValSockInit = NATIVE_KEYHOOK_SOCKET_ERROR;
	}

	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_UNSPEC;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	if (iResult == NATIVE_SUCCESS) {
		iResult = getaddrinfo("LOCALHOST", port, &hints, &result);				// Resolve the server address and port
		if (iResult != NATIVE_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Getaddrinfo failed with Error : %ld", function, WSAGetLastError());
			WSACleanup();
			retValSockInit = NATIVE_KEYHOOK_SOCKET_ERROR;
		}
	}

	if (iResult == NATIVE_SUCCESS) {
		ptr = result;
		while (reTrySockConn > 0 && ConnectSocket == INVALID_SOCKET) {
			reTrySockConn--;									// Create a SOCKET for connecting to server
			ConnectSocket = socket(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol);
			if (ConnectSocket == INVALID_SOCKET) {
				SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Socket could not be created,failed with Error : %ld", function, WSAGetLastError());
				WSACleanup();
				retValSockInit = NATIVE_KEYHOOK_SOCKET_ERROR;
			}
			else {

				iResult = connect(ConnectSocket, ptr->ai_addr, (Sys_Int)ptr->ai_addrlen);
				if (iResult == SOCKET_ERROR) {
					iResult_Connect = (Sys_Int)WSAGetLastError();
					iResult = closesocket(ConnectSocket);
					if(iResult != NATIVE_SUCCESS)
						SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Closesocket failed with error : %ld", function, WSAGetLastError());
					ConnectSocket = INVALID_SOCKET;//assign initial vallue as recv() fail
				}
				
			}
		}
		ptr = ptr->ai_next;
	}

	freeaddrinfo(result);

	if (ConnectSocket == INVALID_SOCKET) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Socket connection failed with error: %d", function, iResult_Connect);
		retValSockInit = NATIVE_KEYHOOK_SOCKET_ERROR;
	}

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Exited.", function);
	return retValSockInit;
}
#endif


#ifdef KEYHOOK_PROC /*Enable this flag to get the Keyboard and Mouse Hook from Keysight_EMSHelper Application.*/
NativeErrCodes Socket_UnInit(void) {

	Sys_Int iResult = 1;
	Sys_Int reTry = 2;
	Sys_Int retValSockUnInit = NATIVE_SUCCESS;
	Sys_Char *function = "Socket_UnInit";
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Entered.", function);

	while (reTry && iResult) {

		reTry--;
		iResult = closesocket(ConnectSocket);
		if (!iResult) {
			reTry = 0;
			SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Client socket closed for Keysight_EMSHelper.", function);
			retValSockUnInit = NATIVE_SUCCESS;
		}
		else
		{
			SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Closesocket failed with error : %ld", function, WSAGetLastError());
			Sleep(1000);                       //retry 2nd time for clode
			retValSockUnInit = NATIVE_KEYHOOK_SOCKET_ERROR;

		}
	}

	iResult = WSACleanup();
	if(iResult != NATIVE_SUCCESS) {
		SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Winsock 2 dll(WS_32.dll) could not be freed.", function);
		retValSockUnInit = NATIVE_KEYHOOK_SOCKET_ERROR;
	}
	//else
		//SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Winsock 2 dll(WS_32.dll) freed", function);

	ConnectSocket = INVALID_SOCKET;
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Exited.", function);

	return retValSockUnInit;
}
#endif

NativeErrCodes NatAgent_Init(
	void **ppHdl
)
{
	NativeErrCodes retVal = NATIVE_SUCCESS;
	NativeErrCodes retValSock = NATIVE_SUCCESS;
	pnatAgentHdle pNatHdl = NULL;
	Sys_Char *function = "NatAgent_Init";
	Sys_Int idx1 = 0;
	ConfigErrCodes confRetVal = CONFIG_SUCCESS;
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: entered.", function);


#ifdef KEYHOOK_PROC /*Enable this flag to get the Keyboard and Mouse Hook from Keysight_EMSHelper Application.*/
if (keyHookHelper) {
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Keysight_EMSHelper Functionality is enabled", function);
		retValSock = Socket_Init();
		if (!retValSock)
			SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Socket_Init success for Keysight_EMSHelper.", function);
		else
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Error in socket initilization for Keysight_EMSHelper.", function);
}
else
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Keysight_EMSHelper Functionality is disabled", function);
#endif

	if (*ppHdl == NULL) {
		pNatHdl = (pnatAgentHdle)Sys_Malloc(sizeof(natAgentHdle));
		if (pNatHdl == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Insufficient Memory!", function);
			goto failCall;
		}

		pgNatConf = NULL;
		confRetVal = GetConfigData(&pgNatConf);
		if (confRetVal != CONFIG_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: GetConfigData() failed!", function);
			goto failCall;
		}

		pNatHdl->pPrmHlth = NULL;
		pNatHdl->pPrmEnv = NULL;
		pNatHdl->pPrmUtiSCPI = NULL;
		pNatHdl->pPrmUtiOS = NULL;
#ifdef KEYBOARD_MOUSE_HOOK  /* Enable this flag to use the Keyboard & mouse hook thread struct i.e natAgentThrd_T */
		pNatThrdHdl = NULL;
		pNatThrdHdl = (pnatAgentThrd)Sys_Malloc(sizeof(natAgentThrd));
		if (pNatThrdHdl == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pNatThrdHdl-Insufficient Memory!", function);
			goto failCall;
		}

		pNatThrdHdl->pMutHdl = NULL;
		pNatThrdHdl->pMutHdl = SysMutex_Create();
		if (pNatThrdHdl->pMutHdl == NULL) {
			retVal = NATIVE_SYSTEM_ERROR;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Mutex create failed!", function);
			goto failCall;
		}

		pNatThrdHdl->pPrmUtiOS = NULL;
		pNatThrdHdl->pPrmUtiOS = (pParam_Utilization_OS)Sys_Malloc(sizeof(Param_Utilization_OS));
		if (pNatThrdHdl->pPrmUtiOS == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pNatThrdHdl->pPrmUtiOS-Insufficient Memory!", function);
			goto failCall;
		}
		/** Populating data for Utilization OS data */ //TODO: Vishal: Why only for Utilization? Ideally should be for all category.
		SysMutex_Lock(pgNatConf->mutexHdl);
		pNatThrdHdl->pPrmUtiOS->uAstDet.pId = NULL;
		idx1 = (Sys_Int)strlen(pgNatConf->m_Asset.pId);
		pNatThrdHdl->pPrmUtiOS->uAstDet.pId = (Sys_Char *)Sys_Malloc(idx1 + 1);
		if (pNatThrdHdl->pPrmUtiOS->uAstDet.pId == NULL) {
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Failed to allocate memory for Asset ID!", function);
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			goto failCall;
		}
		else {
			Sys_StringnCpy(pNatThrdHdl->pPrmUtiOS->uAstDet.pId, pgNatConf->m_Asset.pId, idx1, idx1 + 1);
		}

		pNatThrdHdl->pPrmUtiOS->uAstDet.Type = pgNatConf->m_Asset.Type;
		SysMutex_Unlock(pgNatConf->mutexHdl);
#ifdef WIN32
		pNatThrdHdl->pPrmUtiOS->uPrmSrc = OS_INT;
		pNatThrdHdl->pPrmUtiOS->puKeybrd = (Sys_Char *)Sys_Malloc(sizeof(Sys_Char) * TIMESTMAMP_LENGTH);
		if (pNatThrdHdl->pPrmUtiOS->puKeybrd == NULL) {
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Failed to allocate memory for KEYBOARD!", function);
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			goto failCall;
		}
		pNatThrdHdl->pPrmUtiOS->puMouse = (Sys_Char *)Sys_Malloc(sizeof(Sys_Char) * TIMESTMAMP_LENGTH);
		if (pNatThrdHdl->pPrmUtiOS->puMouse == NULL) {
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Failed to allocate memory for MOUSE!", function);
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			goto failCall;
		}

		pNatThrdHdl->pThrdStrct = NULL;
		pNatThrdHdl->pThrdStrct = SysCreateThreadStruct();
		if (pNatThrdHdl->pThrdStrct == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pNatThrdHdl->pThrdStrct-Create Thread failed!", function);
			goto failCall;
		}
#ifndef WINCE
		SysStartThread(pNatThrdHdl->pThrdStrct, NatAgent_CreateKMhook); //TODO: Vishal: Retrun value??  //Shantanu Added
#endif
#endif /*WIN32 */
#endif /* KEYBOARD_MOUSE_HOOK */

																		//Added Sept_19
#ifdef SCPI_ENABLE
		char ems_version[512] = { 0 };
		snprintf(ems_version, 512, "\n\n***********************************\n");
		snprintf(ems_version + strlen(ems_version), 512, "*                                 *\n");
		snprintf(ems_version + strlen(ems_version), 512, "*     EMS Version: %s%s     *\n", EMS_AGENT_PLATFORM, EMS_AGENT_VERSION);
		snprintf(ems_version + strlen(ems_version), 512, "*                                 *\n");
		snprintf(ems_version + strlen(ems_version), 512, "***********************************\n\n");
		SysAppLog(SYS_INFO, MODULE_NATIVE_AGENT, "%s", ems_version);

		// CWU SCPI_INTERFACE
		int util_flag = 0; // enable all utilization
		double current_threshold = -999;
		double current_margin = -999;
		if (pgNatConf->m_Asset.misc != NULL) {
			char *pch, *saved;
			char *misc_cpy = malloc(strlen(pgNatConf->m_Asset.misc) + 1);
			strcpy(misc_cpy, pgNatConf->m_Asset.misc);
			//pch = strtok_r(misc_cpy, ";");
			pch = strtok_s(misc_cpy, ";", &saved);
			while (pch != NULL)
			{
				char *misc_pair, *saved_pair;
				misc_pair = strtok_s(pch, "=", &saved_pair);
				while (misc_pair != NULL) {
					// find key
					if (strcmp(misc_pair, "util_flag") == 0) {
						misc_pair = strtok_s(NULL, "=", &saved_pair);
						if (misc_pair != NULL) {
							// get value
							util_flag = atoi(misc_pair);
						}
					}
					if (strcmp(misc_pair, "cur_threshold") == 0) {
						misc_pair = strtok_s(NULL, "=", &saved_pair);
						if (misc_pair != NULL) {
							// get value
							current_threshold = atof(misc_pair);
						}
					}
					if (strcmp(misc_pair, "cur_margin") == 0) {
						misc_pair = strtok_s(NULL, "=", &saved_pair);
						if (misc_pair != NULL) {
							// get value
							current_margin = atof(misc_pair);
						}
					}
					misc_pair = strtok_s(NULL, "=", &saved_pair);
				}
				pch = strtok_s(NULL, ";", &saved);
			}
			free(misc_cpy);
		}

		// ==================================================
		// Sequence: create -> setConfig -> InitSensors
		// ==================================================
			myMonitor = selfMonitor_Create();
			selfMonitor_SetConfig(myMonitor,
			pgNatConf->m_Asset.comAddr,
			pgNatConf->m_Asset.refVolt,
			util_flag,
			pgNatConf->acquisition.health,
			pgNatConf->acquisition.environment,
			pgNatConf->acquisition.utilization,
			pgNatConf->acquisition.information,
			current_threshold,
			current_margin);
		selfMonitor_InitSensors(myMonitor);
		//selfMonitor_RunAppUtilization(myMonitor, pgNatConf->m_Asset.appName);
		selfMonitor_RunAppRemoteUtilization(myMonitor);
#ifndef DEBUG_WITHOUT_HOOK
		selfMonitor_RunEventHook(myMonitor); // this will init a thread and run Keyboard/Mount hook.
#endif

#ifdef _WIN32
		myClient = scpi_Client_Create(strstr(pgNatConf->m_Asset.comType, "socket") ? Com_Socket : Com_GPIB);
		scpi_Client_SetConfig(myClient, pgNatConf->m_Asset.comPort, pgNatConf->m_Asset.comAddr);
		retValSCPI = scpi_Client_Connect(myClient);
		if (retValSCPI != ERR_OK)
		{
			scpi_Client_Disconnect(myClient);
			SCPIStatus = SYS_FALSE;
		}
		else
		{
			SCPIStatus = SYS_TRUE;
		}
#endif /**_WIN32**/

#else
		ReadDevicePropertyFile(STR_FILE_UTILS_JSON, &pszSCPIUtils);
		if (pszSCPIUtils == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Insufficient Memory!", function);
			goto failCall;
		}

		ReadDevicePropertyFile(STR_FILE_HEALTH_JSON, &pszSCPIHealth);
		if (pszSCPIHealth == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Insufficient Memory!", function);
			goto failCall;
		}

		ReadDevicePropertyFile(STR_FILE_ENV_JSON, &pszSCPIENV);
		if (pszSCPIENV == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Insufficient Memory!", function);
			goto failCall;
		}

		ReadDevicePropertyFile(STR_FILE_INFO_JSON, &pszSCPIInfo);
		if (pszSCPIInfo == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Insufficient Memory!", function);
			goto failCall;
		}
#endif //End Sept_19
	}
	else {
		retVal = NATIVE_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Wrong IP pHdl passed!", function);
		goto failCall;
	}

	*ppHdl = pNatHdl;

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: exited.", function);
	return retVal;

failCall:
	if (pNatHdl) {
		Sys_Free(pNatHdl);
		pNatHdl = NULL;
	}

	if (pszSCPIUtils) {
		Sys_Free(pszSCPIUtils);
		pszSCPIUtils = NULL;
	}

	if (pszSCPIHealth) {
		Sys_Free(pszSCPIHealth);
		pszSCPIHealth = NULL;
	}

	if (pszSCPIENV) {
		Sys_Free(pszSCPIENV);
		pszSCPIENV = NULL;
	}

	if (pszSCPIInfo) {
		Sys_Free(pszSCPIInfo);
		pszSCPIInfo = NULL;
	}

#ifdef WIN32
#ifndef WINCE
#ifdef KEYBOARD_MOUSE_HOOK	 /* Enable this flag to use the Keyboard & mouse hook thread struct i.e natAgentThrd_T */
	/** Uninitialize Keyboard and Mouse hooks */
	retVal = NatAgent_DestroyKMhook();  //Add the Native_Agent_KMhooks.c in the solution if this methods need to be used.
	if (retVal != NATIVE_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Key/Mouse hook call failed!", function);
	}
#endif /* KEYBOARD_MOUSE_HOOK */
#endif /*WINCE*/
#endif /*WIN32 */

	if (pgNatConf) {
		confRetVal = FreeConfigData(pgNatConf);
		if (confRetVal != CONFIG_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: GetConfigData() failed!", function);
		}
	}
#ifdef KEYBOARD_MOUSE_HOOK	 /* Enable this flag to use the Keyboard & mouse hook thread struct i.e natAgentThrd_T */
#ifdef WIN32
	if (pNatThrdHdl) {
		if (pNatThrdHdl->pThrdStrct) {
			SysDestroyThreadStruct(pNatThrdHdl->pThrdStrct);
			pNatThrdHdl->pThrdStrct = NULL;
		}

		if (pNatThrdHdl->pMutHdl) {
			SysMutex_Delete(pNatThrdHdl->pMutHdl);
			pNatThrdHdl->pMutHdl = NULL;
		}

		if (pNatThrdHdl->pPrmUtiOS) {

			if (pNatThrdHdl->pPrmUtiOS->uAstDet.pId) {
				Sys_Free(pNatThrdHdl->pPrmUtiOS->uAstDet.pId);
				pNatThrdHdl->pPrmUtiOS->uAstDet.pId = NULL;
			}

			if (pNatThrdHdl->pPrmUtiOS->puMouse) {
				Sys_Free(pNatThrdHdl->pPrmUtiOS->puMouse);
				pNatThrdHdl->pPrmUtiOS->puMouse = NULL;
			}

			if (pNatThrdHdl->pPrmUtiOS->puKeybrd) {
				Sys_Free(pNatThrdHdl->pPrmUtiOS->puKeybrd);
				pNatThrdHdl->pPrmUtiOS->puKeybrd = NULL;
			}

			Sys_Free(pNatThrdHdl->pPrmUtiOS);
			pNatThrdHdl->pPrmUtiOS = NULL;
		}

		Sys_Free(pNatThrdHdl);
		pNatThrdHdl = NULL;
	}
#endif /**WIN32**/
#endif /* KEYBOARD_MOUSE_HOOK */

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: exited with failure!", function);
	return retVal;
}


NativeErrCodes SCPI_Restart() {
	NativeErrCodes retVal = NATIVE_SUCCESS;
#ifdef SCPI_ENABLE
#ifdef _WIN32
	if (SCPIStatus == SYS_FALSE) {
		SysAppLog(SYS_INFO, MODULE_NATIVE_AGENT, "SCPI_Restart()");
		retValSCPI = scpi_Client_Connect(myClient);
		if (retValSCPI != ERR_OK) {
			scpi_Client_Disconnect(myClient);
			retVal = NATIVE_SYSTEM_ERROR;
			SCPIStatus = SYS_FALSE;
		}
		else {
			SCPIStatus = SYS_TRUE;
		}
	}
#endif
#endif

	return retVal;
}

NativeErrCodes NatAgent_GetData(
	void *pHdl,
	Param_Type *pPrmTyp,
	Param_Source *pPrmSrc,
	void *pStrToSend,
	Sys_Ulong *Buffer_Length
)
{
	NativeErrCodes retVal = NATIVE_SUCCESS;
	Sys_Char *function = "NatAgent_GetData";
 	//commented to supress warning
	//pnatAgentHdle pNatHdl = (pnatAgentHdle)pHdl;
	int ret = 0;
	Sys_Uint tmpLen = 0;
	Sys_Uint bufMaxLengthLocal = *Buffer_Length;

#ifdef KEYHOOK_PROC /*Enable this flag to get the Keyboard and Mouse Hook from Keysight_EMSHelper Application.*/
		//-----Keyhooks Socket
		Sys_Char *bufKMHook = NULL;
		//Sys_Char *token = NULL;
		//Sys_Int splitFlag = 0; //split timeStamp
		Sys_Int retValKMHook = 0;
		/*Sys_Char *keyTime = NULL;
		Sys_Char *mouseTime = NULL;*/
#endif

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: entered.", function);

	//Added Sept_19
#ifdef SCPI_ENABLE

#ifdef _WIN32
	HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hConsole, 11);
#else
	SysSleepMsec(300);
	printf("\x1b[33m");
#endif /**_WIN32**/

	// CWU SCPI TEST

	int osBufSize = bufMaxLengthLocal, scpiBufSize = bufMaxLengthLocal, totalBufSize = bufMaxLengthLocal;
	unsigned char *outputScpi = NULL, *outputOs = NULL, *outputSn = NULL;
	outputScpi = (unsigned char*)malloc(sizeof(unsigned char) * pgNatConf->Max_Message_Size);
	if (outputScpi == NULL) {
#ifdef _WIN32
		SetConsoleTextAttribute(hConsole, 4);
#endif
		printf("\nERROR!! Cannot alloc buffer.\n");
		totalBufSize = 0;
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		goto Finish;
	}
	outputOs = (unsigned char*)malloc(sizeof(unsigned char) * pgNatConf->Max_Message_Size);
	if (outputOs == NULL) {
#ifdef _WIN32
		SetConsoleTextAttribute(hConsole, 4);
#endif
		printf("\nERROR!! Cannot alloc buffer.\n");
		totalBufSize = 0;
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		goto Finish;
	}
	outputSn = (unsigned char*)malloc(sizeof(unsigned char) * 512);
	if (outputSn == NULL) {
#ifdef _WIN32
		SetConsoleTextAttribute(hConsole, 4);
#endif
		printf("\nERROR!! Cannot alloc buffer.\n");
		totalBufSize = 0;
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		goto Finish;
	}

#ifdef _WIN32
	SysSleepMsec(20);
	printf("\n----------------- SN -----------------\n");
	scpiBufSize = sizeof(unsigned char) * 512;
	ret = scpi_Client_GetSerialNumber(myClient, &outputSn, &scpiBufSize);
	outputSn[scpiBufSize] = '\0';
	if (ret == ERR_REACH_MAX_BUFFER_SIZE) {
		SetConsoleTextAttribute(hConsole, 4);
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! Reach Max Buffer Size. (SN SCPI)");
		totalBufSize = 0;
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		goto Finish;
	}
	else if (ret == ERR_SOCKET_ERROR || ret == ERR_NO_CONNECTION) {
		scpi_Client_Disconnect(myClient);
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "\nERROR!! No Socket Connection.");
		SCPIStatus = SYS_FALSE;
		scpiBufSize = 0;
		//totalBufSize = 0;
		//retVal = NATIVE_SYSTEM_ERROR;
		//goto Finish;
	}

#endif

	//printf("\n%s\n", outputSn);
#endif


	switch (*pPrmTyp)
	{
	case PRM_HEALTH_SCPI:
	case PRM_HEALTH_OS:
		/*
		(retVal = natAgent_GetHealthData_SCPI(&pNatHdl->pPrmHlth);
		if(retVal != NATIVE_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: natAgent_GetHealthData_SCPI() failed!", function);
		}

		*ppPrm = pNatHdl->pPrmHlth;*/


#ifdef SCPI_ENABLE
		printf("----------------- OS Health -----------------\n");
		osBufSize = bufMaxLengthLocal;
		ret = selfMonitor_GetHealthData(myMonitor, &outputOs, &osBufSize);
		if (ret == ERR_SELF_MONITOR_REACH_MAX_BUFFER_SIZE) {
#ifdef _WIN32
			SetConsoleTextAttribute(hConsole, 4);
#endif /**_WIN32**/
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! Reach Max Buffer Size. (Health OS)");
			totalBufSize = 0;
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			goto Finish;
		}

#ifdef _WIN32
		printf("----------------- Health SCPI -----------------\n");
		scpiBufSize = bufMaxLengthLocal;
		ret = scpi_Client_GetHealthData(myClient, &outputScpi, &scpiBufSize);
		if (ret == ERR_REACH_MAX_BUFFER_SIZE) {
			SetConsoleTextAttribute(hConsole, 4);
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! Reach Max Buffer Size. (Health SCPI)");
			totalBufSize = 0;
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			goto Finish;
		}
		else if (ret == ERR_SOCKET_ERROR || ret == ERR_NO_CONNECTION) {
			scpi_Client_Disconnect(myClient);
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! No Socket Connection.");
			SCPIStatus = SYS_FALSE;
			scpiBufSize = 0;
		}
#endif /**_WIN32**/

#else
		//*ppPrm = pszSCPIHealth;
		tmpLen = (Sys_Uint)strlen(pszSCPIHealth);
		if (tmpLen <= *Buffer_Length) {
			Sys_Memcpy(pStrToSend, pszSCPIHealth, tmpLen + 1);
			*Buffer_Length = tmpLen;
		}
		else
			retVal = NATIVE_INSUFFICIENT_MEMORY;

#endif
		break;

	case PRM_ENVIRONMENT_SCPI:
	case PRM_ENVIRONMENT_OS:
		/*retVal = natAgent_GetEnvironmentData_SCPI(&pNatHdl->pPrmEnv);
		if(retVal != NATIVE_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: natAgent_GetEnvironmentData_SCPI() failed!", function);
		}

		*ppPrm = pNatHdl->pPrmEnv;
		*/

#ifdef SCPI_ENABLE
		printf("----------------- OS Environment -----------------\n");
		osBufSize = bufMaxLengthLocal;
		ret = selfMonitor_GetEnvironmentData(myMonitor, &outputOs, &osBufSize);
		if (ret == ERR_SELF_MONITOR_REACH_MAX_BUFFER_SIZE) {
#ifdef _WIN32
			SetConsoleTextAttribute(hConsole, 4);
#endif /**_WIN32**/
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! Reach Max Buffer Size. (Environment OS)");
			totalBufSize = 0;
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			goto Finish;
		}

#ifdef _WIN32
		printf("----------------- Environment SCPI -----------------\n");
		scpiBufSize = bufMaxLengthLocal;
		ret = scpi_Client_GetEnvironmentData(myClient, &outputScpi, &scpiBufSize);
		if (ret == ERR_REACH_MAX_BUFFER_SIZE) {
			SetConsoleTextAttribute(hConsole, 4);
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! Reach Max Buffer Size. (Environment SCPI)");
			totalBufSize = 0;
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			goto Finish;
		}
		else if (ret == ERR_SOCKET_ERROR || ret == ERR_NO_CONNECTION) {
			scpi_Client_Disconnect(myClient);
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! No Socket Connection.");
			SCPIStatus = SYS_FALSE;
			scpiBufSize = 0;
		}
#endif /**_WIN32**/

#else
		//	*ppPrm = pszSCPIENV;
		tmpLen = (Sys_Uint)strlen(pszSCPIENV);
		if (tmpLen <= *Buffer_Length) {
			Sys_Memcpy(pStrToSend, pszSCPIENV, tmpLen + 1);
			*Buffer_Length = tmpLen;
		}
		else
			retVal = NATIVE_INSUFFICIENT_MEMORY;
#endif

		break;

	case PRM_UTILIZATION_SCPI:
		/*retVal = natAgent_GetUtilizationData_SCPI(&pNatHdl->pPrmUtiSCPI);
		if(retVal != NATIVE_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: natAgent_GetUtilizationData_SCPI() failed!", function);
		}

		*ppPrm = pNatHdl->pPrmUtiSCPI;*/
	case PRM_UTILIZATION_OS:
		/*retVal = natAgent_GetUtilizationData_OS(&pNatHdl->pPrmUtiOS);
		if(retVal != NATIVE_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: natAgent_GetUtilizationData_OS() failed!", function);
		}

		*ppPrm = pNatHdl->pPrmUtiOS;*/
#ifdef SCPI_ENABLE

		printf("----------------- OS Utilization -----------------\n");


#ifdef KEYHOOK_PROC /*Enable this flag to get the Keyboard and Mouse Hook from Keysight_EMSHelper Application.*/
if (keyHookHelper) {
			bufKMHook = (Sys_Char *)Sys_Malloc(DEFAULT_BUFLEN);
			if (bufKMHook != NULL)
			{
				memset(bufKMHook, '\0', DEFAULT_BUFLEN);
				retValKMHook = KeyMouseHook(bufKMHook);
				if (retValKMHook == NATIVE_SUCCESS) {
					SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Timestamp of the last input event is :%s", function, bufKMHook);
				}
				else {
					SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Failed to get timestamp from Keysight_EMSHelper application.", function);
				}
				/*if (bufKMHook[0] != '#')
					keyTime = strtok(bufKMHook, "#");
				else {
					mouseTime = strtok(bufKMHook, "#");
					keyTime = NULL;
					splitFlag = 1;
				}
				if (!splitFlag)
					mouseTime = strtok(NULL, "\0");

				SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s Last used Keyboard time :%s", function, keyTime);
				SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s Last used Mouse time :%s", function, mouseTime);*/
			}
			else
			{
				SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s Error in allocating the memory", function);
			}

			/**********************************Socket string for KeyMouseHooks receving(ends)***********************/
			selfMonitor_SetMisc(myMonitor, bufKMHook, bufKMHook);
}
#endif
		osBufSize = bufMaxLengthLocal;
		ret = selfMonitor_GetUtilizationData(myMonitor, &outputOs, &osBufSize);
		if (ret == ERR_SELF_MONITOR_REACH_MAX_BUFFER_SIZE) {
#ifdef _WIN32
			SetConsoleTextAttribute(hConsole, 4);
#endif /**_WIN32**/
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! Reach Max Buffer Size. (Utilization OS)");
			totalBufSize = 0;
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			goto Finish;
		}

#ifdef _WIN32
		printf("----------------- Utilization SCPI -----------------\n");
		scpiBufSize = bufMaxLengthLocal;
		ret = scpi_Client_GetUtilizationData(myClient, &outputScpi, &scpiBufSize);
		if (ret == ERR_REACH_MAX_BUFFER_SIZE) {
			SetConsoleTextAttribute(hConsole, 4);
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! Reach Max Buffer Size. (Utilization SCPI)");
			totalBufSize = 0;
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			goto Finish;
		}
		else if (ret == ERR_SOCKET_ERROR || ret == ERR_NO_CONNECTION) {
			scpi_Client_Disconnect(myClient);
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! No Socket Connection.");
			SCPIStatus = SYS_FALSE;
			scpiBufSize = 0;
		}
#endif /**_WIN32**/


#else
		//	*ppPrm = pszSCPIUtils;
		tmpLen = (Sys_Uint)strlen(pszSCPIUtils);
		if (tmpLen <= *Buffer_Length) {
			Sys_Memcpy(pStrToSend, pszSCPIUtils, tmpLen + 1);
			*Buffer_Length = tmpLen;
		}
		else
			retVal = NATIVE_INSUFFICIENT_MEMORY;
#endif

		break;

	case PRM_INFORMATION_SCPI:
	case PRM_INFORMATION_OS:
		//TBD: Ching Pu
#ifdef SCPI_ENABLE
		printf("----------------- OS Information -----------------\n");
		osBufSize = bufMaxLengthLocal;
		ret = selfMonitor_GetInformationData(myMonitor, &outputOs, &osBufSize);
		if (ret == ERR_SELF_MONITOR_REACH_MAX_BUFFER_SIZE) {
#ifdef _WIN32
			SetConsoleTextAttribute(hConsole, 4);
#endif
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! Reach Max Buffer Size. (Information OS)");
			totalBufSize = 0;
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			goto Finish;
		}

#ifdef _WIN32
		printf("----------------- Information SCPI -----------------\n");
		scpiBufSize = bufMaxLengthLocal;
		ret = scpi_Client_GetInformationData(myClient, &outputScpi, &scpiBufSize);
		if (ret == ERR_REACH_MAX_BUFFER_SIZE) {
			SetConsoleTextAttribute(hConsole, 4);
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! Reach Max Buffer Size. (Information SCPI)");
			totalBufSize = 0;
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			goto Finish;
		}
		else if (ret == ERR_SOCKET_ERROR || ret == ERR_NO_CONNECTION) {
			scpi_Client_Disconnect(myClient);
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "ERROR!! No Socket Connection.");
			SCPIStatus = SYS_FALSE;
			scpiBufSize = 0;
		}
#endif /**_WIN32**/


#else
		//	*ppPrm = pszSCPIInfo;
		tmpLen = (Sys_Uint)strlen(pszSCPIInfo);
		if (tmpLen <= *Buffer_Length) {
			Sys_Memcpy(pStrToSend, pszSCPIInfo, tmpLen + 1);
			*Buffer_Length = tmpLen;
		}
		else
			retVal = NATIVE_INSUFFICIENT_MEMORY;
#endif
		break;

	default:
		retVal = NATIVE_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Wrong parameter type!", function);
		break;
	}
#ifdef SCPI_ENABLE



#ifndef _WIN32
	scpiBufSize = 0; // CWU
	outputSn[0] = 0;
#endif /**_WIN32**/
	char headerStr[512] = { 0 };
	char assetType[32] = { 0 };
	switch (pgNatConf->m_Asset.Type) {
	case ASSET:
		strcpy(assetType, "ASSET");
		break;
	case PLUM:
		strcpy(assetType, "PLUM");
		break;
	case SYSTEM_CONTROLLER:
		strcpy(assetType, "SYSTEM_CONTROLLER");
		break;
	default:
		strcpy(assetType, "ASSET");
		break;
	}
	char strTmp[512] = { 0 };
	snprintf(strTmp, sizeof(strTmp),
		"\"asset_id\": \"%s\",\n\"asset_type\": \"%s\",\n\"idn\": \"%s\",\n\"ems_ver\": \"%s%s\"",
		pgNatConf->m_Asset.pId,
		assetType,
		outputSn,
		EMS_AGENT_PLATFORM,
		EMS_AGENT_VERSION);
	strcpy(headerStr, strTmp);
	strTmp[0] = 0;

	SysAppLog(SYS_INFO, MODULE_NATIVE_AGENT, "Buffer Log: (%d, %d)\n", bufMaxLengthLocal, (scpiBufSize + osBufSize + 512/*room for header size*/));
	printf("Buffer Log: (%d, %d)\n", bufMaxLengthLocal, (scpiBufSize + osBufSize + 512/*room for header size*/));
	if (bufMaxLengthLocal < (Sys_Uint)(scpiBufSize + osBufSize + 512/*room for header size*/)) {
#ifdef _WIN32
		SetConsoleTextAttribute(hConsole, 4);
#endif /**_WIN32**/
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "\nERROR!! Reach Max Buffer Size. (Total buffer)");
		totalBufSize = 0;
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		goto Finish;
	}
	else {
		combineCharArraysWithHeader(headerStr, outputOs, osBufSize, outputScpi, scpiBufSize, &pStrToSend, &totalBufSize);
	}

Finish:
	*Buffer_Length = totalBufSize;
	if (outputScpi != NULL)
		free(outputScpi);
	if (outputOs != NULL)
		free(outputOs);
	if (outputSn != NULL)
		free(outputSn);

#ifdef _WIN32
	SetConsoleTextAttribute(hConsole, 2);
#else
	printf("\x1b[0m");
#endif /**_WIN32**/

#endif

#ifdef KEYHOOK_PROC
	if (bufKMHook) {
		Sys_Free(bufKMHook);
		bufKMHook = NULL;
	}
#endif

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: exited.", function);
	return retVal;
}

NativeErrCodes NatAgent_SetConfigData(configparam *pConfig)
{
	Sys_Char *function = " NativeAgent_SetConfigData";
	NativeErrCodes retVal = NATIVE_SUCCESS;

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: entered.", function);
	if (pConfig == NULL) {
		retVal = NATIVE_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Wrong Input params!", function);
		goto failCall;
	}

	if (pgNatConf != NULL) {
		SysMutex_Lock(pConfig->mutexHdl);
		SysMutex_Lock(pgNatConf->mutexHdl);

		if (pgNatConf->m_Asset.pId) {
			Sys_Free(pgNatConf->m_Asset.pId);
			pgNatConf->m_Asset.pId = NULL;
		}
		pgNatConf->m_Asset.pId = Sys_StrDup(pConfig->m_Asset.pId);
		if (pgNatConf->m_Asset.pId == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pgNatConf->m_Asset.pId - Insufficient Memory!", function);
			goto failCall;
		}

		//Added Sept_19
		// Asset Connection Config
		if (pgNatConf->m_Asset.comType) {
			Sys_Free(pgNatConf->m_Asset.comType);
			pgNatConf->m_Asset.comType = NULL;
		}
		pgNatConf->m_Asset.comType = Sys_StrDup(pConfig->m_Asset.comType);
		if (pgNatConf->m_Asset.comType == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pgNatConf->m_Asset.comType - Insufficient Memory!", function);
			goto failCall;
		}

		if (pgNatConf->m_Asset.comAddr) {
			Sys_Free(pgNatConf->m_Asset.comAddr);
			pgNatConf->m_Asset.comAddr = NULL;
		}
		pgNatConf->m_Asset.comAddr = Sys_StrDup(pConfig->m_Asset.comAddr);
		if (pgNatConf->m_Asset.comAddr == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pgNatConf->m_Asset.comAddr - Insufficient Memory!", function);
			goto failCall;
		}

		if (pgNatConf->m_Asset.comPort) {
			Sys_Free(pgNatConf->m_Asset.comPort);
			pgNatConf->m_Asset.comPort = NULL;
		}
		pgNatConf->m_Asset.comPort = Sys_StrDup(pConfig->m_Asset.comPort);
		if (pgNatConf->m_Asset.comPort == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pgNatConf->m_Asset.comPort - Insufficient Memory!", function);
			goto failCall;
		}
		//End Sept_19

		// For App Utilization
		if (pgNatConf->m_Asset.appName) {
			Sys_Free(pgNatConf->m_Asset.appName);
			pgNatConf->m_Asset.appName = NULL;
		}
		pgNatConf->m_Asset.appName = Sys_StrDup(pConfig->m_Asset.appName);
		if (pgNatConf->m_Asset.appName == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pgNatConf->m_Asset.appName - Insufficient Memory!", function);
			goto failCall;
		}

		// For Plum Ref Volt
		pgNatConf->m_Asset.refVolt = pConfig->m_Asset.refVolt;

		if (pgNatConf->m_Asset.misc) {
			Sys_Free(pgNatConf->m_Asset.misc);
			pgNatConf->m_Asset.misc = NULL;
		}
		if (pConfig->m_Asset.misc) {
			pgNatConf->m_Asset.misc = Sys_StrDup(pConfig->m_Asset.misc);
			if (pgNatConf->m_Asset.misc == NULL) {
				// skip error since this is an option parameter
				/*retVal = NATIVE_INSUFFICIENT_MEMORY;
				SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pgNatConf->m_Asset.misc - Insufficient Memory!", function);
				goto failCall;*/
			}
		}

		//SCM - 11/9/2017 Version---------------------------------------------------------------
		if (pgNatConf->m_ConfigVersion) {
			Sys_Free(pgNatConf->m_ConfigVersion);
			pgNatConf->m_ConfigVersion = NULL;
		}
		pgNatConf->m_ConfigVersion = Sys_StrDup(pConfig->m_ConfigVersion);
		if (pgNatConf->m_ConfigVersion == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pgNatConf->m_Version - Insufficient Memory!", function);
			goto failCall;
		}
		//----------------------------------------------------------------------------------------
		if (pgNatConf->m_ThingName) {
			Sys_Free(pgNatConf->m_ThingName);
			pgNatConf->m_ThingName = NULL;
		}
		pgNatConf->m_ThingName = Sys_StrDup(pConfig->m_ThingName);
		if (pgNatConf->m_ThingName == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pgNatConf->m_ThingName - Insufficient Memory!", function);
			goto failCall;
		}

		if (pgNatConf->m_HostName) {
			Sys_Free(pgNatConf->m_HostName);
			pgNatConf->m_HostName = NULL;
		}
		pgNatConf->m_HostName = Sys_StrDup(pConfig->m_HostName);
		if (pgNatConf->m_HostName == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pgNatConf->m_HostName - Insufficient Memory!", function);
			goto failCall;
		}

		if (pgNatConf->m_AppKey) {
			Sys_Free(pgNatConf->m_AppKey);
			pgNatConf->m_AppKey = NULL;
		}
		pgNatConf->m_AppKey = Sys_StrDup(pConfig->m_AppKey);
		if (pgNatConf->m_AppKey == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pgNatConf->m_AppKey - Insufficient Memory!", function);
			goto failCall;
		}

		if (pgNatConf->m_Encryption) {
			Sys_Free(pgNatConf->m_Encryption);
			pgNatConf->m_Encryption = NULL;
		}
		pgNatConf->m_Encryption = Sys_StrDup(pConfig->m_Encryption);
		if (pgNatConf->m_Encryption == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pgNatConf->m_Encryption - Insufficient Memory!", function);
			goto failCall;
		}

		pgNatConf->Max_Message_Size = pConfig->Max_Message_Size;
		pgNatConf->m_Asset.Type = pConfig->m_Asset.Type;
		pgNatConf->m_EmsStatus = pConfig->m_EmsStatus;
		pgNatConf->m_Port = pConfig->m_Port;
		pgNatConf->acquisition.unit = pConfig->acquisition.unit;
		pgNatConf->acquisition.health = pConfig->acquisition.health;
		pgNatConf->acquisition.environment = pConfig->acquisition.environment;
		pgNatConf->acquisition.utilization = pConfig->acquisition.utilization;
		pgNatConf->acquisition.information = pConfig->acquisition.information;
		/*	pgNatConf->posting.unit = pConfig->posting.unit;
		pgNatConf->posting.health = pConfig->posting.health;
		pgNatConf->posting.environment = pConfig->posting.environment;
		pgNatConf->posting.utilization = pConfig->posting.utilization;*/

		SysMutex_Unlock(pgNatConf->mutexHdl);
		SysMutex_Unlock(pConfig->mutexHdl);
	}
	else {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pgNatConf not initiliazed!", function);
	}

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: exited.", function);

failCall:
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s:exited with failure!", function);

	return retVal;
}

NativeErrCodes NatAgent_Uninit(
	void *pHdl
)
{
	NativeErrCodes retVal = NATIVE_SUCCESS;
	NativeErrCodes retValSock = NATIVE_SUCCESS;
	Sys_Char *function = "NatAgent_Uninit";
	pnatAgentHdle pNatHdl = (pnatAgentHdle)pHdl;
	ConfigErrCodes confRetVal = CONFIG_SUCCESS;
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: entered.", function);


#ifdef KEYHOOK_PROC /*Enable this flag to get the Keyboard and Mouse Hook from Keysight_EMSHelper Application.*/
	if (ConnectSocket != INVALID_SOCKET && keyHookHelper) {
		retValSock = Socket_UnInit();
		if (!retValSock)
			SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: Socket_UnInit success.", function);
		else
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Socket_UnInit failed.", function);
	}
#endif

	//Added Sept_19
#ifdef SCPI_ENABLE
	// CWU SCPI_INTERFACE
#ifdef _WIN32
	scpi_Client_Disconnect(myClient);
	scpi_Client_Destroy(myClient);
#endif /**_WIN32**/
	selfMonitor_Destroy(myMonitor);
#endif //End Sept_19

	if (pgNatConf) {
		confRetVal = FreeConfigData(pgNatConf);
		if (confRetVal != CONFIG_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: GetConfigData() failed!", function);
		}
	}

	if (pNatHdl) {
		if (pNatHdl->pPrmHlth) {
			if (pNatHdl->pPrmHlth->hAstDet.pId) {
				Sys_Free(pNatHdl->pPrmHlth->hAstDet.pId);
				pNatHdl->pPrmHlth->hAstDet.pId = NULL;
			}

			if (pNatHdl->pPrmHlth->hMemory.phOSVer) {
				Sys_Free(pNatHdl->pPrmHlth->hMemory.phOSVer);
				pNatHdl->pPrmHlth->hMemory.phOSVer = NULL;
			}

			Sys_Free(pNatHdl->pPrmHlth);
			pNatHdl->pPrmHlth = NULL;
		}

		if (pNatHdl->pPrmEnv) {
			if (pNatHdl->pPrmEnv->eAstDet.pId) {
				Sys_Free(pNatHdl->pPrmEnv->eAstDet.pId);
				pNatHdl->pPrmEnv->eAstDet.pId = NULL;
			}

			if (pNatHdl->pPrmEnv->eAccelMet.eXAxis) {
				Sys_Free(pNatHdl->pPrmEnv->eAccelMet.eXAxis);
				pNatHdl->pPrmEnv->eAccelMet.eXAxis = NULL;
			}

			if (pNatHdl->pPrmEnv->eAccelMet.eYAxis) {
				Sys_Free(pNatHdl->pPrmEnv->eAccelMet.eYAxis);
				pNatHdl->pPrmEnv->eAccelMet.eYAxis = NULL;
			}

			if (pNatHdl->pPrmEnv->eAccelMet.eZAxis) {
				Sys_Free(pNatHdl->pPrmEnv->eAccelMet.eZAxis);
				pNatHdl->pPrmEnv->eAccelMet.eZAxis = NULL;
			}

			Sys_Free(pNatHdl->pPrmEnv);
			pNatHdl->pPrmEnv = NULL;
		}

		if (pNatHdl->pPrmUtiSCPI) {
			if (pNatHdl->pPrmUtiSCPI->uAstDet.pId) {
				Sys_Free(pNatHdl->pPrmUtiSCPI->uAstDet.pId);
				pNatHdl->pPrmUtiSCPI->uAstDet.pId = NULL;
			}

			if (pNatHdl->pPrmUtiSCPI->puFrntPanl) {
				Sys_Free(pNatHdl->pPrmUtiSCPI->puFrntPanl);
				pNatHdl->pPrmUtiSCPI->puFrntPanl = NULL;
			}

			if (pNatHdl->pPrmUtiSCPI->puSCPI) {
				Sys_Free(pNatHdl->pPrmUtiSCPI->uAstDet.pId);
				pNatHdl->pPrmUtiSCPI->uAstDet.pId = NULL;
			}

			Sys_Free(pNatHdl->pPrmUtiSCPI);
			pNatHdl->pPrmUtiSCPI = NULL;
		}

		if (pNatHdl->pPrmUtiOS) {
			if (pNatHdl->pPrmUtiOS->uAstDet.pId) {
				Sys_Free(pNatHdl->pPrmUtiOS->uAstDet.pId);
				pNatHdl->pPrmUtiOS->uAstDet.pId = NULL;
			}

			if (pNatHdl->pPrmUtiOS->puKeybrd) {
				Sys_Free(pNatHdl->pPrmUtiOS->puKeybrd);
				pNatHdl->pPrmUtiOS->puKeybrd = NULL;
			}

			if (pNatHdl->pPrmUtiOS->puMouse) {
				Sys_Free(pNatHdl->pPrmUtiOS->puMouse);
				pNatHdl->pPrmUtiOS->puMouse = NULL;
			}

			Sys_Free(pNatHdl->pPrmUtiOS);
			pNatHdl->pPrmUtiOS = NULL;
		}

		Sys_Free(pNatHdl);
		pNatHdl = NULL;
	}
	else {
		retVal = NATIVE_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Wrong IP pHdl passed!", function);
	}
	if (pszSCPIUtils)
	{
		Sys_Free(pszSCPIUtils);
		pszSCPIUtils = NULL;
	}
	if (pszSCPIHealth)
	{
		Sys_Free(pszSCPIHealth);
		pszSCPIHealth = NULL;
	}
	if (pszSCPIENV)
	{
		Sys_Free(pszSCPIENV);
		pszSCPIENV = NULL;
	}
	if (pszSCPIInfo)
	{
		Sys_Free(pszSCPIInfo);
		pszSCPIInfo = NULL;
	}

#ifdef WIN32
#ifdef KEYBOARD_MOUSE_HOOK  /* Enable this flag to use the Keyboard & mouse hook thread struct i.e natAgentThrd_T */
#ifndef WINCE
	/** Uninitialize Keyboard and Mouse hooks */
	retVal = NatAgent_DestroyKMhook(); //Add the Native_Agent_KMhooks.c in the solution if this method needs to be used.
	if (retVal != NATIVE_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Key/Mouse hook call failed!", function);
	}
#endif /*WINCE*/

	if (pNatThrdHdl) {
		if (pNatThrdHdl->pThrdStrct) {
			SysDestroyThreadStruct(pNatThrdHdl->pThrdStrct);
			pNatThrdHdl->pThrdStrct = NULL;
		}

		if (pNatThrdHdl->pMutHdl) {
			SysMutex_Delete(pNatThrdHdl->pMutHdl);
			pNatThrdHdl->pMutHdl = NULL;
		}

		if (pNatThrdHdl->pPrmUtiOS) {

			if (pNatThrdHdl->pPrmUtiOS->uAstDet.pId) {
				Sys_Free(pNatThrdHdl->pPrmUtiOS->uAstDet.pId);
				pNatThrdHdl->pPrmUtiOS->uAstDet.pId = NULL;
			}

			if (pNatThrdHdl->pPrmUtiOS->puMouse) {
				Sys_Free(pNatThrdHdl->pPrmUtiOS->puMouse);
				pNatThrdHdl->pPrmUtiOS->puMouse = NULL;
			}

			if (pNatThrdHdl->pPrmUtiOS->puKeybrd) {
				Sys_Free(pNatThrdHdl->pPrmUtiOS->puKeybrd);
				pNatThrdHdl->pPrmUtiOS->puKeybrd = NULL;
			}

			Sys_Free(pNatThrdHdl->pPrmUtiOS);
			pNatThrdHdl->pPrmUtiOS = NULL;
		}

		Sys_Free(pNatThrdHdl);
		pNatThrdHdl = NULL;
	}
#endif /*WIN32 */
#endif /* KEYBOARD_MOUSE_HOOK */
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: exited.", function);

	return retVal;
}
