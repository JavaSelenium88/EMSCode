// EMS_Agent.cpp : Defines the entry point for the console application.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//#include "Systypes.h"
#include "Sysapi.h"
#include "SysLog.h"
//#include "twOSPort.h"
//#include "twApi.h"
#include "Native_Agent.h"
#include "Native_Agent_Utils.h"

NativeErrCodes natAgent_GetHealthData_SCPI (
	pParam_Health *ppPrm /**< Actual parameters data */
	)
{
	NativeErrCodes retVal = NATIVE_SUCCESS;
	Sys_Char *function = "NatAgent_GetHealthData_SCPI";

	pParam_Health pPrm = NULL;
	Sys_Int idx1 = 0;

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: entered.", function);

	if(*ppPrm == NULL) {
		pPrm = (pParam_Health) Sys_Malloc(sizeof(Param_Health));
		if(pPrm == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Insufficient Memory!", function);
			goto failCall;
		}
		pPrm->hAstDet.pId = NULL;
		pPrm->hMemory.phOSVer = NULL;

		*ppPrm = pPrm;
	}
	else {
		pPrm = *ppPrm;
	}

	//TODO: Vishal - Stub. Actually needs to be retrieved through SCPI server/application.
	pPrm->hAttenuator = 10;
	pPrm->hBattery.hCycles = 10;
	pPrm->hBattery.hLifeRemain = 50;
	pPrm->hDefinedPart = 100;
	pPrm->hDisplay = 50;
	pPrm->hLaser = 50;
	pPrm->hMemory.hBytesAvail = 10000;
	pPrm->hMemory.hBytesUsed = 5000;
	
	pPrm->hMotor.hMovements = 100;
	pPrm->hMotor.hMovTime = 100;
	pPrm->hMotor.hOnTime = 50;
	pPrm->hMotor.hRevolut = 1000;
	pPrm->hOutput = 50;
	pPrm->hPart = 50;
	pPrm->hProduct = 50;
	pPrm->hSwitch = 100;
	pPrm->hPrmSrc = SCPI_INT;
	
	SysMutex_Lock(pgNatConf->mutexHdl);
	if (pPrm->hAstDet.pId) {
		Sys_Free(pPrm->hAstDet.pId);
		pPrm->hAstDet.pId = NULL;
	}
	pPrm->hAstDet.pId = Sys_StrDup(pgNatConf->m_Asset.pId);
	if (pPrm->hAstDet.pId == NULL) {
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pPrm->hAstDet.pId - Insufficient Memory!", function);
		goto failCall;
	}

	pPrm->hAstDet.Type = pgNatConf->m_Asset.Type;
	SysMutex_Unlock(pgNatConf->mutexHdl);

	if (pPrm->hMemory.phOSVer)
		Sys_Free(pPrm->hMemory.phOSVer);
	pPrm->hMemory.phOSVer = NULL;
	idx1 = (Sys_Int)strlen("8.1");
	pPrm->hMemory.phOSVer = (Sys_Char *)Sys_Malloc(idx1 + 1);
	if (pPrm->hMemory.phOSVer == NULL) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Failed to allocate memory for OS version! ", function);
		goto failCall;
	}
	else {
		Sys_StringnCpy(pPrm->hMemory.phOSVer, "8.1", idx1, idx1 + 1);
	}
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: exited.", function);
	return retVal;

failCall:
	if(pPrm) { 
		if (pPrm->hAstDet.pId) {
			Sys_Free(pPrm->hAstDet.pId);
			pPrm->hAstDet.pId = NULL;
		}
		
		if(pPrm->hMemory.phOSVer) {
			Sys_Free(pPrm->hMemory.phOSVer);
			pPrm->hMemory.phOSVer = NULL;
		}

		Sys_Free(pPrm); //TODO: Vishal: Need to check if it has to be freed on failure on every successive calls???
		pPrm = NULL;
	}
	SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: exited with failure!", function);
	return retVal;
}

NativeErrCodes natAgent_GetEnvironmentData_SCPI(
	pParam_Environment *ppPrm /**< Actual parameters data */
	)
{
	NativeErrCodes retVal = NATIVE_SUCCESS;
	Sys_Char *function = "natAgent_GetEnvData_SCPI";
	pParam_Environment pPrm = NULL;
	Sys_Int idx1 = 0;
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: entered.", function);
	if (*ppPrm == NULL) {
		pPrm = (pParam_Environment)Sys_Malloc(sizeof(Param_Environment));
		if (pPrm == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Insufficient Memory! ", function);
			goto failCall;
		}
		pPrm->eAstDet.pId = NULL;
		pPrm->eAccelMet.eXAxis = NULL;
		pPrm->eAccelMet.eYAxis = NULL;
		pPrm->eAccelMet.eZAxis = NULL;

		*ppPrm = pPrm;
	}
	else {
		pPrm = *ppPrm;
	}

	pPrm->eCurrSens = 5.5;
	pPrm->eHumidSens = 10.5;
	pPrm->eLightSens = 50.5;
	pPrm->ePressSens = 40.5;
	pPrm->eTempSens = 30.5;
	pPrm->eVoltSens = 200.5;
	/*pPrm->eAstDet.Type = ASSET;*/
	pPrm->ePrmSrc = SCPI_INT;

	SysMutex_Lock(pgNatConf->mutexHdl);
	if (pPrm->eAstDet.pId) {
		Sys_Free(pPrm->eAstDet.pId);
		pPrm->eAstDet.pId = NULL;
	}

	pPrm->eAstDet.pId = Sys_StrDup(pgNatConf->m_Asset.pId);
	if (pPrm->eAstDet.pId == NULL) {
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pPrm->eAstDet.pId - Insufficient Memory!", function);
		goto failCall;
	}
	pPrm->eAstDet.Type = pgNatConf->m_Asset.Type;
	SysMutex_Unlock(pgNatConf->mutexHdl);

	if (pPrm->eAccelMet.eXAxis)
		Sys_Free(pPrm->eAccelMet.eXAxis);
	pPrm->eAccelMet.eXAxis = NULL;
	idx1 = (Sys_Int)strlen("SIDE-TO-SIDE");
	pPrm->eAccelMet.eXAxis = (Sys_Char *)Sys_Malloc(idx1 + 1);
	if (pPrm->eAccelMet.eXAxis == NULL) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Failed to allocate memory for XAxis!", function);
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		goto failCall;

	}
	else {
		Sys_StringnCpy(pPrm->eAccelMet.eXAxis, "SIDE-TO-SIDE", idx1, idx1 + 1);
	}


	if (pPrm->eAccelMet.eYAxis)
		Sys_Free(pPrm->eAccelMet.eYAxis);
	pPrm->eAccelMet.eYAxis = NULL;
	idx1 = (Sys_Int)strlen("TOP-TO-BOTTOM");
	pPrm->eAccelMet.eYAxis = (Sys_Char *)Sys_Malloc(idx1 + 1);
	if (pPrm->eAccelMet.eYAxis == NULL) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Failed to allocate memory for YAxis!", function);
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		goto failCall;
	}
	else {
		Sys_StringnCpy(pPrm->eAccelMet.eYAxis, "TOP-TO-BOTTOM", idx1, idx1 + 1);
	}

	if (pPrm->eAccelMet.eZAxis)
		Sys_Free(pPrm->eAccelMet.eZAxis);
	pPrm->eAccelMet.eZAxis = NULL;
	idx1 = (Sys_Int)strlen("FRONT-TO-BACK");
	pPrm->eAccelMet.eZAxis = (Sys_Char *)Sys_Malloc(idx1 + 1);
	if (pPrm->eAccelMet.eZAxis == NULL) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Failed to allocate memory for ZAxis!", function);
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		goto failCall;
	}
	else {
		Sys_StringnCpy(pPrm->eAccelMet.eZAxis, "FRONT-TO-BACK", idx1, idx1 + 1);
	}

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: exited.\n", function);
	return retVal;

failCall:
	if (pPrm) {
		if (pPrm->eAstDet.pId) {
			Sys_Free(pPrm->eAstDet.pId);
			pPrm->eAstDet.pId = NULL;
		}

		if (pPrm->eAccelMet.eXAxis) {
			Sys_Free(pPrm->eAccelMet.eXAxis);
			pPrm->eAccelMet.eXAxis = NULL;
		}

		if (pPrm->eAccelMet.eYAxis) {
			Sys_Free(pPrm->eAccelMet.eYAxis);
			pPrm->eAccelMet.eYAxis = NULL;
		}

		if (pPrm->eAccelMet.eZAxis) {
			Sys_Free(pPrm->eAccelMet.eZAxis);
			pPrm->eAccelMet.eZAxis = NULL;
		}

		Sys_Free(pPrm);//TODO: Vishal: Need to check if it has to be freed on failure on every successive calls???
		pPrm = NULL;
	}

	SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: exited with failure!", function);
	return retVal;
}

NativeErrCodes natAgent_GetUtilizationData_SCPI(
	pParam_Utilization_SCPI *ppPrm /**< Actual parameters data */
	)
{
	NativeErrCodes retVal = NATIVE_SUCCESS;
	Sys_Char *function = "natAgent_GetUtilizationData_SCPI";
	pParam_Utilization_SCPI pPrm = NULL;
	Sys_Int idx1 = 0;

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: entered.", function);
	if (*ppPrm == NULL) {
		pPrm = (pParam_Utilization_SCPI)Sys_Malloc(sizeof(Param_Utilization_SCPI));
		if (pPrm == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Insufficient Memory!", function);
			goto failCall;
		}
		pPrm->puFrntPanl = NULL;
		pPrm->puSCPI = NULL;
		pPrm->uAstDet.pId = NULL;

		*ppPrm = pPrm;
	}
	else {
		pPrm = *ppPrm;
	}

	/*pPrm->uAstDet.Type = ASSET;*/
	pPrm->uPrmSrc = SCPI_INT;

	SysMutex_Lock(pgNatConf->mutexHdl);
	if (pPrm->uAstDet.pId){
		Sys_Free(pPrm->uAstDet.pId);
		pPrm->uAstDet.pId = NULL;
	}
	pPrm->uAstDet.pId = Sys_StrDup(pgNatConf->m_Asset.pId);
		
	if (pPrm->uAstDet.pId == NULL)
	{
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pPrm->uAstDet.pId - Insufficient Memory!", function);
		goto failCall;
	}

	pPrm->uAstDet.Type = pgNatConf->m_Asset.Type;
	SysMutex_Unlock(pgNatConf->mutexHdl);

	if (pPrm->puSCPI)
		Sys_Free(pPrm->puSCPI);
	pPrm->puSCPI = NULL;
	idx1 = (Sys_Int)strlen("2016-06-02 18-10-20");
	pPrm->puSCPI = (Sys_Char *)Sys_Malloc(idx1 + 1);
	if (pPrm->puSCPI == NULL) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Failed to allocate memory for SCPI Timestamp!", function);
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		goto failCall;
	}
	else {
		Sys_StringnCpy(pPrm->puSCPI, "2016-06-02 18-10-20", idx1, idx1 + 1);
	}

	if (pPrm->puFrntPanl)
		Sys_Free(pPrm->puFrntPanl);
	pPrm->puFrntPanl = NULL;
	idx1 = (Sys_Int)strlen("2016-06-02 18-10-20");
	pPrm->puFrntPanl = (Sys_Char *)Sys_Malloc(idx1 + 1);
	if (pPrm->puFrntPanl == NULL) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Failed to allocate memory for front panel!", function);
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		goto failCall;
	}
	else {
		Sys_StringnCpy(pPrm->puFrntPanl, "2016-06-02 18-10-20", idx1, idx1 + 1);
	}
	pPrm->uLicense = (Sys_Bool)1;
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: exited.", function);
	return retVal;

failCall:
	if (pPrm) {
		if (pPrm->uAstDet.pId) {
			Sys_Free(pPrm->uAstDet.pId);
			pPrm->uAstDet.pId = NULL;
		}

		if (pPrm->puFrntPanl) {
			Sys_Free(pPrm->puFrntPanl);
			pPrm->puFrntPanl = NULL;
		}

		if (pPrm->puSCPI) {
			Sys_Free(pPrm->puSCPI);
			pPrm->puSCPI = NULL;
		}

		Sys_Free(pPrm); //TODO: Vishal: Need to check if it has to be freed on failure on every successive calls???
		pPrm = NULL;
	}

	SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: exited with failure!", function);
	return retVal;
}

NativeErrCodes natAgent_GetUtilizationData_OS(
	pParam_Utilization_OS *ppPrm /**< Actual parameters data */
	)
{
	NativeErrCodes retVal = NATIVE_SUCCESS;
	Sys_Char *function = "natAgent_GetUtilizationData_SCPI";
	pParam_Utilization_OS pPrm = NULL;
	
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: entered.", function);
	if (*ppPrm == NULL) {
		pPrm = (pParam_Utilization_OS)Sys_Malloc(sizeof(Param_Utilization_OS));
		if (pPrm == NULL) {
			retVal = NATIVE_INSUFFICIENT_MEMORY;

			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Insufficient Memory!", function);
			goto failCall;
		}
		pPrm->puKeybrd = NULL;
		pPrm->puMouse = NULL;

		*ppPrm = pPrm;
	}
	else {
		pPrm = *ppPrm;
	}

	/*pPrm->uAstDet.Type = ASSET;*/
	pPrm->uPrmSrc = OS_INT;

	SysMutex_Lock(pgNatConf->mutexHdl);
	if (pPrm->uAstDet.pId){
		Sys_Free(pPrm->uAstDet.pId);
		pPrm->uAstDet.pId = NULL;
	}
		pPrm->uAstDet.pId = Sys_StrDup(pgNatConf->m_Asset.pId);
	
		if (pPrm->uAstDet.pId == NULL)
	{
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: pPrm->uAstDet.pId - Insufficient Memory!", function);
		goto failCall;
	}
	pPrm->uAstDet.Type = pgNatConf->m_Asset.Type;
	SysMutex_Unlock(pgNatConf->mutexHdl);

	if (pPrm->puMouse)
		Sys_Free(pPrm->puMouse);
	pPrm->puMouse = NULL;
	pPrm->puMouse = (Sys_Char *)Sys_Malloc(TIMESTMAMP_LENGTH);
	if (pPrm->puMouse == NULL) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Failed to allocate memory for Mouse Timestamp!", function);
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		goto failCall;
	}
#ifdef KEYBOARD_MOUSE_HOOK  /* Enable this flag to use the Keyboard & mouse hook thread struct i.e natAgentThrd_T */
	else {
		SysMutex_Lock(pNatThrdHdl->pMutHdl);
		Sys_StringnCpy(pPrm->puMouse, pNatThrdHdl->pPrmUtiOS->puMouse, Sys_StringLength(pNatThrdHdl->pPrmUtiOS->puMouse), TIMESTMAMP_LENGTH);
		SysMutex_Unlock(pNatThrdHdl->pMutHdl);
	}
#endif /* KEYBOARD_MOUSE_HOOK */
	if (pPrm->puKeybrd)
		Sys_Free(pPrm->puKeybrd);
	pPrm->puKeybrd = NULL;
	pPrm->puKeybrd = NULL;
	pPrm->puKeybrd = (Sys_Char *)Sys_Malloc(TIMESTMAMP_LENGTH);
	if (pPrm->puKeybrd == NULL) {
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Failed to allocate memory for Keyboard Timestamp!", function);
		retVal = NATIVE_INSUFFICIENT_MEMORY;
		goto failCall;
	}
#ifdef KEYBOARD_MOUSE_HOOK  /* Enable this flag to use the Keyboard & mouse hook thread struct i.e natAgentThrd_T */
	else {
		SysMutex_Lock(pNatThrdHdl->pMutHdl);
		Sys_StringnCpy(pPrm->puKeybrd, pNatThrdHdl->pPrmUtiOS->puKeybrd, Sys_StringLength(pNatThrdHdl->pPrmUtiOS->puKeybrd), TIMESTMAMP_LENGTH);
		SysMutex_Unlock(pNatThrdHdl->pMutHdl);
	}
#endif /* KEYBOARD_MOUSE_HOOK */
	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: exited.", function);
	return retVal;
failCall:
	if (pPrm) {
		
		if (pPrm->uAstDet.pId) {
			Sys_Free(pPrm->uAstDet.pId);
			pPrm->uAstDet.pId = NULL;
		}

		if (pPrm->puMouse) {
			Sys_Free(pPrm->puMouse);
			pPrm->puMouse = NULL;
		}
		
		if (pPrm->puKeybrd) {
			Sys_Free(pPrm->puKeybrd);
			pPrm->puKeybrd = NULL;
		}

		Sys_Free(pPrm); //TODO: Vishal: Need to check if it has to be freed on failure on every successive calls???
		pPrm = NULL;
	}

	SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: exited with failure!", function);
	return retVal;
}