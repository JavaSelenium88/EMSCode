//*****************************************************************************
//
//  Copyright � 2016 ITC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  Native_Agent.h
//  
//  Subsystem  :  Native_Agent
//
//  Description:  Interface Header file for Native Agent.   
//
//*****************************************************************************

#ifndef __NATIVE_AGENT_UTILS_H__
#define __NATIVE_AGENT_UTILS_H__

#include "twApi.h"
#include "SysThread.h"


#ifdef SCPI_ENABLE
#ifdef _WIN32
#include "Scpi_Client_C.h"
#endif /**_WIN32**/
#include "Self_Monitor.h"
#endif

#ifdef SCPI_ENABLE
struct selfMonitor* myMonitor;
#ifdef _WIN32
typedef enum ScpiClientErrorCode SCPIErrorCodes;
SCPIErrorCodes retValSCPI;
struct scpi_Client* myClient;
#endif /**_WIN32**/
#endif

/********************************************** Interface Datatypes **********************************************/

typedef struct natAgentHdle_T {
#if 0
	Sys_Char *pPrmHlth;
	Sys_Char *pPrmEnv;
	Sys_Char *pPrmUtiSCPI;
	Sys_Char *pPrmUtiOS;
#else
	pParam_Health pPrmHlth;
	pParam_Environment pPrmEnv;
	pParam_Utilization_SCPI pPrmUtiSCPI;
	pParam_Utilization_OS pPrmUtiOS;
#endif
}natAgentHdle, *pnatAgentHdle;

#ifdef KEYBOARD_MOUSE_HOOK   /* Enable this flag to use theKeyboard & mouse hook thread i.e struct natAgentThrd_T */
typedef struct natAgentThrd_T {
	pSysThreadStruct pThrdStrct; /**< Thread structure per handle */
	pParam_Utilization_OS pPrmUtiOS;
	SYS_MUTEX pMutHdl;
}natAgentThrd, *pnatAgentThrd;

pnatAgentThrd pNatThrdHdl;
#endif /* KEYBOARD_MOUSE_HOOK */

configparam *pgNatConf;


#ifdef WIN32
HHOOK hKeyboardHook;
HHOOK hMouseHook;
HINSTANCE hins;
#endif /**WIN32**/

/********************************************** Interface APIs **********************************************/

NativeErrCodes natAgent_GetHealthData_SCPI (
	pParam_Health *ppPrm /**< Actual parameters data */
	);

NativeErrCodes natAgent_GetEnvironmentData_SCPI (
	pParam_Environment *ppPrm /**< Actual parameters data */
	);

NativeErrCodes natAgent_GetUtilizationData_SCPI (
	pParam_Utilization_SCPI *ppPrm /**< Actual parameters data */
	);

NativeErrCodes natAgent_GetUtilizationData_OS (
	pParam_Utilization_OS *ppPrm /**< Actual parameters data */
	);
#ifdef WIN32
LRESULT CALLBACK KeyboardProc(
	Sys_Int nCode, 
	WPARAM wParam, 
	LPARAM lParam
	);
DWORD WINAPI NatAgent_CreateKMhook(void* pVoid);
NativeErrCodes NatAgent_DestroyKMhook();
#endif


#endif  // __NATIVE_AGENT_UTILS_H__
