//EMS_Agent.cpp : Defines the entry point for the console application.
#include "Sysapi.h"
#include "SysLog.h"
#include "Native_Agent.h"
#include "Native_Agent_Utils.h"

// CWU: Use Self_Monitor Hook instead. Self_Monitor will take care of piping out results and return with the right data
//#undef KEY_HOOK 

LRESULT CALLBACK KeyboardProc(Sys_Int nCode, WPARAM wParam, LPARAM lParam)
{
	Sys_Char *function = "CALLBACK KeyboardProc()";
	Sys_Char *pTmpArr = NULL;
	Sys_Ret_t sysRet = SYS_RET_OK;
	LRESULT RetVal;

	if ((nCode == HC_ACTION) &&
		((wParam == WM_SYSKEYDOWN) ||
		(wParam == WM_KEYDOWN)))
	{
		pTmpArr = (Sys_Char *)Sys_Calloc(TIMESTMAMP_LENGTH);
		Sys_StringnCpy(pTmpArr, "yyyy-mm-dd hh-mm-ss  ", (TIMESTMAMP_LENGTH - 1), TIMESTMAMP_LENGTH);
		sysRet = Sys_GetTimeStamp(pTmpArr, "%Y-%m-%d %H:%M:%S", 80, 1, 1);
		if (sysRet != SYS_RET_OK) {
			SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: failed to retrieve timestamp!", function);
		}
		else {
			SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: SysTime- %s", function, pTmpArr);
			SysMutex_Lock(pNatThrdHdl->pMutHdl);
			Sys_StringnCpy(pNatThrdHdl->pPrmUtiOS->puKeybrd, pTmpArr, Sys_StringLength(pTmpArr), TIMESTMAMP_LENGTH);
			SysMutex_Unlock(pNatThrdHdl->pMutHdl);
		}

		if (pTmpArr) {
			Sys_Free(pTmpArr);
			pTmpArr = NULL;
		}
	}

	RetVal = CallNextHookEx(hKeyboardHook, nCode, wParam, lParam);

	return  RetVal;
}

LRESULT CALLBACK MouseEvent(Sys_Int nCode, WPARAM wParam, LPARAM lParam)
{
	Sys_Char *function = "CALLBACK MouseEvent()";
	Sys_Ret_t sysRet = SYS_RET_OK;
	Sys_Char *pTmpArr = NULL;
	LRESULT RetVal;

	if ((nCode == HC_ACTION) &&
		((wParam == WM_LBUTTONDOWN) ||
		(wParam == WM_MBUTTONDOWN) ||
		(wParam == WM_RBUTTONDOWN)))
	{

		pTmpArr = (Sys_Char *)Sys_Calloc(TIMESTMAMP_LENGTH);
		Sys_StringnCpy(pTmpArr, "yyyy-mm-dd hh-mm-ss  ", (TIMESTMAMP_LENGTH - 1), TIMESTMAMP_LENGTH);
		sysRet = Sys_GetTimeStamp(pTmpArr, "%Y-%m-%d %H:%M:%S", 80, 1, 1);
		if (sysRet != SYS_RET_OK) {
			SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: failed to retrieve timestamp!", function);
		}
		else {
			SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: SysTime- %s", function, pTmpArr);
			SysMutex_Lock(pNatThrdHdl->pMutHdl);
			Sys_StringnCpy(pNatThrdHdl->pPrmUtiOS->puMouse, pTmpArr, Sys_StringLength(pTmpArr), TIMESTMAMP_LENGTH);
			SysMutex_Unlock(pNatThrdHdl->pMutHdl);
		}

		if (pTmpArr) {
			Sys_Free(pTmpArr);
			pTmpArr = NULL;
		}
	}

 RetVal = CallNextHookEx(hMouseHook, nCode, wParam, lParam);

	return  RetVal;

}

#ifdef WIN32
DWORD WINAPI NatAgent_CreateKMhook(void* pVoid)
#else
void* NatAgent_CreateKMhook(void* pVoid)
#endif
{
	NativeErrCodes retVal = NATIVE_SUCCESS;
	MSG message;
	Sys_Bool bRet;

	Sys_Char *function = "NatAgent_GetKMhook";

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: entered.", function);

	hKeyboardHook = NULL;
	hMouseHook = NULL;
	hins = NULL;
	hins = GetModuleHandle(NULL);

#ifdef KEY_HOOK

	hKeyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyboardProc, NULL, 0);
	if (hKeyboardHook == NULL)
	{
		retVal = NATIVE_KEY_HOOK_ERROR;
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Key hook not installed!", function);
		return -1;
	}

#else //Just a stub when KEY_HOOK is disabled
	SysMutex_Lock(pNatThrdHdl->pMutHdl);
	Sys_StringnCpy(pNatThrdHdl->pPrmUtiOS->puKeybrd, "yyyy-mm-dd hh-mm-ss", Sys_StringLength("yyyy-mm-dd hh-mm-ss"), TIMESTMAMP_LENGTH);
	SysMutex_Unlock(pNatThrdHdl->pMutHdl);

#endif

#ifdef MOUSE_HOOK     //TODO:Disabled for debugging.Enable in preprocessor to get the mouse hook

	hMouseHook = SetWindowsHookEx(WH_MOUSE_LL, MouseEvent, NULL, 0);

	if (hMouseHook == NULL)
	{
		retVal = NATIVE_MOUSE_HOOK_ERROR;
		SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: Mouse hook not installed!!", function);
		return -1;
	}

#else //Just a stub when MOUSE_HOOK is disabled.
	SysMutex_Lock(pNatThrdHdl->pMutHdl);
	Sys_StringnCpy(pNatThrdHdl->pPrmUtiOS->puMouse, "yyyy-mm-dd hh-mm-ss", Sys_StringLength("yyyy-mm-dd hh-mm-ss"), TIMESTMAMP_LENGTH);
	SysMutex_Unlock(pNatThrdHdl->pMutHdl);

#endif

	while ((bRet = GetMessage(&message, NULL, 0, 0)) != 0) {
		if (bRet == -1) {
			retVal = NATIVE_HOOK_MSG_ERROR;
			SysAppLog(SYS_ERROR, MODULE_NATIVE_AGENT, "%s: GetMessage(&message, NULL, 0, 0) failed !", function);
			return -1;
		}
		else if (bRet == 1) {
			TranslateMessage(&message);
			DispatchMessage(&message);
		}
	}

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: exited.", function);

	return 0;
}

NativeErrCodes NatAgent_DestroyKMhook()
{
	NativeErrCodes retVal = NATIVE_SUCCESS;
	Sys_Char *function = "NatAgent_DestroyKMhook";

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: entered.", function);
#ifdef KEY_HOOK

	if (hKeyboardHook)
		UnhookWindowsHookEx(hKeyboardHook);

#endif	

#ifdef MOUSE_HOOK

	if (hMouseHook)
		UnhookWindowsHookEx(hMouseHook);
#endif

	if (pNatThrdHdl)
		PostThreadMessage(pNatThrdHdl->pThrdStrct->m_threadId, WM_QUIT, 0, 0);

	SysAppLog(SYS_DEBUG, MODULE_NATIVE_AGENT, "%s: exited.", function);
	return retVal;
}