//*****************************************************************************
//
//  Copyright © 2016 ITC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  Native_Agent.h
//  
//  Subsystem  :  Native_Agent
//
//  Description:  Interface Header file for Native Agent.   
//
//*****************************************************************************

#ifndef __NATIVE_AGENT_H__
#define __NATIVE_AGENT_H__

//#include "Systypes.h"
#include "EMS_Config.h"

/********************************************** Interface Datatypes **********************************************/
#define NATIVE_AGENT_VERSION "0.0.1" /**< version.major.minor */
#define STR_FILE_UTILS_JSON "Utilization.json"
#define STR_FILE_HEALTH_JSON "Health.json"
#define STR_FILE_ENV_JSON "Environment.json"
#define STR_FILE_INFO_JSON "Information.json"

#define CONFIG_FOLDER_NAME "Config_Files"
#define PAYLOAD_FOLDER_NAME "Payloads"

typedef void *pNatHdl;

typedef enum Native_Error_Codes_T {
	NATIVE_SUCCESS = 0, /**< No error */
	NATIVE_INSUFFICIENT_MEMORY = -1, /**< Memory allocation failed */
	NATIVE_WRONG_IP_PARAMS = -2, /**< Wrong input parameters passed */
	NATIVE_SYSTEM_ERROR = -3, /**< Some issue with system/platform */
	NATIVE_KEY_HOOK_ERROR = -4, /*< Failure in installing key hook */
	NATIVE_MOUSE_HOOK_ERROR = -5, /*< Failure in installing mouse hook */
	NATIVE_HOOK_MSG_ERROR = -6,   /*< Failure in getmessage hook */
	NATIVE_KEYHOOK_SOCKET_ERROR = -7 /*< Failure in get Keyhook socket */
}NativeErrCodes;

typedef enum Param_Source_T {
	SCPI_INT, /**< Parameters retrieved through SCPI interface/source */
	OS_INT /**< Parameters retrieved through OS calls/interface */
}Param_Source;

typedef enum Param_Type_T {
	PRM_HEALTH_SCPI,
	PRM_HEALTH_OS,
	PRM_ENVIRONMENT_SCPI,
	PRM_ENVIRONMENT_OS,
	PRM_UTILIZATION_SCPI,
	PRM_UTILIZATION_OS,
	PRM_INFORMATION_SCPI,
	PRM_INFORMATION_OS
}Param_Type;

/** Health Parameters */
typedef struct HBattery_T {
	Sys_Double hLifeRemain; /**< Battery life remaining in %. */
	Sys_Int hCycles; /**< Battery life remaining in cycles. >= 0 */
}HBattery;

typedef struct HMemory_T {
	Sys_Double hBytesAvail; /**< Available bytes in memory */
	Sys_Double hBytesUsed; /**< Used bytes in memory */
	Sys_Char *phOSVer; /**< OS Version. */
}HMemory;

typedef struct HMotor_T {
	Sys_Int hRevolut; /**< Revolutions, > 0 */
	Sys_Int hMovements; /**< Movements, >= 0 */
	Sys_Int hMovTime; /**< Moving Time, >= 0 */
	Sys_Int hOnTime; /**< Hours, >= 0 */
}HMotor;

typedef struct Param_Health_T {
	Asset_Details hAstDet; /**< Asset specific details */
	Param_Source hPrmSrc; /**< Source of these parameter retrievals */
	Sys_Int hAttenuator; /**< Attenuator in cycles. >= 0 */
	HBattery hBattery;  
	Sys_Double hDefinedPart; /**< Defined by Instrument. */
	Sys_Int hDisplay; /**< Hours, >= 0 */
	Sys_Int hLaser; /**< Hours, >= 0 */
	HMemory hMemory;
	HMotor hMotor;
	Sys_Int hOutput; /**< Hours, >= 0 */
	Sys_Int hPart; /**< Hours, >= 0 */
	Sys_Int hProduct; /**< Hours, >= 0 */
	Sys_Int hSwitch; /**< Cycles, >= 0*/
}Param_Health, *pParam_Health;

/** Environment Parameters */
typedef struct EAccelerometer_T {
	Sys_Char *eXAxis; /**< Side to side */
	Sys_Char *eYAxis; /**< Top to bottom */
	Sys_Char *eZAxis; /**< Front to back */
}EAccelMet;

typedef struct Param_Environment_T {
	Asset_Details eAstDet; /**< Asset specific details */
	Param_Source ePrmSrc; /**< Source of these parameter retrievals */
	EAccelMet eAccelMet; /**< Accelerometer */
	Sys_Double eCurrSens; /**< Current Sensor in ampere */
	Sys_Double eHumidSens; /**< Humidity Sensor in % RH */
	Sys_Double eLightSens; /**< Light Sensor in Lux */
	Sys_Double ePressSens; /**< Pressure Sensor in millibars */
	Sys_Double eTempSens; /**< Temperature Sensor in degrees c */
	Sys_Double eVoltSens; /**< Voltage Sensor in volts */
}Param_Environment, *pParam_Environment;

/** Utilization Parameters */
typedef struct Param_Utilization_SCPI_T {
	Asset_Details uAstDet; /**< Asset specific details */
	Param_Source uPrmSrc; /**< Source of these parameter retrievals */
	Sys_Char *puFrntPanl; /**< Front Panel in Hours Used. Timestamp - <yyyy-mm-dd hh-mm-ss> */
	Sys_Bool uLicense; /**< Licenses. Active – true – 1, Inactive – false - 0 */
	Sys_Char *puSCPI; /**< SCPI. Timestamp - <yyyy-mm-dd hh-mm-ss> */
}Param_Utilization_SCPI, *pParam_Utilization_SCPI;

typedef struct Param_Utilization_OS_T {
	Asset_Details uAstDet; /**< Asset specific details */
	Param_Source uPrmSrc; /**< Source of these parameter retrievals */
	Sys_Char *puKeybrd; /**< Timestamp for Keyboard clicks. Timestamp - <yyyy-mm-dd hh-mm-ss> */
	Sys_Char *puMouse; /**< Timestamp for Mouse or Touchscreen clicks. Timestamp - <yyyy-mm-dd hh-mm-ss> */
}Param_Utilization_OS, *pParam_Utilization_OS;


/********************************************** Interface APIs **********************************************/

NativeErrCodes NatAgent_Init (
	void **ppHdl /**< Opaque handle to be registered */
	);
NativeErrCodes scpi_restart();

NativeErrCodes NatAgent_Uninit (
	void *pHdl /**< Handle */
	);

NativeErrCodes NatAgent_GetData (
	void *pHdl, /**< Opaque handle */
	Param_Type *pPrmTyp, /**< Type of parameter to be retrieved */
	Param_Source *pPrmSrc, /**< Source of parameter */
	void *pStrToSend, /**< String to be populated with Native data */
	Sys_Ulong *Buffer_Length /**< Length of pStrToSend */
	);

NativeErrCodes NatAgent_SetConfigData(
	configparam *pConfig
	);


#ifdef KEYHOOK_PROC

Sys_Bool keyHookHelper;
NativeErrCodes Socket_Init(void); /**< Initializing socket */

NativeErrCodes Socket_UnInit(void); /**< Uninitiaizing socket */

NativeErrCodes KeyMouseHook(Sys_Char *recvBuf); /**< Function to get timestamp from helper */

#endif

#endif  // __NATIVE_AGENT_H__
