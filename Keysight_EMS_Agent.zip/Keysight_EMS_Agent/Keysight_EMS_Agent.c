/*****************************************************************************
//
//  Copyright © 2016 ITC .  All rights reserved.
//
******************************************************************************
//
//  Filename   :  main.c
//
//  Subsystem  :  KeySight
//
//  Description: Main program file for KeySight project
//
******************************************************************************/

#include "twApi.h"
#ifdef WIN32
#include "SysWindows-openssl.h"
#else
#include "SysLinux-openssl.h"
#endif /*Contains macro for TW_MALLOC,TW_FREE*/

#include "SysOSPort.h"
#include "cJSON.h"
#include "EMS_Config.h"
#include "Properties.h"
#include "Services.h"
#include "JsonObjectCreator.h"
#include <string.h>
#ifndef WINCE
#include <signal.h>     
#endif  /**WINCE**/
#include "SysLog.h"
#include "Sysapi.h"
#include "EMS_Agent.h"
#include "openssl/crypto.h"
#include "Keysight_EMS_Agent.h"
#include "FileWatcher.h"

#ifndef WINCE
#include "OS_Utilities.h"
#endif

/*
* All global variables and constants to be declared here
* */
#define FILE_WATCHER_RATE_MSEC 5000
#define DATA_UPDATION_RATE_MSEC 5000
#define STR_FILE_WS_CONNECTION "Config.json"
#define CONFIG_FOLDER_NAME "Config_Files"
#define STR_FILE_DUMP_SUCCESS ".dump_success.bin"
#define STR_FILE_DUMP_FAIL ".dump_fail.bin"
#ifdef WIN32
#define DUMP_FOLDER_NAME "SideCar_EMS\\Downloads\\updates"
#else
#define DUMP_FOLDER_NAME "SideCar_EMS/Downloads/updates"
#endif

#ifdef WINCE
Sys_Char logFolderBuf[MAX_PATH];
#endif


#ifdef KEYHOOK_PROC
keyHookHelper = TRUE;
#endif

Sys_Int INTR_FLAG = 1;
Sys_Int logType = 0;
#define LOG_TYPE_VERBOSE 1
#define LOG_TYPE_DEBUG 2

static keySightEHdle pEAHdl = NULL; /**< EMS Agent Handle */
static keySightEHdle pECHdl = NULL; /**< EMS Config handle */

/** Main **/
Sys_Int main(Sys_Int argc, Sys_Char **argv)
{
	KeysightEMSErrCodes retVal = KEYSIGHT_EMS_SUCCESS;
	Sys_Char *function = "main()";
	Sys_Int i = 0 ;
	Sys_Int flag = 0;
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: entered.", function);

//Fix for the jira AA-430 
#ifdef WIN32
#ifndef WINCE
	for(i = 1; i<argc; i++){
		if ((!strcmp(argv[i], "-VERBOSE") || !strcmp(argv[i], "-verbose") || !strcmp(argv[i], "-V") || !strcmp(argv[i], "-v")) && flag == 0) {
			logType = LOG_TYPE_VERBOSE;
			flag++;
		}
		else if ((!strcmp(argv[i], "-DEBUG") || !strcmp(argv[i], "-debug") || !strcmp(argv[i], "-D") || !strcmp(argv[i], "-d")) && flag == 0) {
			logType = LOG_TYPE_DEBUG;
			flag++;
		}
		else if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "-H") || !strcmp(argv[i], "-help") || !strcmp(argv[i], "-HELP")) {
			printf("-V/-v OR -VERBOSE/-verbose for Verbose logs\n");
			printf("-D/-d OR -DEBUG/-debug for Debug logs\n");
			printf("NOTE: Do not use -debug/-verbose at a time\n");
			printf("-VERSION/-version for Version Information\n");
			printf("-i/-inpuinfo: pass true/false to enable/disable the EMSHelepr code respectively\n");
			goto failCall;
		}
		else if (!strcmp(argv[i], "-version") || !strcmp(argv[i], "-VERSION")) {
			printf("****************************************************************************\n");
			printf("Keysight Version : %s\n", KEYSIGHT_VERSION);
			printf("Thingworx SDK Version : %s\n", twApi_GetVersion());
			printf("OpenSSL Version : %s\n", SSLeay_version(SSLEAY_VERSION));
			printf("****************************************************************************\n");
			goto failCall;
		}

#ifdef KEYHOOK_PROC
		else if (!strcmp(argv[i], "-i") || !strcmp(argv[i], "-inputinfo")) {
			if (i == argc - 1) {
				printf("Error: inputinfo is given but no value is specified.\n");
				goto failCall;
			}
			else if (!strcmp(argv[i + 1], "true") || !strcmp(argv[i + 1], "True") || !strcmp(argv[i + 1], "TRUE")) {
				keyHookHelper = TRUE;
				i++;
			}
			else if (!strcmp(argv[i + 1], "false") || !strcmp(argv[i + 1], "False") || !strcmp(argv[i + 1], "FALSE")) {
				keyHookHelper = FALSE;
				i++;
			}
			else {
				printf("Error: Invalid value for -i/-inputinfo.\n");
				printf("Please give either true or false.\n");
				goto failCall;
			}
		}
#endif
		else {
			printf("Wrong Command Line Parameters. Try the below Arguments for the help menu:\n");
			printf("NOTE: Do not use -debug/-verbose at a time\n");
			printf("-H/-h OR -HELP/-help\n");
			goto failCall;
		}
	}
	if(argc == 1 || ((!strcmp(argv[1], "-i") || !strcmp(argv[1], "-inputinfo"))) && argc != 4)
		ShowWindow(GetConsoleWindow(), SW_HIDE);
#endif
#endif
	
	// Do system initialization.
	retVal = EMS_Initialize();
	if(retVal != KEYSIGHT_EMS_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: EMS_Initialize() failed!", function);
		goto failCall;
	}

	// Start the system.  Connection must be established in Start.
	retVal = EMS_Start();
	if(retVal != KEYSIGHT_EMS_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: EMS_Start() failed!", function);
		goto failCall;
	}
#ifndef WINCE   
#ifdef WIN32 //Need to check if this same works in Linux
	signal(SIGINT, IntHandler);  //Commented the code for wince
#else //Same as for Linux
	signal(SIGINT, IntHandler);
#endif   /**WIN32**/
#endif  /**WINCE**/
	// do a clean shutdown 
	EMSWait(); //TODO: Vishal: Ideally should be called after failCall tag.
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: exited.", function);

failCall:
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: exited with failure!.", function);
	exit(0);
}


//Signal handler for Ctrl+C interrupt  
void  IntHandler(int sig)
{
	Sys_Char *function = "IntHandler()";
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: Entered.", function);
#ifndef WINCE
	signal(sig, SIG_IGN); //To Ignore the same signal while the ISR is handled   //Commented code for wince 
#endif  /**WINCE**/
	INTR_FLAG = 0; //To break the While loop
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: Exiting after handling the Interrupt.", function);

}

// Private functions 
// ****************************************************************************
KeysightEMSErrCodes StartUpBanner()
{
	SysLogErrCodes sysLogRetVal = SYSLOG_SUCCESS;
	sysLogRetVal= SysAppLog(SYS_INFO, MODULE_KEYSIGHT_EMS_AGENT,
		"****************************************************************************");
	if (sysLogRetVal != SYSLOG_SUCCESS)
	{
		sysLogRetVal = KEYSIGHT_SYS_LOG_FAILURE;
		printf("Unable to create the 1st logging file \n ");
		return sysLogRetVal;
	}
	
	SysAppLog(SYS_INFO, MODULE_KEYSIGHT_EMS_AGENT, "KeySightVersion:  %s", KEYSIGHT_VERSION);
	SysAppLog(SYS_INFO, MODULE_KEYSIGHT_EMS_AGENT, "ThingWorx SDK version:  %s", twApi_GetVersion());
	SysAppLog(SYS_INFO, MODULE_KEYSIGHT_EMS_AGENT, "OpenSSL version:  %s", SSLeay_version(SSLEAY_VERSION));

	SysAppLog(SYS_INFO, MODULE_KEYSIGHT_EMS_AGENT,
		"****************************************************************************\n");
	return sysLogRetVal;
}

/*Initialize*/
KeysightEMSErrCodes EMS_Initialize()
{
	SysLogErrCodes sysLogRetVal = SYSLOG_SUCCESS;
	ConfigErrCodes confRetVal = CONFIG_SUCCESS;
	EMSAgentErrCodes emsAgtRetVal = EMSAGENT_SUCCESS;
	KeysightEMSErrCodes retVal = KEYSIGHT_EMS_SUCCESS;
	Sys_Char *function = "EMS_Initialize";
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: entered.", function);

//Logger must be initialized 1st.
#ifndef WINCE
	Sys_Char *pszLoggFilePath = GetFilePathByName(LOGGER_FOLDER_NAME, STR_LOG_FILE_NAME);
    sysLogRetVal = SysLog_Init(pszLoggFilePath);
#else
	sprintf(logFolderBuf, "%s%s%s%s",WINCE_LOG_MSG_ROOT_FOLDER,LOGGER_FOLDER_NAME, TW_FILE_DELIM_STR, STR_LOG_FILE_NAME);
	sysLogRetVal = SysLog_Init(logFolderBuf);
#endif

//Fix for the jira AA-430 
	if (logType == LOG_TYPE_VERBOSE) //For all logs
		twLogger_SetLevel((enum SysLogLevel) SYS_INFO);
	else if (logType == LOG_TYPE_DEBUG) { 
		twLogger_SetLevel((enum SysLogLevel) SYS_TRACE);
		twLogger_SetIsVerbose(TRUE);
	}
	else
		twLogger_SetLevel((enum SysLogLevel) SYS_INFO);
	twLogger_SetFunction(SysTwLog);

	if (sysLogRetVal != SYSLOG_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: SysLog_Init() failed!", function);
		retVal = KEYSIGHT_SYS_LOG_FAILURE;
		goto failCall;
	}
	
	retVal = StartUpBanner();
	if (retVal != KEYSIGHT_EMS_SUCCESS) {
		retVal = KEYSIGHT_SYS_LOG_FAILURE;
		goto failCall;
	}
	confRetVal = EMSConfig_Init(&pECHdl);
	if(confRetVal != CONFIG_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: EMSConfig_Init() failed!", function);
		retVal = KEYSIGHT_EMS_CONFIG_FAIL;
		goto failCall;
	}

	/*Thread Initialization - Start*/
	emsAgtRetVal = EMSAgent_Init(&pEAHdl);
	if (emsAgtRetVal != EMSAGENT_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: EMSAgent_Init() failed!", function);
		retVal = KEYSIGHT_EMS_AGENT_FAIL;
		goto failCall;
	}
	/*Thread Initialization - End*/
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: exited", function);
	return retVal;

failCall:
	SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: exited with failure!", function);
	return retVal;
}

// ****************************************************************************
KeysightEMSErrCodes EMS_Start()
{	
	//commenting to supress the warning of unused variable
	//Sys_Int err = TW_OK;
	KeysightEMSErrCodes retVal = KEYSIGHT_EMS_SUCCESS;
	EMSAgentErrCodes emsAgtRetVal = EMSAGENT_SUCCESS;
	ConfigErrCodes configRetVal = CONFIG_SUCCESS;
	Sys_Char *function = "EMS_Start";
	EMSAgent_ThreadType thrTyp = EMSAGNT_IDLE;

	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: entered.", function);
	
	configRetVal = EMSConfig_Start(pECHdl);
	if (configRetVal != CONFIG_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: Post EMSConfig_Start() failed!", function);
		retVal = KEYSIGHT_EMS_AGENT_FAIL;
		goto failCall;
	}

	thrTyp = EMSAGNT_POST_THRD;
	emsAgtRetVal = EMSAgent_Start(pEAHdl, thrTyp);
	if (emsAgtRetVal != EMSAGENT_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: Post EMSAgent_Start() failed!", function);
		retVal = KEYSIGHT_EMS_AGENT_FAIL;
		goto failCall;
	}

	thrTyp = EMSAGNT_ACQUISTION_THRD;
	emsAgtRetVal = EMSAgent_Start(pEAHdl, thrTyp);
	if (emsAgtRetVal != EMSAGENT_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: Acquisition EMSAgent_Start() failed!", function);
		retVal = KEYSIGHT_EMS_AGENT_FAIL;
		goto failCall;
	}
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: exited ", function);
	return retVal;

failCall:
	SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: exited with failure!", function);
	return retVal;
}

/*
* Waits for shutdown with 'q' as escape character to quit gracefully.
* */
KeysightEMSErrCodes EMSWait()
{
	KeysightEMSErrCodes retVal = KEYSIGHT_EMS_SUCCESS;
	Sys_Char *function = "EMSWait()";
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: entered.", function);
	Sys_time_t config_last_modified_time = 0;
	Sys_time_t config_current_modified_time = 0;
	Sys_Char *pszConfigFilePath = NULL;
	Sys_Char *pszDumpFilePathSuccess = NULL;
	Sys_Char *pszDumpFilePathFail = NULL;
	
	pszDumpFilePathSuccess = GetFilePathByName(DUMP_FOLDER_NAME, STR_FILE_DUMP_SUCCESS);
	pszDumpFilePathFail = GetFilePathByName(DUMP_FOLDER_NAME, STR_FILE_DUMP_FAIL);
	pszConfigFilePath = GetFilePathByName(CONFIG_FOLDER_NAME, STR_FILE_WS_CONNECTION);
	config_last_modified_time = SYS_Get_Mtime(pszConfigFilePath);
	while (INTR_FLAG) // && ThingnameValidation()) //Reverting the changes of Revision 461
	{

#ifndef ENABLE_TASKER
		//DATETIME nextDataCollectionTime = 0;
		//DATETIME now = twGetSystemTime(TRUE);

		//TW_LOG(TW_DEBUG, "emsShutdown: Inside ifdef ENABLE_TASKER");

		//twApi_TaskerFunction(now, NULL);
		//twMessageHandler_msgHandlerTask(now, NULL);

		//if (twTimeGreaterThan(now, nextDataCollectionTime))
		//{
		//	//dataCollectionTask(now, NULL);
		//	nextDataCollectionTime = twAddMilliseconds(now,
		//		DATA_UPDATION_RATE_MSEC);
		//}
#else //ENABLE_TASKER

		//Sys_Char in = 0;
		//SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: Inside else ENABLE_TASKER", function);
		//in = Sys_Getch();
		//if (in == 'q') break;
		//else printf("\n");

#endif //ENABLE_TASKER
		config_current_modified_time = SYS_Get_Mtime(pszConfigFilePath);
		if (!config_current_modified_time)
			SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "\n%s: Error in reading last modified time of Config.json.", function);
		else if (config_current_modified_time != config_last_modified_time) {
			retVal = configChangeCallback(CONFIG_FOLDER_NAME, STR_FILE_WS_CONNECTION);
			if (retVal != KEYSIGHT_EMS_SUCCESS) {
				if (retVal == (enum KeysightEMSError_Codes_T)CONFIG_FW_ERROR) // typecasted it as part of warning fix 
					INTR_FLAG = FALSE;  //Stop the Agent as there was change in Static Params
				else
					SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "\n%s: File Transfer Failed. Error Code: %d\n", function, retVal);
			}
			else
				SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "%s: Dynamic Params change", function);
			config_last_modified_time = config_current_modified_time;
		}

		//SideCar/LSR Automatic Stop Functionality
		if (!dumpFileDetect(pszDumpFilePathSuccess)) {
			retVal = StopSideCarFunction(pszDumpFilePathSuccess);
			if (!retVal)
				SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: SCM functionality Success. SideCar/LSR stopped", function);
		}
		if (!dumpFileDetect(pszDumpFilePathFail)) {
			retVal = StopSideCarFunction(pszDumpFilePathFail);
			if (!retVal)
				SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: SCM functionality Failed. SideCar/LSR stopped", function);
		}

		SysSleepMsec(5);
	}
	if (pszConfigFilePath) {
		Sys_Free(pszConfigFilePath);
		pszConfigFilePath = NULL;
	}
	if (pszDumpFilePathSuccess) {
		Sys_Free(pszDumpFilePathSuccess);
		pszDumpFilePathSuccess = NULL;
	}
	if (pszDumpFilePathFail) {
		Sys_Free(pszDumpFilePathFail);
		pszDumpFilePathFail = NULL;
	}

	retVal = EMSShutdown();
	if (retVal != KEYSIGHT_EMS_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: EMSShutdown() failed!", function);
		retVal = KEYSIGHT_EMS_SHUTDOWN_FAIL;
	}
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: exited.", function);

	SysLog_Uninit();	   /*Logging Shutdown*/

	return retVal;
}

Sys_Int dumpFileDetect(Sys_Char *dumpFilePath)
{
	Sys_Int retVal = KEYSIGHT_EMS_SUCCESS;
	FILE *fd = SYS_FOPEN(dumpFilePath, "rb");
	if (fd) {
		retVal = KEYSIGHT_EMS_SUCCESS;
		SYS_FCLOSE(fd);
	}
	else
		retVal = KEYSIGHT_EMS_CONFIG_FAIL;
	return retVal;
}

//Shutdown Procedure
//TODO: Is this Function really required in the future.
KeysightEMSErrCodes EMSShutdown()
{
	KeysightEMSErrCodes retVal = KEYSIGHT_EMS_SUCCESS;
	Sys_Char *function = "EMSShutdown";
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: entered.", function);
   
   /*shutdown function called*/
   retVal = EMSStop();
   if(retVal != KEYSIGHT_EMS_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: EMSStop() failed!", function);
		retVal = KEYSIGHT_EMS_SHUTDOWN_FAIL;
	}
   SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: exited.", function);
   return retVal;
}

/*Shutdown-cleanup function*/
KeysightEMSErrCodes EMSStop()
{
	KeysightEMSErrCodes retVal = KEYSIGHT_EMS_SUCCESS;
	EMSAgentErrCodes emsAgtRetVal = EMSAGENT_SUCCESS;
	Sys_Char *function = "EMSStop";
	ConfigErrCodes confRetVal = CONFIG_SUCCESS;
	EMSAgent_ThreadType thrTyp = EMSAGNT_IDLE;
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: entered.", function);
	SysAppLog(SYS_FORCE, MODULE_KEYSIGHT_EMS_AGENT, "Shutting down Keysight EMS- \"I will be back\"");

	/**< EMS Agent Acquistion Thread Stop */
	thrTyp = EMSAGNT_ACQUISTION_THRD;
	emsAgtRetVal = EMSAgent_Stop(pEAHdl, thrTyp);
	if (emsAgtRetVal != EMSAGENT_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: Acquisition - EMSAgent_Stop() failed!", function);
		retVal = KEYSIGHT_EMS_AGENT_ACQ_FAIL;
	}

	/**< EMS Agent Post Thread Stop */
	thrTyp = EMSAGNT_POST_THRD;
	emsAgtRetVal = EMSAgent_Stop(pEAHdl, thrTyp);
	if (emsAgtRetVal != EMSAGENT_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: Posting - EMSAgent_Stop() failed!", function);
		retVal = KEYSIGHT_EMS_AGENT_POST_FAIL;
	}

	/**< EMS Agent Uninitialize*/
	emsAgtRetVal = EMSAgent_Uninit(pEAHdl);  
	if (emsAgtRetVal != EMSAGENT_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: EMSAgent_Uninit() failed!", function);
		retVal = KEYSIGHT_EMS_AGENT_FAIL;
	}

	/**< Config Stop */
	confRetVal = EMSConfig_Stop(pECHdl);
	if (confRetVal != CONFIG_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: Posting - EMSConfig_Stop() failed!", function);
		retVal = KEYSIGHT_EMS_CONFIG_STOP_FAIL;
	}

	/**< Config UnInitialize */
	confRetVal = EMSConfig_Uninit(pECHdl);
	if(confRetVal != CONFIG_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: Posting - EMSConfig_Uninit() failed!", function);
		retVal = KEYSIGHT_EMS_CONFIG_UNINIT_FAIL;
	}
	
	SysAppLog(SYS_DEBUG, MODULE_KEYSIGHT_EMS_AGENT, "%s: exited.", function);

	return retVal;
}
