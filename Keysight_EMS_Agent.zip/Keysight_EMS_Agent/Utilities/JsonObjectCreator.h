/*****************************************************************************
//
//  Copyright © 1985-2016 ITC.  All rights reserved.
//
******************************************************************************
//
//  Filename   : JsonObjectCreator.h 
//
//  Subsystem  : Keysight
//
//  Author     : Akshata N
//
//  Description:
//
//
******************************************************************************/
#ifndef JSONOBJECTCREATOR_H_
#define JSONOBJECTCREATOR_H_

#include "Native_Agent.h"
#include "cJSON.h"

typedef enum Utilities_Error_Codes_T {
	UTILITIES_SUCCESS = 0, /**< No error */
	UTILITIES_INSUFFICIENT_MEMORY = -1, /**< Memory allocation failed */
	UTILITIES_WRONG_IP_PARAMS = -2, /**< Wrong input/invalid parameters passed */
	UTILITIES_TWX_ERROR = -3, /**< Thingworx api/c-sdk related errors */
	UTILITIES_FILE_RW_ERROR = -4, /**< File read-write error */
}UtilitiesErrCodes;

void CleanUpJsonOBJ();
UtilitiesErrCodes FormJsonOBJFromStruct(void  *asset, cJSON **pJsonRoot, Param_Type DevicePro);
Sys_Char *GetAsseType(Sys_Int AssetType);

#endif /* JSONOBJECTCREATOR_H_ */



