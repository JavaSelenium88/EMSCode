/******************************************************************************
//
//  Filename   : JsonObjectCreator.h 
//
//  Subsystem  : Keysight
//
//  Author     : Akshata N
//
//  Description: 
//
//
******************************************************************************/
#include "twApi.h" /* added to remove the error throw by cJSON.h */
#ifdef WIN32
//#include "twWindows-openssl.h"
#include "SysWindows-openssl.h"
#else
//#include "twLinux-openssl.h"
#include "SysLinux-openssl.h"
#endif  /* added for the file operations (read write & open )  */

#include "JsonObjectCreator.h"

#include "Native_Agent.h"
#include "EMS_Config_Utils.h"
#include "SysLog.h"
#include <stdio.h>

// ToDo-Akshata 
cJSON *pJsonHealth = NULL;
cJSON *pJsonEnviorment = NULL;
cJSON *pjsonUtilization = NULL;

/* Local Methods */
UtilitiesErrCodes FormEnviormentJsonOBJFromStruct(pParam_Environment  pENV, cJSON **pJsonRoot);
UtilitiesErrCodes FormHealthJsonOBJFromStruct(pParam_Health pHealth, cJSON **pJsonRoot);
UtilitiesErrCodes FormUtilsSCPIJsonOBJFromStruct(pParam_Utilization_SCPI pUtils, cJSON **pJsonRoot);
UtilitiesErrCodes FormUtilsOSJsonOBJFromStruct(pParam_Utilization_OS pUtils, cJSON **pJsonRoot);
Sys_Char *GetSourceType(Sys_Int source);

Sys_Char *GetAsseType(Sys_Int AssetType)
{
	Sys_Char *function = "GetAsseType";
	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s: entered.", function);

	switch (AssetType)
	{
	case 0:
		return "ASSET";
		break;
	case 1:
		return "PLUM";
		break;
	case 2:
		return "SYSTEM_CONTROLLER";
		break;
	default:
		return "UNKNOWN";
		break;
	}

	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s: exited.", function);
}

Sys_Char *GetSourceType(Sys_Int source)
{
	Sys_Char *function = "GetAsseType";
	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s: entered.", function);

	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " GetSourceType() start");
	switch (source)
	{
	case 0:
		return "SCPI";
		break;
	case 1:
		return "OS";
		break;
	default:
		return "UNKNOWN";
		break;
	}

	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s: exited.", function);
}

UtilitiesErrCodes FormJsonOBJFromStruct(void  *asset, cJSON **pJsonRoot, Param_Type paramType)
{
	Sys_Char *function = "FormJsonOBJFromStruct";
	UtilitiesErrCodes retVal = UTILITIES_SUCCESS;
	pParam_Environment pEnviorment;
	pParam_Health pHealth;
	pParam_Utilization_SCPI pUtilsSCPI;
	pParam_Utilization_OS pUtilsOS;

	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s: entered.", function);
	switch (paramType)
	{
	case PRM_ENVIRONMENT_SCPI:
		pEnviorment = (pParam_Environment)asset;
		retVal= FormEnviormentJsonOBJFromStruct(pEnviorment, &(*pJsonRoot));
		break;
	case PRM_ENVIRONMENT_OS:
		pEnviorment = (pParam_Environment)asset;
		retVal= FormEnviormentJsonOBJFromStruct(pEnviorment, &(*pJsonRoot));
		break;
	case PRM_UTILIZATION_SCPI:
		pUtilsSCPI = (pParam_Utilization_SCPI)asset;
		retVal= FormUtilsSCPIJsonOBJFromStruct(pUtilsSCPI, &(*pJsonRoot));
		break;
	case PRM_UTILIZATION_OS:
		pUtilsOS = (pParam_Utilization_OS)asset;
		retVal= FormUtilsOSJsonOBJFromStruct(pUtilsOS, &(*pJsonRoot));
		break;
	case PRM_HEALTH_SCPI:
		pHealth = (pParam_Health )asset;
		retVal= FormHealthJsonOBJFromStruct(pHealth, &(*pJsonRoot));
		break;
	case PRM_HEALTH_OS:
		pHealth = (pParam_Health)asset;
		retVal= FormHealthJsonOBJFromStruct(pHealth, &(*pJsonRoot));
		break;
	default :
		break;
	}

	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s: exited.", function);
	return retVal;
}

UtilitiesErrCodes FormEnviormentJsonOBJFromStruct(pParam_Environment pENV, cJSON **pJsonRoot)
{
	cJSON *pJsonENV, *pJsonAsset, *pJsonAccelerometer;
	UtilitiesErrCodes retVal = UTILITIES_SUCCESS;
	Sys_Char *function = "FormEnviormentJsonOBJFromStruct";
	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s: entered.", function);

	*pJsonRoot = cJSON_CreateObject();
	pJsonAccelerometer = cJSON_CreateObject();
	pJsonENV = cJSON_CreateObject();
	pJsonAsset = cJSON_CreateObject();

	if (*pJsonRoot != NULL)
	{
		if (pJsonENV != NULL)
		{
			cJSON_AddItemToObject(*pJsonRoot, STR_ENV_PARAMS, pJsonENV);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		if(pJsonAsset!= NULL)
		{
			cJSON_AddItemToObject(pJsonENV, STR_DEVICE_ASSET, pJsonAsset);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		cJSON_AddStringToObject(pJsonENV, STR_DEVICE_SOURCE, GetSourceType(pENV->ePrmSrc));
		if (pJsonAccelerometer != NULL)
		{
			cJSON_AddItemToObject(pJsonENV, STR_ACCELEROMETER, pJsonAccelerometer );
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		cJSON_AddStringToObject(pJsonAsset, STR_DEVICE_ASSET_ID, pENV->eAstDet.pId);
		cJSON_AddStringToObject(pJsonAsset, STR_DEVICE_ASSET_TYPE, GetAsseType(pENV->eAstDet.Type));
		cJSON_AddStringToObject(pJsonAccelerometer, STR_XAXIS, pENV->eAccelMet.eXAxis);
		cJSON_AddStringToObject(pJsonAccelerometer, STR_YAXIS, pENV->eAccelMet.eYAxis);
		cJSON_AddStringToObject(pJsonAccelerometer, STR_ZAXIS, pENV->eAccelMet.eZAxis);
		cJSON_AddNumberToObject(pJsonENV, STR_CURRENT_SENSOR, pENV->eCurrSens);
		cJSON_AddNumberToObject(pJsonENV, STR_HUMIDITY_SENSOR, pENV->eHumidSens);
		cJSON_AddNumberToObject(pJsonENV, STR_LIGHT_SENSOR, pENV->eLightSens);
		cJSON_AddNumberToObject(pJsonENV, STR_PRESSURE_SENSOR, pENV->ePressSens);
		cJSON_AddNumberToObject(pJsonENV, STR_TEMPERATURE_SENSOR, pENV->eTempSens);
		cJSON_AddNumberToObject(pJsonENV, STR_VOLTAGE_SENSOR, pENV->eVoltSens);
	}
	else
	{
		retVal = UTILITIES_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s:pJsonRoot is NULL ", function);
	}
	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s: exited.", function);
	return retVal;
}

UtilitiesErrCodes FormHealthJsonOBJFromStruct(pParam_Health pHealth, cJSON **pJsonRoot)
{
	cJSON *pJsonHealth, *pJsonAsset, *pJsonBattery, *pJsonMemory, *pJsonMotor;
	UtilitiesErrCodes retVal = UTILITIES_SUCCESS;
	Sys_Char *function = "FormHealthJsonOBJFromStruct";
	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s : entered", function);

	*pJsonRoot = cJSON_CreateObject();
	pJsonHealth = cJSON_CreateObject();
	pJsonAsset = cJSON_CreateObject();
	pJsonBattery = cJSON_CreateObject();
	pJsonMemory = cJSON_CreateObject();
	pJsonMotor = cJSON_CreateObject();
	if (*pJsonRoot!= NULL)
	{
		if (pJsonHealth != NULL)
		{
			cJSON_AddItemToObject(*pJsonRoot, STR_HEALTH_PARAMS, pJsonHealth);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		if (pJsonAsset != NULL)
		{
			cJSON_AddItemToObject(pJsonHealth, STR_DEVICE_ASSET, pJsonAsset);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		cJSON_AddStringToObject(pJsonHealth, STR_DEVICE_SOURCE, GetSourceType(pHealth->hPrmSrc));
		if (pJsonBattery != NULL)
		{
			cJSON_AddItemToObject(pJsonHealth, STR_BATTERY, pJsonBattery);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		if (pJsonMemory)
		{
			cJSON_AddItemToObject(pJsonHealth, STR_MEMORY, pJsonMemory);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		if (pJsonMotor)
		{
			cJSON_AddItemToObject(pJsonHealth, STR_MOTOR, pJsonMotor);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		cJSON_AddStringToObject(pJsonAsset, STR_DEVICE_ASSET_ID, pHealth->hAstDet.pId);
		cJSON_AddStringToObject(pJsonAsset, STR_DEVICE_ASSET_TYPE, GetAsseType(pHealth->hAstDet.Type));
		cJSON_AddNumberToObject(pJsonHealth, STR_ATTENUATOR, pHealth->hAttenuator);
		cJSON_AddNumberToObject(pJsonBattery, STR_LIFE_REMAINING, pHealth->hBattery.hLifeRemain);
		cJSON_AddNumberToObject(pJsonBattery, STR_CYCLE, pHealth->hBattery.hCycles);
		cJSON_AddNumberToObject(pJsonHealth, STR_DEFINED_PART, pHealth->hDefinedPart);
		cJSON_AddNumberToObject(pJsonHealth, STR_DISPLAY, pHealth->hDisplay);
		cJSON_AddNumberToObject(pJsonHealth, STR_LASER, pHealth->hLaser);
		cJSON_AddNumberToObject(pJsonMemory, STR_BYTES_AVAIL, pHealth->hMemory.hBytesAvail);
		cJSON_AddNumberToObject(pJsonMemory, STR_BYTES_USED, pHealth->hMemory.hBytesUsed);
		if (pHealth->hMemory.phOSVer != NULL)
		{
			cJSON_AddStringToObject(pJsonMemory, STR_OS_VERSION, pHealth->hMemory.phOSVer);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
			SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s :pHealth->hMemory.hOSVer value is %s **************", function, pHealth->hMemory.phOSVer);
		}
		cJSON_AddNumberToObject(pJsonMotor, STR_REVOLUTIONS, pHealth->hMotor.hRevolut);
		cJSON_AddNumberToObject(pJsonMotor, STR_MOVEMENTS, pHealth->hMotor.hMovements);
		cJSON_AddNumberToObject(pJsonMotor, STR_MOVING_TIME, pHealth->hMotor.hMovTime);
		cJSON_AddNumberToObject(pJsonMotor, STR_ON_TIME, pHealth->hMotor.hOnTime);
		cJSON_AddNumberToObject(pJsonHealth, STR_OUTPUT, pHealth->hOutput);
		cJSON_AddNumberToObject(pJsonHealth, STR_PART, pHealth->hPart);
		cJSON_AddNumberToObject(pJsonHealth, STR_PRODUCT, pHealth->hProduct);
		cJSON_AddNumberToObject(pJsonHealth, STR_SWITCH, pHealth->hSwitch);
	}
	else
	{
		retVal = UTILITIES_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s:pJsonRoot is NULL ", function);
	}
	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s: exited", function);
	return retVal;
}

//"Akshata: JSON merge for future use" and commit the code.
//
//void FormEnviormentJsonOBJFromStruct(pParam_Environment pENV, cJSON **pJsonENV)
//{
//	cJSON  *pJsonAsset, *pJsonAccelerometer;
//	Sys_Char *function = "FormEnviormentJsonOBJFromStruct";
//	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s: entered.", function);
//
//	*pJsonENV = cJSON_CreateObject();
//	
//	cJSON_AddItemToObject(*pJsonENV, STR_DEVICE_ASSET, pJsonAsset = cJSON_CreateObject());
//	cJSON_AddStringToObject(*pJsonENV, STR_DEVICE_SOURCE, GetSourceType(pENV->ePrmSrc));
//	cJSON_AddItemToObject(*pJsonENV, STR_ACCELEROMETER, pJsonAccelerometer = cJSON_CreateObject());
//	cJSON_AddStringToObject(pJsonAsset, STR_DEVICE_ASSET_ID, pENV->eAstDet.pId);
//	cJSON_AddStringToObject(pJsonAsset, STR_DEVICE_ASSET_TYPE, GetAsseType(pENV->eAstDet.Type));
//	cJSON_AddStringToObject(pJsonAccelerometer, STR_XAXIS, pENV->eAccelMet.eXAxis);
//	cJSON_AddStringToObject(pJsonAccelerometer, STR_YAXIS, pENV->eAccelMet.eYAxis);
//	cJSON_AddStringToObject(pJsonAccelerometer, STR_ZAXIS, pENV->eAccelMet.eZAxis);
//	cJSON_AddNumberToObject(*pJsonENV, STR_CURRENT_SENSOR, pENV->eCurrSens);
//	cJSON_AddNumberToObject(*pJsonENV, STR_HUMIDITY_SENSOR, pENV->eHumidSens);
//	cJSON_AddNumberToObject(*pJsonENV, STR_LIGHT_SENSOR, pENV->eLightSens);
//	cJSON_AddNumberToObject(*pJsonENV, STR_PRESSURE_SENSOR, pENV->ePressSens);
//	cJSON_AddNumberToObject(*pJsonENV, STR_TEMPERATURE_SENSOR, pENV->eTempSens);
//	cJSON_AddNumberToObject(*pJsonENV, STR_VOLTAGE_SENSOR, pENV->eVoltSens);
//
//	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s: exited.", function);
//}
//
//
//void FormHealthJsonOBJFromStruct(pParam_Health pHealth, cJSON **pJsonHealth)
//{
//	cJSON  *pJsonAsset, *pJsonBattery, *pJsonMemory, *pJsonMotor;
//
//	Sys_Char *function = "FormHealthJsonOBJFromStruct";
//	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s : entered",function);
//
//	*pJsonHealth = cJSON_CreateObject();
//	cJSON_AddItemToObject(*pJsonHealth, STR_DEVICE_ASSET, pJsonAsset = cJSON_CreateObject());
//	cJSON_AddStringToObject(*pJsonHealth, STR_DEVICE_SOURCE, GetSourceType(pHealth->hPrmSrc));
//	cJSON_AddItemToObject(*pJsonHealth, STR_BATTERY, pJsonBattery = cJSON_CreateObject());
//	cJSON_AddItemToObject(*pJsonHealth, STR_MEMORY, pJsonMemory = cJSON_CreateObject());
//	cJSON_AddItemToObject(*pJsonHealth, STR_MOTOR, pJsonMotor = cJSON_CreateObject());
//	cJSON_AddStringToObject(pJsonAsset, STR_DEVICE_ASSET_ID, pHealth->hAstDet.pId);
//	cJSON_AddStringToObject(pJsonAsset, STR_DEVICE_ASSET_TYPE, GetAsseType(pHealth->hAstDet.Type));
//	cJSON_AddNumberToObject(*pJsonHealth, STR_ATTENUATOR, pHealth->hAttenuator);
//	cJSON_AddNumberToObject(pJsonBattery, STR_LIFE_REMAINING, pHealth->hBattery.hLifeRemain);
//	cJSON_AddNumberToObject(pJsonBattery, STR_CYCLE, pHealth->hBattery.hCycles);
//	cJSON_AddNumberToObject(*pJsonHealth, STR_DEFINED_PART, pHealth->hDefinedPart);
//	cJSON_AddNumberToObject(*pJsonHealth, STR_DISPLAY, pHealth->hDisplay);
//	cJSON_AddNumberToObject(*pJsonHealth, STR_LASER, pHealth->hLaser);
//	cJSON_AddNumberToObject(pJsonMemory, STR_BYTES_AVAIL, pHealth->hMemory.hBytesAvail);
//	cJSON_AddNumberToObject(pJsonMemory, STR_BYTES_USED, pHealth->hMemory.hBytesUsed);
//	if (pHealth->hMemory.phOSVer != NULL)
//	{
//		cJSON_AddStringToObject(pJsonMemory, STR_OS_VERSION, pHealth->hMemory.phOSVer);
//	}
//	else
//	{
//		SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s :pHealth->hMemory.hOSVer value is %s **************",function, pHealth->hMemory.phOSVer);
//	}
//	cJSON_AddNumberToObject(pJsonMotor, STR_REVOLUTIONS, pHealth->hMotor.hRevolut);
//	cJSON_AddNumberToObject(pJsonMotor, STR_MOVEMENTS, pHealth->hMotor.hMovements);
//	cJSON_AddNumberToObject(pJsonMotor, STR_MOVING_TIME, pHealth->hMotor.hMovTime);
//	cJSON_AddNumberToObject(pJsonMotor, STR_ON_TIME, pHealth->hMotor.hOnTime);
//	cJSON_AddNumberToObject(*pJsonHealth, STR_OUTPUT, pHealth->hOutput);
//	cJSON_AddNumberToObject(*pJsonHealth, STR_PART, pHealth->hPart);
//	cJSON_AddNumberToObject(*pJsonHealth, STR_PRODUCT, pHealth->hProduct);
//	cJSON_AddNumberToObject(*pJsonHealth, STR_SWITCH, pHealth->hSwitch);
//
//	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s: exited",function);
//}

UtilitiesErrCodes FormUtilsSCPIJsonOBJFromStruct(pParam_Utilization_SCPI pUtils, cJSON **pJsonRoot)
{
	cJSON *pJsonUtils, *pJsonAsset, *pJsonSCPI_Init, *pJsonOS_Init;
	UtilitiesErrCodes retVal = UTILITIES_SUCCESS;
	Sys_Char *function = "FormUtilsSCPIJsonOBJFromStruct";
	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s: entered",function);
	
	*pJsonRoot = cJSON_CreateObject();
	pJsonUtils = cJSON_CreateObject();
	pJsonAsset = cJSON_CreateObject();
	pJsonSCPI_Init = cJSON_CreateObject();
	pJsonOS_Init = cJSON_CreateObject();

	if (*pJsonRoot != NULL)
	{
		if (pJsonUtils != NULL)
		{
			cJSON_AddItemToObject(*pJsonRoot, STR_UTIL_PARAMS, pJsonUtils);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		if (pJsonAsset)
		{
			cJSON_AddItemToObject(pJsonUtils, STR_DEVICE_ASSET, pJsonAsset);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		cJSON_AddStringToObject(pJsonUtils, STR_DEVICE_SOURCE, GetSourceType(pUtils->uPrmSrc));
		if (pJsonSCPI_Init != NULL)
		{
			cJSON_AddItemToObject(pJsonUtils, STR_SCPI_INT, pJsonSCPI_Init);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		if (pJsonOS_Init)
		{

			cJSON_AddItemToObject(pJsonUtils, STR_OS_INIT, pJsonOS_Init);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		cJSON_AddStringToObject(pJsonAsset, STR_DEVICE_ASSET_ID, pUtils->uAstDet.pId);
		cJSON_AddStringToObject(pJsonAsset, STR_DEVICE_ASSET_TYPE, GetAsseType(pUtils->uAstDet.Type));
		cJSON_AddStringToObject(pJsonSCPI_Init, STR_FRONT_PANEL, pUtils->puFrntPanl);
		cJSON_AddBoolToObject(pJsonSCPI_Init, STR_LICENSES, pUtils->uLicense);
		cJSON_AddStringToObject(pJsonSCPI_Init, STR_SCPI, pUtils->puSCPI);
		cJSON_AddStringToObject(pJsonOS_Init, STR_KEYBOADR, "");
		cJSON_AddStringToObject(pJsonOS_Init, STR_MOUSE, "");
	}
	else
	{
		retVal = UTILITIES_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s:pJsonRoot is NULL ", function);
	}

	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s: exited",function);
	return retVal;
}

UtilitiesErrCodes FormUtilsOSJsonOBJFromStruct(pParam_Utilization_OS pUtilsOS, cJSON **pJsonRoot)
{
	cJSON *pJsonUtils, *pJsonAsset, *pJsonSCPI_Init, *pJsonOS_Init;
	Sys_Char *function = "FormUtilsOSJsonOBJFromStruct";
	UtilitiesErrCodes retVal = UTILITIES_SUCCESS;
	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, "%s: entered",function);
	//UtilitiesErrCodes retVal = UTILITIES_SUCCESS;
	*pJsonRoot = cJSON_CreateObject();
	pJsonUtils = cJSON_CreateObject();
	pJsonAsset = cJSON_CreateObject();
	pJsonSCPI_Init = cJSON_CreateObject();
	pJsonOS_Init = cJSON_CreateObject();
	if (*pJsonRoot != NULL)
	{
		if (pJsonUtils != NULL)
		{
			cJSON_AddItemToObject(*pJsonRoot, STR_UTIL_PARAMS, pJsonUtils);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		if (pJsonAsset != NULL)
		{
			cJSON_AddItemToObject(pJsonUtils, STR_DEVICE_ASSET, pJsonAsset);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		cJSON_AddStringToObject(pJsonUtils, STR_DEVICE_SOURCE, GetSourceType(pUtilsOS->uPrmSrc));
		if (pJsonSCPI_Init != NULL)
		{
			cJSON_AddItemToObject(pJsonUtils, STR_SCPI_INT, pJsonSCPI_Init);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		if (pJsonOS_Init != NULL)
		{
			cJSON_AddItemToObject(pJsonUtils, STR_OS_INIT, pJsonOS_Init);
		}
		else
		{
			retVal = UTILITIES_WRONG_IP_PARAMS;
		}
		cJSON_AddStringToObject(pJsonAsset, STR_DEVICE_ASSET_ID, pUtilsOS->uAstDet.pId);
		cJSON_AddStringToObject(pJsonAsset, STR_DEVICE_ASSET_TYPE, GetAsseType(pUtilsOS->uAstDet.Type));
		cJSON_AddStringToObject(pJsonSCPI_Init, STR_FRONT_PANEL, "");
		cJSON_AddBoolToObject(pJsonSCPI_Init, STR_LICENSES, 0);
		cJSON_AddStringToObject(pJsonSCPI_Init, STR_SCPI, "");
		cJSON_AddStringToObject(pJsonOS_Init, STR_KEYBOADR, pUtilsOS->puKeybrd);
		cJSON_AddStringToObject(pJsonOS_Init, STR_MOUSE, pUtilsOS->puMouse);
	}
	else
	{
		retVal = UTILITIES_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s:pJsonRoot is NULL ", function);
	}
	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s: exited.",function);
	return retVal;
}

void CleanUpJsonOBJ()
{
	Sys_Char *function = "CleanUpJsonOBJ";
	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s: entered",function);

	cJSON_Delete(pJsonHealth);
	cJSON_Delete(pJsonEnviorment);
	cJSON_Delete(pjsonUtilization); 

	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s: exited",function);
}