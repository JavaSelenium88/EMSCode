/******************************************************************************
//
//  Filename   : properties.h
//
//  Subsystem  : KeySight
//
//  Author     : Soumya Ranjan Bej
//
//  Description: Property related functionality are handled here.
//
******************************************************************************/

#ifndef PROPERTIES_H_
#define PROPERTIES_H_

#ifdef WIN32
//#include "twWindows-openssl.h"
#include "SysWindows-openssl.h"
#else
//#include "twLinux-openssl.h"
#include "SysLinux-openssl.h"
#endif
#include "Sysapi.h"
/* EMS properties */
struct
{
  Sys_Char *m_KeysightVersion;
  Sys_Char *m_Attenuator_cycles;
  Sys_Char *m_ConfigVersion;
} properties;

Sys_Int RegisterProperties();
//void PeriodicPropertyUpdate();
Sys_Int StaticPropertyUpdate();

#endif /* PROPERTIES_H_ */
