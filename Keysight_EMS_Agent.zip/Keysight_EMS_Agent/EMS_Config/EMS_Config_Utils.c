/*****************************************************************************
//  Copyright © 2016 ITC .  All rights reserved.
//
******************************************************************************
//
//  Filename   : configParams.c
//
//  Subsystem  : KeySight
//
//  Author     : Akshata N
//
//  Description:
//
//                Fetches values from JSON files and sets the parameters of network
//                connection, logging, offline message store & file transfer.
//
//
******************************************************************************/

#ifdef WIN32
//#include "twWindows-openssl.h"//ToDo:Abhishek - Is this reqd ?
#include "SysWindows-openssl.h"
#include <Windows.h>
#else
//#include "twLinux-openssl.h"
#include "SysLinux-openssl.h"
#include <unistd.h>
#endif

#ifdef WINCE
#include "twMessages.h"
#endif

#include  "OS_Utilities.h"
#include "EMS_Config_Utils.h"
#include "twLogger.h"
#include "cJSON.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "SysLog.h"
#include "Sysapi.h"
#include "OS_Utilities.h"
#include "EMS_Config.h"
#include "JsonObjectCreator.h"
#include "twFileManager.h"
#include "Properties.h"

#ifndef _WIN32
#define strtok_s strtok_r
#endif

extern twApi * tw_api; // This singleton api is used to get the WS connection status

Sys_Int DataRateForUnits(Sys_Char *unit);
Asset_Type AssetType(Sys_Char *type);


Sys_Char *ReadJsonFile(Sys_Char *fileName)
{
	Sys_Char *data = NULL;
	Sys_Long len = 0;
	Sys_Char *function = "ReadJsonFile";
    FILE *fd = SYS_FOPEN(fileName, "rb");
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	//FILE *fd = TW_FOPEN(fileName, "rb");
	if (!fd)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s:ReadJsonFile():Error opening the file/File does not exist in the path/folder",function);
		return data;
	}
	SYS_FSEEK(fd, 0, SEEK_END);
	len = (Sys_Long) SYS_FTELL(fd);
	SYS_FSEEK(fd, 0, SEEK_SET);
	data = (Sys_Char*)Sys_Malloc(len + 1);
	SYS_FREAD(data, 1, len, fd);
	SYS_FCLOSE(fd);

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return data;
}

Sys_Char *GetWinFormat(char *pszDir)
{
	Sys_Char *function = "GetWinFormat";
	Sys_Char *pszSysDirTemp = NULL;
	Sys_Char *pszTemp = pszDir;

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	pszTemp += 2;
	pszSysDirTemp = (Sys_Char*)Sys_Malloc(strlen(pszTemp) + 2);
	if (pszSysDirTemp)
	{
		strcpy(pszSysDirTemp, STR_DELIM_FWDSLSH);
	}
	strcat(pszSysDirTemp, pszTemp);
	if (pszDir != NULL)
	{
		Sys_Free(pszDir);
		pszTemp = NULL;
	}
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return pszSysDirTemp;
}

ConfigErrCodes AddSyslogVirtualDir(char *pszSysDir)
{

	Sys_Char *function = "AddSyslogVirtualDir";
	//Sys_Char buff[PATH_MAX + 1];
	Sys_Char* buff = NULL;
	//buff = GetCWD(); //Added after Valgrind mem check
    //Sys_Int lenCWD = (Sys_Int)strlen(GetCWD(buff, PATH_MAX + 1));
	Sys_Char *pszSysLogPath = NULL;
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	Sys_Int lenCWD = 0;
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
#ifndef WINCE
	buff = GetCWD();
#else
	buff = Sys_StrDup(WINCE_LOG_MSG_ROOT_FOLDER);
#endif
	/* length of current working directory*/
	lenCWD = (Sys_Int)strlen(buff);
	//Sys_Int lenCWD = (Sys_Int)strlen(GetCWD(buff, PATH_MAX + 1));
	//Sys_Char *pszSysLogPath = NULL;
	//ConfigErrCodes retVal = CONFIG_SUCCESS;

	if (pszSysDir != NULL)
	{
		pszSysLogPath = (Sys_Char*)Sys_Malloc(lenCWD + (strlen(pszSysDir) + 1));
		if (pszSysLogPath == NULL){
			retVal = CONFIG_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Insufficient memory !", function);
			goto failCall;
		}
		strcpy(pszSysLogPath, buff);
		strcat(pszSysLogPath, strtok(pszSysDir, "."));
		//
		//#ifdef WIN32	
		//		pszSysDir = GetWinFormat(pszSysDir);
		//		strcat(pszSysLogPath, pszSysDir);
		//#else
		//		strcat(pszSysLogPath, strtok(pszSysDir, STR_DELIM_DOT));
		//#endif

		twFileManager_AddVirtualDir(pConfigparam->m_ThingName, STR_SYSTEM_LOG, pszSysLogPath);

	}
	else{
		retVal = CONFIG_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Wrong input passed !", function);
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited ", function);
		goto failCall;
	}

failCall:
	/*if (pszSysDir) {
	Sys_Free(pszSysDir);
	pszSysDir = NULL;
	}
	*/
	if (pszSysLogPath){
		Sys_Free(pszSysLogPath);
		pszSysLogPath = NULL;
	}

	if (buff) { //Added after Valgrind mem check
		Sys_Free(buff);
		buff = NULL;
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited!", function);
	return retVal;
}

ConfigErrCodes AddEMSConfigVirtualDir(Sys_Char *pszEMSDir)
{
	Sys_Char *function = "AddEMSConfigVirtualDir";
	//Sys_Char buff[PATH_MAX + 1];
	Sys_Char* buff = NULL; //Added after Valgrind mem check	
	Sys_Int lenCWD = 0;
	//Sys_Int lenCWD = (Sys_Int)strlen(GetCWD(buff, PATH_MAX + 1));
	Sys_Char *pszEMSConfigPath = NULL;
	ConfigErrCodes retVal = CONFIG_SUCCESS;

	buff = GetCWD();
	/*length of current working directory*/
	lenCWD = (Sys_Int)strlen(buff);

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	if (pszEMSDir != NULL)
	{
		pszEMSConfigPath = (Sys_Char*)Sys_Malloc(lenCWD + (strlen(pszEMSDir) + 1));
		if (pszEMSConfigPath == NULL){
			retVal = CONFIG_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Insufficient memory !", function);
			goto failCall;
		}
		strcpy(pszEMSConfigPath, buff);
		strcat(pszEMSConfigPath, strtok(pszEMSDir, "."));
		//#ifdef WIN32	
		//		pszEMSDir = GetWinFormat(pszEMSDir);
		//		strcat(pszEMSConfigPath, pszEMSDir);
		//#else
		//		strcat(pszSysLogPath, strtok(pszSysDir, STR_DELIM_DOT));
		//#endif
		twFileManager_AddVirtualDir(pConfigparam->m_ThingName, STR_EMS_CONFIG_FILES, pszEMSConfigPath);

	}
	else{
		retVal = CONFIG_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Wrong input passed !", function);
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited ", function);
		goto failCall;
	}
failCall:
	/*if (pszEMSDir) {
	Sys_Free(pszEMSDir);
	pszEMSDir = NULL;
	}*/

	if (pszEMSConfigPath){
		Sys_Free(pszEMSConfigPath);
		pszEMSConfigPath = NULL;
	}

	if (buff) { //Added after Valgrind mem check
		Sys_Free(buff);
		buff = NULL;
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited!", function);
	return retVal;
}

//Added
Sys_Ullong GetDiskFreeSize()
{
	Sys_Char *function = "GetDiskFreeSize";
	Sys_Ullong freeSpace;
	ConfigErrCodes retVal = CONFIG_SUCCESS;

#ifdef WINCE
	retVal = Sys_GetFreeDiskSpace(WINCE_LOG_MSG_ROOT_FOLDER, &freeSpace);
#else
	retVal = Sys_GetFreeDiskSpace(NULL, &freeSpace);
#endif

	if (retVal != 0)
		return CONFIG_SYSTEM_ERROR;

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "GetDiskFreeSize: %I64u MB Free", freeSpace / 1024 / 1024);
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: Exit", function);
	return freeSpace;
}
/*
* Fetches the value from Config.json & sets the values to the pConfigparam
*/
ConfigErrCodes  ReadConfigParams()
{
	Sys_Char *pszWs_connection = STR_FILE_WS_CONNECTION;
	Sys_Char *pszConfigFilePath = GetFilePathByName(CONFIG_FOLDER_NAME, pszWs_connection);
	Sys_Char *pszBufWS = NULL;
	cJSON *pJsonRoot = NULL;
	cJSON *pJsonStart = NULL;
	cJSON *pJsonAsset = NULL;
	cJSON *pJsonAcquisition = NULL;
	cJSON *pJsonPosting = NULL;
	cJSON *pJsonFTStart = NULL;
	/* cJSON *pVirtualDirArray = NULL; */
	cJSON *pOfflineStart = NULL;
	cJSON *cjson_tmp = NULL;
	cJSON *cjson_ProxyHostTmp = NULL;
	cJSON *cjson_ProxyPortTmp = NULL;

	ConfigErrCodes retVal = CONFIG_SUCCESS;
	ConfigErrCodes proxyHostRetVal = CONFIG_SUCCESS;
	Sys_Char *pAssetType = NULL;
	Sys_Char *pAcqUnit = NULL;
	/* Sys_Char *pHealthRate = NULL; */
	/* Sys_Char *pENVRate = NULL; */
	/* Sys_Char *pUtilRate = NULL; */
	/* Sys_Char *pPostingUnit = NULL; */
	Sys_Char *function = "ReadConfigParams";
	Sys_Char *pStagingDir = NULL;
	Sys_Char *pOfflineDir = NULL;
	/* Sys_Int pVirtualDirSize = 0; */
	Sys_Int twRetVal = TW_OK;
	Sys_Char *pszEMSDir = NULL;
	Sys_Char *pszSysDir = NULL;

	/*---------------SCM---12/09/2017  Config Version---------------------------*/
	Sys_Int retProperty = TW_OK;
	twPrimitive *pConfigVersion = NULL;
	cJSON *check_Configparam = NULL;
	/*check_Configparam --> Checks whether the config_version parameter is 
	  present in config file.*/
	/*--------------------------------------------------------------------------*/
#ifdef WINCE
	Sys_Char *pTempOfflinePath = NULL;
    Sys_Char msgFolderBuf[MAX_PATH];
#endif

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	SysMutex_Lock(pConfigparam->mutexHdl);
	pszBufWS = ReadFileContent(pszConfigFilePath);
	if (pszBufWS != NULL)
	{
		/*json object will have the parsed value of the data*/
		pJsonRoot = cJSON_Parse(pszBufWS);
		Sys_Free(pszBufWS);
		pszBufWS = NULL;
		if (!pJsonRoot) {
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: --> INVALID JSON FILE", function);
			retVal = CONFIG_WRONG_IP_PARAMS;
			goto failCall;
		}
		/*Gets the 1st JSON item in the JSON object*/
		pJsonStart = cJSON_GetObjectItem(pJsonRoot, STR_HYRAX_SERVER);
		if (pJsonStart == NULL) {
			retVal = CONFIG_FILE_RW_ERROR;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error reading config json header!", function);
			goto failCall;
		}

		if (pConfigparam != NULL) {
			twcfg.connect_timeout = CONNECT_TIMEOUT_KEYSIGHT;// cJSON_GetObjectItem(pJsonStart, STR_CONNECTION_TIMEOUT)->valueint;
			twcfg.connect_retry_interval = CONNECT_RETRY_INTERVAL_KEYSIGHT;// cJSON_GetObjectItem(pJsonStart, STR_CONNECT_RETRY_INTERVAL)->valueint;
			twcfg.max_connect_delay = MAX_CONNECT_DELAY_KEYSIGHT;// cJSON_GetObjectItem(pJsonStart, STR_MAX_CONNECT_DELAY)->valueint;
			twcfg.max_message_size = cJSON_GetObjectItem(pJsonStart, STR_MAX_MESSAGE_SIZE)->valueint;

			if (pConfigparam->m_HostName) {
				Sys_Free(pConfigparam->m_HostName);
				pConfigparam->m_HostName = NULL;
			}
			pConfigparam->m_HostName = Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_HOSTNAME)->valuestring);
			if (pConfigparam->m_HostName == NULL) {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			pConfigparam->m_Port = cJSON_GetObjectItem(pJsonStart, STR_PORT)->valueint;

			//Proxy server host config 
			if (pConfigparam->m_ProxyHostName) {
				Sys_Free(pConfigparam->m_ProxyHostName);
				pConfigparam->m_ProxyHostName = NULL;
			}

			cjson_ProxyHostTmp = cJSON_GetObjectItem(pJsonStart, STR_PROXY_HOSTNAME);
			if (cjson_ProxyHostTmp != NULL) {
				pConfigparam->m_ProxyHostName = Sys_StrDup(cjson_ProxyHostTmp->valuestring);
				if (!Sys_StringCmp(pConfigparam->m_ProxyHostName, ""))

					SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Proxy_hostname is null. EMS will connect without Proxy", function);
			}
			
			//Proxy server port config 
			if (pConfigparam->m_ProxyPort) {
				Sys_Free(pConfigparam->m_ProxyPort);
				pConfigparam->m_ProxyPort = NULL;
			}
			cjson_ProxyPortTmp = cJSON_GetObjectItem(pJsonStart, STR_PROXY_PORT);
				if (cjson_ProxyPortTmp != NULL) {
					pConfigparam->m_ProxyPort = Sys_StrDup(cjson_ProxyPortTmp->valuestring);
					if (!Sys_StringCmp(pConfigparam->m_ProxyPort, ""))
						SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Proxy_Port is null. EMS will connect without Proxy", function);
				}


			pJsonAsset = cJSON_GetObjectItem(pJsonStart, STR_ASSET);

			if (pConfigparam->m_Asset.pId) {
				Sys_Free(pConfigparam->m_Asset.pId);
				pConfigparam->m_Asset.pId = NULL;
			}
			pConfigparam->m_Asset.pId = Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_ID)->valuestring);
			if (pConfigparam->m_Asset.pId == NULL) {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			//Added Sept_19
			// Asset Connection Config
			if (pConfigparam->m_Asset.comType) {
				Sys_Free(pConfigparam->m_Asset.comType);
				pConfigparam->m_Asset.comType = NULL;
			}
			pConfigparam->m_Asset.comType = Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_COM_TYPE)->valuestring);
			if (pConfigparam->m_Asset.comType == NULL) {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			if (pConfigparam->m_Asset.comAddr) {
				Sys_Free(pConfigparam->m_Asset.comAddr);
				pConfigparam->m_Asset.comAddr = NULL;
			}
			pConfigparam->m_Asset.comAddr = Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_COM_ADDR)->valuestring);
			if (pConfigparam->m_Asset.comAddr == NULL) {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			if (pConfigparam->m_Asset.comPort) {
				Sys_Free(pConfigparam->m_Asset.comPort);
				pConfigparam->m_Asset.comPort = NULL;
			}
			pConfigparam->m_Asset.comPort = Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_COM_PORT)->valuestring);
			if (pConfigparam->m_Asset.comPort == NULL) {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}
			//End Sept_19
			// For App Utilization
			if (pConfigparam->m_Asset.appName) {
				Sys_Free(pConfigparam->m_Asset.appName);
				pConfigparam->m_Asset.appName = NULL;
			}
			pConfigparam->m_Asset.appName = Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_APP_NAME)->valuestring);
			if (pConfigparam->m_Asset.appName == NULL) {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}
			pAssetType = Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_TYPE)->valuestring);
			if (pAssetType != NULL) {
				pConfigparam->m_Asset.Type = AssetType(pAssetType);

				Sys_Free(pAssetType);
				pAssetType = NULL;
			}
			else {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			// For Plum Ref Volt
			pConfigparam->m_Asset.refVolt = cJSON_GetObjectItem(pJsonAsset, STR_ASSET_REF_VOLT)->valuedouble;
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%lu : ref volt", pConfigparam->m_Asset.refVolt);

			if (pConfigparam->m_Asset.misc) {
				Sys_Free(pConfigparam->m_Asset.misc);
				pConfigparam->m_Asset.misc = NULL;
			}
			cjson_tmp = cJSON_GetObjectItem(pJsonAsset, STR_ASSET_MISC);
			if (cjson_tmp != NULL) {
				pConfigparam->m_Asset.misc = Sys_StrDup(cjson_tmp->valuestring);
				if (pConfigparam->m_Asset.misc == NULL) {
					retVal = CONFIG_WRONG_IP_PARAMS;
					goto failCall;
				}
			}

			//Made changes for the feature of EMS_Status to start, stop EMS Agent dynamically
			if (cJSON_GetObjectItem(pJsonStart, STR_EMS_STATUS)->type == SYS_TRUE || cJSON_GetObjectItem(pJsonStart, STR_EMS_STATUS)->type == SYS_FALSE) {
				pConfigparam->m_EmsStatus = (Sys_Bool)cJSON_GetObjectItem(pJsonStart, STR_EMS_STATUS)->type;
			}
			else {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			//SCM 11/9/2017	Reading Config version parameter---------------------------------------------------------
			if (pConfigparam->m_ConfigVersion) {
				Sys_Free(pConfigparam->m_ConfigVersion);
				pConfigparam->m_ConfigVersion = NULL;
			}

			check_Configparam = cJSON_GetObjectItem(pJsonStart, STR_CONFIG_VERSION);

			if (!check_Configparam)
			{
				pConfigparam->m_ConfigVersion = Sys_StrDup("0.0.0");
			}
			else
			{
				pConfigparam->m_ConfigVersion = Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_CONFIG_VERSION)->valuestring);
			}

			properties.m_ConfigVersion = pConfigparam->m_ConfigVersion;
			pConfigVersion = twPrimitive_CreateFromString(pConfigparam->m_ConfigVersion, TRUE);
			retProperty = twApi_WriteProperty(TW_THING, pConfigparam->m_ThingName, "Config_Version", pConfigVersion, -1, 0);

			if (retProperty)
			{
				SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error in writing Config.json version number on the platform", function);
			}
			twPrimitive_Delete(pConfigVersion);
			//-------------------------------------------------------------------------------------------------------

			if (pConfigparam->m_ThingName) {
				Sys_Free(pConfigparam->m_ThingName);
				pConfigparam->m_ThingName = NULL;
			}
			pConfigparam->m_ThingName = Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_THINGNAME)->valuestring);
			if (pConfigparam->m_ThingName) {
				GetThingName();
			}
			else {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			if (pConfigparam->m_AppKey) {
				Sys_Free(pConfigparam->m_AppKey);
				pConfigparam->m_AppKey = NULL;
			}
			pConfigparam->m_AppKey = Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_APPKEY)->valuestring);
			if (pConfigparam->m_AppKey == NULL) {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			if (pConfigparam->PEMCertFile != NULL) {
				Sys_Free(pConfigparam->PEMCertFile);
				pConfigparam->PEMCertFile = NULL;
			}

			pConfigparam->PEMCertFile = Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_PEM_FILE)->valuestring);
			if (pConfigparam->PEMCertFile == NULL) {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			if (pConfigparam->m_Encryption) {
				Sys_Free(pConfigparam->m_Encryption);
				pConfigparam->m_Encryption = NULL;
			}
			pConfigparam->m_Encryption = Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_ENCRYPTION)->valuestring);
			if (pConfigparam->m_Encryption == NULL) {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			/*< Max Message Size*/
			pConfigparam->Max_Message_Size = twcfg.max_message_size;
			if (pConfigparam->Max_Message_Size == 0) {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}
			/*< Get Acquisition Rates and Unit */
			pJsonAcquisition = cJSON_GetObjectItem(pJsonStart, STR_ACQUISITION);
			pAcqUnit = Sys_StrDup(cJSON_GetObjectItem(pJsonAcquisition, STR_UNIT)->valuestring);
			if (pAcqUnit != NULL) {
				pConfigparam->acquisition.unit = DataRateForUnits(pAcqUnit);

				Sys_Free(pAcqUnit);
				pAcqUnit = NULL;
			}
			else {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}
			
			pConfigparam->acquisition.health = GetInMSec(cJSON_GetObjectItem(pJsonAcquisition, STR_HEALTH_RATE)->valueint, pConfigparam->acquisition.unit);
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%lu : Health Acq. rate", pConfigparam->acquisition.health);

			pConfigparam->acquisition.environment = GetInMSec(cJSON_GetObjectItem(pJsonAcquisition, STR_ENV_RATE)->valueint, pConfigparam->acquisition.unit);
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%lu : Enviornment Acq. rate", pConfigparam->acquisition.environment);

			pConfigparam->acquisition.utilization = GetInMSec(cJSON_GetObjectItem(pJsonAcquisition, STR_UTILIZATION_RATE)->valueint, pConfigparam->acquisition.unit);
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%lu : Utilization Acq. rate", pConfigparam->acquisition.utilization);

			pConfigparam->acquisition.information = GetInMSec(cJSON_GetObjectItem(pJsonAcquisition, STR_INFORMATION_RATE)->valueint, pConfigparam->acquisition.unit);
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%lu : Information Acq. rate", pConfigparam->acquisition.information);

			if ((pConfigparam->acquisition.health == 0)
				&& (pConfigparam->acquisition.environment == 0)
				&& (pConfigparam->acquisition.utilization == 0)
				&& (pConfigparam->acquisition.information == 0)) {
				pConfigparam->m_EmsStatus = SYS_FALSE;
				SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%d : All rates are zero, application will not send any data to server", pConfigparam->acquisition.information); 
			}

			/*< Get Posting Rates and Unit */
			//Posting rate is remove
			/*pJsonPosting = cJSON_GetObjectItem(pJsonStart, STR_POSTING);
			pAcqUnit = Sys_StrDup(cJSON_GetObjectItem(pJsonPosting, STR_UNIT)->valuestring);
			if (pAcqUnit != NULL) {
				pConfigparam->posting.unit = DataRateForUnits(pAcqUnit);

				Sys_Free(pAcqUnit);
				pAcqUnit = NULL;
			}
			else {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			pConfigparam->posting.health = GetInMSec(cJSON_GetObjectItem(pJsonPosting, STR_HEALTH_RATE)->valueint, pConfigparam->posting.unit);
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%d : Health Post. rate", pConfigparam->posting.health);

			pConfigparam->posting.environment = GetInMSec(cJSON_GetObjectItem(pJsonPosting, STR_ENV_RATE)->valueint, pConfigparam->posting.unit);
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%d : Enviornment Post. rate", pConfigparam->posting.environment);

			pConfigparam->posting.utilization = GetInMSec(cJSON_GetObjectItem(pJsonPosting, STR_UTILIZATION_RATE)->valueint, pConfigparam->posting.unit);
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%d : Utilization Post. rate", pConfigparam->posting.utilization);
			*/
		}
		else {
			retVal = CONFIG_WRONG_IP_PARAMS;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Wrong pConfigparam hdle passed!", function);
			goto failCall;
		}

		if (pConfigparam->configDone == SYS_FALSE) {
			pJsonFTStart = cJSON_GetObjectItem(pJsonStart, STR_FILE_TRANSFER);
			twcfg.file_xfer_md5_block_size = cJSON_GetObjectItem(pJsonFTStart, STR_BUFFER_SIZE)->valueint;
			twcfg.file_xfer_max_file_size = cJSON_GetObjectItem(pJsonFTStart, STR_MAX_FILE_SIZE)->valueint;

			pStagingDir = Sys_StrDup(cJSON_GetObjectItem(pJsonFTStart, STR_STAGING_DIR)->valuestring);
			if (pStagingDir != NULL) {
				twcfg.file_xfer_staging_dir = pStagingDir;
			}
			else {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			twRetVal = twFileManager_Create();
			if (twRetVal != TW_OK) {
				retVal = CONFIG_FW_ERROR;
				SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: twFileManager_Create() failed!", function);
				goto failCall;
			}

			twRetVal = twFileManager_AddVirtualDir(pConfigparam->m_ThingName, "tw", twcfg.file_xfer_staging_dir);
			if (twRetVal != TW_OK) {
				retVal = CONFIG_FW_ERROR;
				SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: twFileManager_AddVirtualDir() failed!", function);
				goto failCall;
			}

			pszEMSDir = Sys_StrDup(cJSON_GetObjectItem(pJsonFTStart, STR_EMS_CONFIG_FILES)->valuestring);
			if (pszEMSDir != NULL) {
				AddEMSConfigVirtualDir(pszEMSDir);
				Sys_Free(pszEMSDir);
				pszEMSDir = NULL;
			}
			else {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			pConfigparam->configDone = SYS_TRUE;
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: Config file dump configuration completed.", function);
		}
		else {
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: Config file dump re-configuration skipped.", function);
		}

		if (pConfigparam->logDone == SYS_FALSE) {
			pszSysDir = Sys_StrDup(cJSON_GetObjectItem(pJsonFTStart, STR_SYSTEM_LOG)->valuestring);
			if (pszSysDir != NULL) {
				AddSyslogVirtualDir(pszSysDir);
				Sys_Free(pszSysDir);
				pszSysDir = NULL;
			}
			else {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			pConfigparam->logDone = SYS_TRUE;
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: Log file retrieval configuration completed.", function);
		}
		else {
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: Log file retrieval re-configuration skipped.", function);
		}


		/*< Get Offline Message Store dir and Size */
		if (pConfigparam->offlineDone == SYS_FALSE) {
			pOfflineStart = cJSON_GetObjectItem(pJsonStart, STR_OFFLINE_MSG);

			//Added
			twcfg.offline_msg_queue_size = ((GetDiskFreeSize() * (cJSON_GetObjectItem(pOfflineStart, STR_MSG_SIZE)->valueint)) / 100);
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "Offline msg storage file size : %lu Bytes", twcfg.offline_msg_queue_size);
    
			if ((twcfg.max_message_size * PAYLOAD_MULTIPLIER) > twcfg.offline_msg_queue_size) {   /*<Minimum message store buffer should be greater than or equal to 10 time of the payload*/

				retVal = CONFIG_INSUFFICIENT_MEMORY;
				SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Insufficient Memory for storing minimum payload size!", function);
				goto failCall;;

			}

			pOfflineDir = Sys_StrDup(cJSON_GetObjectItem(pOfflineStart, STR_DIRECTORY)->valuestring);
			if (pOfflineDir != NULL) {
#ifndef WINCE
				twcfg.offline_msg_store_dir = pOfflineDir;
#else
				pTempOfflinePath = pOfflineDir + 2;
			    sprintf(msgFolderBuf,"%s%s",WINCE_LOG_MSG_ROOT_FOLDER,pTempOfflinePath);
				twcfg.offline_msg_store_dir = Sys_StrDup(msgFolderBuf);
#endif
                
			}
			else {
				retVal = CONFIG_WRONG_IP_PARAMS;
				goto failCall;
			}

			//twApi_SetOfflineMsgStoreDir(twcfg.offline_msg_store_dir); //TODO: Abhishek: Check for return codes.

#ifdef WINCE
			twSetOfflineDirWinCE(twcfg.offline_msg_store_dir);

#endif

			pConfigparam->offlineDone = SYS_TRUE;
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: Offline storage file configuration completed.", function);
		}
		else {
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: Offline storage file re-configuration skipped.", function);
		}

		if (pJsonRoot) {
			cJSON_Delete(pJsonRoot);
			pJsonRoot = NULL;
		}
	}
	else {
		retVal = CONFIG_FILE_RW_ERROR;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: CONFIG_FILE_RW_ERROR", function);
		goto failCall;
	}

	if (pszConfigFilePath) {
		Sys_Free(pszConfigFilePath);
		pszConfigFilePath = NULL;
	}

	SysAppLog(SYS_DEBUG,MODULE_EMS_CONFIG,  "%s: exited!", function);
	SysMutex_Unlock(pConfigparam->mutexHdl);
	return retVal;
	
failCall:
	if (pszConfigFilePath) {
		Sys_Free(pszConfigFilePath);
		pszConfigFilePath = NULL;
	}

	if (cjson_ProxyHostTmp) {
			Sys_Free(cjson_ProxyHostTmp);
			cjson_ProxyHostTmp = NULL;
	}
	if (cjson_ProxyPortTmp) {
		Sys_Free(cjson_ProxyPortTmp);
		cjson_ProxyPortTmp = NULL;
	}
	
	if (pJsonRoot) {
		cJSON_Delete(pJsonRoot);
		pJsonRoot = NULL;
	}

	if (pAssetType) {
		Sys_Free(pAssetType);
		pAssetType = NULL;
	}

	if (pAcqUnit) {
		Sys_Free(pAcqUnit);
		pAcqUnit = NULL;
	}

	if (pszSysDir) {
		Sys_Free(pszSysDir);
		pszSysDir = NULL;
	}

	if (pszEMSDir) {
		Sys_Free(pszEMSDir);
		pszEMSDir = NULL;
	}

	SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: exited with failure!", function);

	SysMutex_Unlock(pConfigparam->mutexHdl);

	return (retVal);
}

//Added
Sys_Ulong GetInMSec(Sys_Uint rate, DataRateUnits unit)
{
	Sys_Ulong retVal = TW_UNKNOWN_ERROR;
	Sys_Char *function = "GetInMSec";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	Sys_Ulong temp = 0;
	static Sys_Int booster = 0;
	static Sys_Bool BoosterFlag = FALSE;//BoosterFlag-Makes sure we search Booster parameter only once from teh Config.json

	switch (unit)
	{
	case 0:
		temp = (Sys_Ulong)rate;
		break;
	case 1:
		temp = (Sys_Ulong)(rate * 1000);
		break;
	case 2:
		temp = (Sys_Ulong)(rate * 1000 * 60);
		break;
	case 3:
		temp = (Sys_Ulong)(rate * 1000 * 60 * 60);
		break;
	case 4:
		if (rate > 49) {
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Rate entered above permissible limit. Allowed Rate of 49 days will be assigned. ", function);
			temp = MAX_DAYS_IN_MSEC;
		}
		else
			temp = (Sys_Ulong)(rate * 1000 * 60 * 60 * 24);
		break;
	case 5:
		temp = (Sys_Ulong)DEFAULT_ACQ_RATE_KEYSIGHT;//ToDo:Soumya - Update the default time too
	}

	//Added for Asset Misc | 15/02/2018 
	if (!temp)
		return 0;
	
	if ((pConfigparam->m_Asset.misc != NULL) && (BoosterFlag == FALSE)) {
		Sys_Char *pch, *saved;
		Sys_Char *misc_cpy = Sys_Malloc(strlen(pConfigparam->m_Asset.misc) + 1);
		strcpy(misc_cpy, pConfigparam->m_Asset.misc);
		pch = strtok_s(misc_cpy, ";", &saved);
		while (pch != NULL)
		{
			char *misc_pair, *saved_pair;
			misc_pair = strtok_s(pch, "=", &saved_pair);
			while (misc_pair != NULL) {
				// find key
				if (strcmp(misc_pair, "booster") == 0) {
					BoosterFlag = TRUE;
					misc_pair = strtok_s(NULL, "=", &saved_pair);
					if (misc_pair != NULL) {
						// get value
						SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: *****************booster flag found", function);
						booster = atoi(misc_pair);
						SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: *****************booster value = %d", function, booster);
					}
				}
				misc_pair = strtok_s(NULL, "=", &saved_pair);
			}
			pch = strtok_s(NULL, ";", &saved);
		}
		free(misc_cpy);
	
	}

	if (booster == 1) {
		if (temp <= TWENTY_SECOND_IN_MSEC_KEYSIGHT)
			retVal = TWENTY_SECOND_IN_MSEC_KEYSIGHT;
		else
			retVal = temp;
	}
	else {
		if (temp <= FIVE_MIN_IN_MSEC_KEYSIGHT) {
			retVal = FIVE_MIN_IN_MSEC_KEYSIGHT;
		}
		else
			retVal = temp;
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return retVal;
}

Sys_Char *GetUnitType(Sys_Int unit)
{
	Sys_Char *function = "GetUnitType";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, " GetUnitType() start");
	switch (unit)
	{
	case 0:
		return "msec";
		break;
	case 1:
		return "sec";
		break;
	case 2:
		return "min";
		break;
	case 3:
		return "hour";
		break;
	case 4:
		return "day";
		break;
	default:
		return "UNKNOWN";
		break;
	}
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
}

ConfigErrCodes WriteConfigParams()
{
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	Sys_Char *function = "WriteConfigParams";
	/* Sys_Int returnCode = TW_OK; */
	Sys_Char *pszWs_connection = STR_FILE_WS_CONNECTIONS;
	Sys_Char *pszConfigFilePath = GetFilePathByName(CONFIG_FOLDER_NAME, pszWs_connection);
	Sys_Char *pszJsonOutput = NULL;
	Sys_Int len = 0;
	/* Sys_Char *pszBufWS = NULL; */
	Sys_Char *thing_name = NULL;
	SYS_FILE_HANDLE  fileHandle = NULL;

	cJSON *root = NULL;
	cJSON *hyrax_server = NULL;
	cJSON *Asset = NULL;
	cJSON *Acquisition = NULL;
	cJSON *Posting = NULL;

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	root = cJSON_CreateObject();
	if (root == NULL){
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: root Insufficient memory!", function);
		goto failCall;
	}

	cJSON_AddItemToObject(root, STR_HYRAX_SERVER, hyrax_server = cJSON_CreateObject());

	if (hyrax_server == NULL){
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: hyrax_server - Insufficient memory!", function);
		goto failCall;
	}

	cJSON_AddItemToObject(hyrax_server, STR_ASSET, Asset = cJSON_CreateObject());

	if (Asset == NULL){
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Asset- Insufficient memory!", function);
		goto failCall;
	}

	if (pConfigparam->m_Asset.pId)
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_ID, pConfigparam->m_Asset.pId);
	}
	else
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_ID,"");
	}
	
	if (GetAsseType(pConfigparam->m_Asset.Type))
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_TYPE, (Sys_Char *)GetAsseType(pConfigparam->m_Asset.Type));
	}
	else
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_TYPE, "");
	}

	//Added Sept_19
	if (pConfigparam->m_Asset.comType)
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_COM_TYPE, pConfigparam->m_Asset.comType);
	}
	else
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_COM_TYPE, "");
	}

	if (pConfigparam->m_Asset.comAddr)
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_COM_ADDR, pConfigparam->m_Asset.comAddr);
	}
	else
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_COM_ADDR, "");
	}

	if (pConfigparam->m_Asset.comPort)
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_COM_PORT, pConfigparam->m_Asset.comPort);
	}
	else
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_COM_PORT, "");
	}
	//End Sept_19
	// For App Utilization
	if (pConfigparam->m_Asset.appName)
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_APP_NAME, pConfigparam->m_Asset.appName);
	}
	else
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_APP_NAME, "");
	}

	cJSON_AddNumberToObject(Asset, STR_ASSET_REF_VOLT, pConfigparam->m_Asset.refVolt);
	if (pConfigparam->m_Asset.misc)
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_MISC, pConfigparam->m_Asset.misc);
	}
	else
	{
		cJSON_AddStringToObject(Asset, STR_ASSET_MISC, "");
	}
	cJSON_AddBoolToObject(hyrax_server, STR_EMS_STATUS, pConfigparam->m_EmsStatus);

	if (pConfigparam->m_ThingName)
	{
		thing_name = pConfigparam->m_ThingName;
		thing_name++;

		cJSON_AddStringToObject(hyrax_server, STR_THINGNAME, thing_name);
	}
	else
	{
		cJSON_AddStringToObject(hyrax_server, STR_THINGNAME, "");
	}

	if (pConfigparam->m_HostName)
	{
		cJSON_AddStringToObject(hyrax_server, STR_HOSTNAME, pConfigparam->m_HostName);
	}
	else
	{
		cJSON_AddStringToObject(hyrax_server, STR_HOSTNAME, "");
	}
	
	cJSON_AddNumberToObject(hyrax_server, STR_PORT, pConfigparam->m_Port);
	if (pConfigparam->m_AppKey)
	{
		cJSON_AddStringToObject(hyrax_server, STR_APPKEY, pConfigparam->m_AppKey);
	}
	else
	{
		cJSON_AddStringToObject(hyrax_server, STR_APPKEY, "");
	}
	
	if (pConfigparam->m_Encryption)
	{
		cJSON_AddStringToObject(hyrax_server, STR_ENCRYPTION, pConfigparam->m_Encryption);
	}
	else
	{
		cJSON_AddStringToObject(hyrax_server, STR_ENCRYPTION, "");
	}
	
	cJSON_AddNumberToObject(hyrax_server, STR_CONNECT_RETRY_INTERVAL, twcfg.connect_retry_interval);
	cJSON_AddNumberToObject(hyrax_server, STR_MAX_CONNECT_DELAY, twcfg.max_connect_delay);
	cJSON_AddNumberToObject(hyrax_server, STR_CONNECTION_TIMEOUT, twcfg.connect_timeout);

	cJSON_AddItemToObject(hyrax_server, STR_ACQUISITION, Acquisition = cJSON_CreateObject());
	if (Acquisition == NULL){
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Acquisition - Insufficient memory!", function);
		goto failCall;
	}
	if (GetUnitType(pConfigparam->acquisition.unit))
	{
		cJSON_AddStringToObject(Acquisition, STR_UNIT, GetUnitType(pConfigparam->acquisition.unit));
	}
	else
	{
		cJSON_AddStringToObject(Acquisition, STR_UNIT, "");
	}
	
	cJSON_AddNumberToObject(Acquisition, STR_HEALTH_RATE, pConfigparam->acquisition.health);
	cJSON_AddNumberToObject(Acquisition, STR_ENV_RATE, pConfigparam->acquisition.environment);
	cJSON_AddNumberToObject(Acquisition, STR_UTILIZATION_RATE, pConfigparam->acquisition.utilization);
	cJSON_AddNumberToObject(Acquisition, STR_INFORMATION_RATE, pConfigparam->acquisition.information);

	cJSON_AddItemToObject(hyrax_server, STR_POSTING, Posting = cJSON_CreateObject());

	if (Posting == NULL){
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Posting - Insufficient memory!", function);
		goto failCall;
	}

	//Posting rate is removed from the config.json
	/*if (GetUnitType(pConfigparam->acquisition.unit))
	{
		cJSON_AddStringToObject(Posting, STR_POSTING_UNIT, GetUnitType(pConfigparam->posting.unit));
	}
	else
	{
		cJSON_AddStringToObject(Posting, STR_POSTING_UNIT, "");
	}
	
	cJSON_AddNumberToObject(Posting, STR_HEALTH_RATE, pConfigparam->posting.health);
	cJSON_AddNumberToObject(Posting, STR_ENV_RATE, pConfigparam->posting.environment);
	cJSON_AddNumberToObject(Posting, STR_UTILIZATION_RATE, pConfigparam->posting.utilization);*/


	fileHandle = SYS_FOPEN(pszConfigFilePath, "wt");
	if (!fileHandle)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error in opening the file: '%s'.", function, pszConfigFilePath);
		retVal = CONFIG_SYSTEM_ERROR;
		goto failCall;
	}
	else
	{
		pszJsonOutput = cJSON_Print(root);
		len = (Sys_Int)strlen(pszJsonOutput);
		SYS_FWRITE(pszJsonOutput, sizeof(Sys_Char), len, fileHandle);
		SYS_FCLOSE(fileHandle);
	}
	
failCall:
	if (pszConfigFilePath) {
		Sys_Free(pszConfigFilePath);
		pszConfigFilePath = NULL;
	}

	if (root){
		cJSON_Delete(root);
		root = NULL;
	}

	SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: exited with failure!", function);
	return retVal;
}


void SetOfflineParam()
{
	Sys_Char *function = "SetOfflineParam";
	Sys_Char *pszConfigFilePath = GetFilePathByName(CONFIG_FOLDER_NAME, STR_FILE_OFFLINE_MSG);
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	//Sys_Char *pszConfigFilePath = GetFilePathByName(CONFIG_FOLDER_NAME, STR_FILE_OFFLINE_MSG);
	if (pszConfigFilePath != NULL)
		{
		cJSON *pJsonOffline = NULL;
		Sys_Char *pszBufOffline = ReadFileContent(pszConfigFilePath);
		pJsonOffline = cJSON_Parse(pszBufOffline);
		Sys_Free(pszBufOffline);
		if (pJsonOffline)
		{
			cJSON *pOfflineStart = cJSON_GetObjectItem(pJsonOffline,
				STR_OFFLINE_MSG);
			twcfg.offline_msg_queue_size = cJSON_GetObjectItem(pOfflineStart,
				STR_MSG_SIZE)->valueint;
			twcfg.offline_msg_store_dir = cJSON_GetObjectItem(pOfflineStart,
				STR_DIRECTORY)->valuestring;
			twApi_SetOfflineMsgStoreDir(twcfg.offline_msg_store_dir);
			Sys_Free(pszConfigFilePath);
			cJSON_Delete(pJsonOffline);
		}
	}
	else
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "Starting up");
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
}

Asset_Type AssetType(Sys_Char *type)
{
	Sys_Char *function = "AssetType";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	if (strcmp(type, "ASSET") == 0 || strcmp(type, "asset") == 0)
	{
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
		return ASSET;
	}
	else if (strcmp(type, "PLUM") == 0 || strcmp(type, "plum") == 0)
	{
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
		return PLUM;
	}
	else if (strcmp(type, "SYSTEM_CONTROLLER") == 0 || strcmp(type, "systemController") == 0)
	{
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
		return SYSTEM_CONTROLLER;
	}
	else
	{
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
		return ASSET; //TODO: Vishal: Default case should be handled.
	}
}

Sys_Int DataRateForUnits(Sys_Char *unit)
{
	Sys_Char *function = " DataRateForUnits";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	if (strcmp(unit, "UNIT_MSEC") == 0 || strcmp(unit, "msec") == 0)
	{
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
		return 0;
	}
	else if (strcmp(unit, "UNIT_SEC") == 0 || strcmp(unit, "sec") == 0)
	{
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
		return 1;
	}
	else if (strcmp(unit, "UNIT_MIN") == 0 || strcmp(unit, "min") == 0)
	{
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
		return 2;
	}
	else if (strcmp(unit, "UNIT_HOUR") == 0 || strcmp(unit, "hour") == 0)
	{
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
		return 3;
	}
	else if (strcmp(unit, "UNIT_DAY") == 0 || strcmp(unit, "day") == 0)
	{
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
		return 4;
	}
	else
	{
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
		return 5;
	}
}

Sys_Ulong TimerReconfig(
	Sys_Ulong delayTime
	)
{
	Sys_Ulong retVal = 0;
	Sys_Char *function = "TimerReconfig";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	if (delayTime <= 1000) // less than 1 sec
		return ((delayTime * 60) / 100);

	else if (delayTime <= 300000) // Less than 5 min
		return ((delayTime * 60) / 100);

	else if (delayTime <= 3600000) // Less than 1 hour
		return ((delayTime * 30) / 100);

	else // More than 1 Hours
		return ((HOUR_IN_MSEC_KEYSIGHT * 30) / 100);

	//else if (delayTime <= 86400000) // Less than 1 day
	//	return ((delayTime * 90) / 100);

	//else if (delayTime <= 4233600000) // Less than 49 days
	//	return ((delayTime * 95) / 100);

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return retVal;
}

Sys_Ulong delay_generator() {
	Sys_Ulong acqHealth = 0;
	Sys_Ulong acqUtil = 0;
	Sys_Ulong acqEnv = 0;
	Sys_Ulong acqInfo = 0;
	Sys_Ulong num[4];
	Sys_Ulong temp = 0;
	int i = 0;
	int j = 0;

	Sys_Char *function = "delay_generator";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	//twMutex_Lock(pConfigparam->mutexHdl);
	acqHealth = pConfigparam->acquisition.health; //t1
	acqUtil = pConfigparam->acquisition.utilization; //t2
	acqEnv = pConfigparam->acquisition.environment; //t3
	acqInfo = pConfigparam->acquisition.information; //t4
	//twMutex_Unlock(pConfigparam->mutexHdl);

	if (!acqHealth && !acqUtil && !acqEnv && !acqInfo) /**< This condition was added to avoid the scenerio when all the rates are 0 */
		return FIVE_MIN_IN_MSEC_KEYSIGHT;
	else {
		num[0] = acqHealth;
		num[1] = acqUtil;
		num[2] = acqEnv;
		num[3] = acqInfo;

		for (i = 0; i < 4; ++i)
		{
			for (j = i + 1; j < 4; ++j)
			{
				if (num[i] > num[j])
				{
					temp = num[i];
					num[i] = num[j];
					num[j] = temp;
				}
			}
		}

		i = 0;
		if (num[i] > 0)
			return num[i];
		else {
			while (num[i] <= 0)
				i++;
			return num[i];
		}
	}
}

#ifdef WIN32
DWORD WINAPI ConfigThreadFunction(void* pVoid)
#else
void* ConfigThreadFunction(void* pVoid)
#endif
{
	Sys_Int twRetCode = TW_OK;
	/* void *assets = NULL; */
	/* twPrimitive *pJsonHealthValue = NULL; */
	SysThreadStruct* pThrdStrct = NULL;
	Sys_Char *function = "ConfigThreadFunction";
	/* cJSON *pJsonHealth = NULL; ToDo-Soumya-test code for CJON object */
	Sys_Ulong delayTime = 0;

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	// The pVoid input parameter is always the thread struct pointer
	pThrdStrct = (SysThreadStruct*)pVoid;
	if (!pThrdStrct) {
		// Log error & exit
		SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "%s:  Thread struct is NULL. Exiting thread!", function);
		return -1;
	}
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s:  Thread started.  Thread id = %lu", function, pThrdStrct->m_threadId);

	SysMutex_Lock(pConfigparam->mutexHdl);
	delayTime = delay_generator(); //pConfigparam->acquisition.health;
	SysMutex_Unlock(pConfigparam->mutexHdl);

	// cwu - keep timer cal logic in the function
	pThrdStrct->m_waitMilliSec = TimerReconfig(delayTime);


	SysAppLog(SYS_INFO, MODULE_EMS_CONFIG, "%lu: TimerReconfig Output", pThrdStrct->m_waitMilliSec);
	// continue processing data forever or at post rate while bRunning
	while (pThrdStrct->m_bRunning)
	{				
		if (!twWs_IsConnected(tw_api->mh->ws) || !(tw_api->isAuthenticated)){ //Was added to have a Authentication check (Issue: If AppKey is missing on the platform)

			SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "%s:Trying to re-connect ", function);
			/** Bind our thing **/
			twRetCode = twApi_BindThing(pConfigparam->m_ThingName);
			if (twRetCode != TW_OK)
			{
				// todo:  define failure scenario if bind fails.
				SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Unable to bind. Error Code: %d", function, twRetCode);
			}
			else
			{
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "Binding done");
			}

			/* Connect to server */
			twRetCode = twApi_Connect(twcfg.connect_timeout, twcfg.connect_retries);
			if (twRetCode != TW_OK)
			{
				SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG,
					"%s: Server connection failed after %d attempts.  Error Code: %d", function,
					CONNECT_RETRIES, twRetCode);
			}
			else
			{
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "Server connection done.");
			}
		}
		else {
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s:  twWs_IsConnected = %d", function, twWs_IsConnected(tw_api->mh->ws));
		}
#ifdef SCPI_ENABLE
		twRetCode = SCPI_Restart(); 
		
		if (twRetCode != TW_OK)
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s:   return value of the scpi_restart = %d", function, twRetCode);
		else
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s:   return value of the scpi_restart = %d", function, twRetCode);
#endif
		SysThreadWaitForRunCycle(pThrdStrct);
		if (!pThrdStrct->m_bRunning) {
			SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s:  Exiting thread as pThrdStrct->m_bRunning= ",
				function, pThrdStrct->m_bRunning);
			break;
		}
	//	pThrdStrct->m_waitMilliSec = delayTime;
		//if (delayTime != delay_generator())
		//	delayTime = delay_generator();
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);

	return 0;
}

//Checks for Static parameter change - Compares with previous Config.json values and 
Sys_Int CheckForChangeConfig(void) {

	Sys_Int err = TW_OK;
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	Sys_Char *function = "CheckForChangeConfig";

	Sys_Char *pszWs_connection = STR_FILE_WS_CONNECTION;
	Sys_Char *pszConfigFilePath = GetFilePathByName(CONFIG_FOLDER_NAME, pszWs_connection);
	Sys_Char *pszBufWS = NULL;
	cJSON *pJsonRoot = NULL;
	cJSON *pJsonStart = NULL;
	cJSON *pJsonAsset = NULL;
	Sys_Char *ThingName = NULL;
#ifdef WINCE
	Sys_Char *pTempOfflinePath = NULL;
	Sys_Char msgFolderBuf[MAX_PATH];
#endif

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	SysMutex_Lock(pConfigparam->mutexHdl);
	pszBufWS = ReadFileContent(pszConfigFilePath);
	if (pszBufWS != NULL)
	{
		/*json object will have the parsed value of the data*/
		pJsonRoot = cJSON_Parse(pszBufWS);
		Sys_Free(pszBufWS);
		pszBufWS = NULL;
		if (!pJsonRoot) {
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: --> INVALID JSON FILE", function);
			retVal = CONFIG_WRONG_IP_PARAMS;
			goto failCall;
		}
		/*Gets the 1st JSON item in the JSON object*/
		pJsonStart = cJSON_GetObjectItem(pJsonRoot, STR_HYRAX_SERVER);
		if (pJsonStart == NULL) {
			retVal = CONFIG_FILE_RW_ERROR;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error reading config json header!", function);
			goto failCall;
		}

		if (pConfigparam != NULL) {
			if (twcfg.max_message_size != cJSON_GetObjectItem(pJsonStart, STR_MAX_MESSAGE_SIZE)->valueint) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "max_message_size field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}

			if (Sys_StringCmp(pConfigparam->m_HostName, Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_HOSTNAME)->valuestring)) != 0) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "hostname field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}


			if (pConfigparam->m_Port != cJSON_GetObjectItem(pJsonStart, STR_PORT)->valueint) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "port field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}

			//For Asset details
			pJsonAsset = cJSON_GetObjectItem(pJsonStart, STR_ASSET);
			if (Sys_StringCmp(pConfigparam->m_Asset.pId, Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_ID)->valuestring)) != 0) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "id field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}
			if (Sys_StringCmp(pConfigparam->m_Asset.comType, Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_COM_TYPE)->valuestring)) != 0) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "asset_com_type field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}
			if (Sys_StringCmp(pConfigparam->m_Asset.comAddr, Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_COM_ADDR)->valuestring)) != 0) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "asset_com_addr field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}
			if (Sys_StringCmp(pConfigparam->m_Asset.comPort, Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_COM_PORT)->valuestring)) != 0) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "asset_com_port field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}
			if (Sys_StringCmp(pConfigparam->m_Asset.appName, Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_APP_NAME)->valuestring)) != 0) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "asset_app_name field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}
			if (pConfigparam->m_Asset.Type != AssetType(Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_TYPE)->valuestring))) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "type field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}
			if (pConfigparam->m_Asset.refVolt != cJSON_GetObjectItem(pJsonAsset, STR_ASSET_REF_VOLT)->valuedouble) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "asset_ref_volt field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}
			if (Sys_StringCmp(pConfigparam->m_Asset.misc, Sys_StrDup(cJSON_GetObjectItem(pJsonAsset, STR_ASSET_MISC)->valuestring)) != 0) {
				SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "asset_misc field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}
			//End Asset details

			ThingName = (Sys_Char*)Sys_Malloc(strlen(Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_THINGNAME)->valuestring)) + 2);
			strcpy(ThingName, "*");
			strcat(ThingName, Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_THINGNAME)->valuestring));
			if (Sys_StringCmp(pConfigparam->m_ThingName, ThingName) != 0) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "thing_name field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}

			/* added proxy details ----------------------------------------------------------------------------------------------------*/

			if (Sys_StringCmp(pConfigparam->m_ProxyHostName, Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_PROXY_HOSTNAME)->valuestring)) != 0) {
				SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "proxy_hostname field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}

			if (Sys_StringCmp(pConfigparam->m_ProxyPort, Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_PROXY_PORT)->valuestring)) != 0) {
				SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "proxy_port field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}
			//-----------------------------------------------------------------------------------------------------------------------------
			if (Sys_StringCmp(pConfigparam->m_AppKey, Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_APPKEY)->valuestring)) != 0) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "app_key field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}

			if (Sys_StringCmp(pConfigparam->PEMCertFile, Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_PEM_FILE)->valuestring)) != 0) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "PEM_file field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}

			if (Sys_StringCmp(pConfigparam->m_Encryption, Sys_StrDup(cJSON_GetObjectItem(pJsonStart, STR_ENCRYPTION)->valuestring)) != 0) {
				SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "encryption field of Config.json Changed", function);
				retVal = CONFIG_FW_ERROR;
			}

			//ToDo:Abhishek: All error scenerios to be checked for Max Message Size and other params
			//ToDo:Abhishek: Checking For File Transfer params is not done
		}
		if (ThingName) {
			Sys_Free(ThingName);
			ThingName = NULL;
		}
		if (pszConfigFilePath) {
			Sys_Free(pszConfigFilePath);
			pszConfigFilePath = NULL;
		}
		if (pJsonRoot) {
			cJSON_Delete(pJsonRoot);
			pJsonRoot = NULL;
		}
		SysMutex_Unlock(pConfigparam->mutexHdl);
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
		return retVal;
	}
failCall:
	if (ThingName) {
		Sys_Free(ThingName);
		ThingName = NULL;
	}
	if (pszConfigFilePath) {
		Sys_Free(pszConfigFilePath);
		pszConfigFilePath = NULL;
	}
	if (pJsonRoot) {
		cJSON_Delete(pJsonRoot);
		pJsonRoot = NULL;
	}
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited with failure!", function);
	SysMutex_Unlock(pConfigparam->mutexHdl);

	return (retVal);
}

/*Fetches the value from Config.json of keysight & sets the values in the sidecar config*/

ConfigErrCodes  UpdateSideCarConfig()
{
	
	/*reading sidecar_config to populate the value in pSidecarConf*/
	Sys_Char *Sc_wsConnection = SC_FILE_WS_CONNECTION;
	Sys_Char *pszScConfigFilepath = GetFilePathByName(SIDECAR_CONFIG_FOLDER_NAME, Sc_wsConnection);

	Sys_Char *pszBufScWS = NULL;
	
	cJSON *pJsonRoot = NULL;
	Sys_Char *out = NULL;
	Sys_Char *WS_EMSThing = NULL;
	Sys_Char *searched_string = NULL;
	Sys_Char *temp = NULL;
	Sys_Char *WSEMS = "-WSEMS";
	Sys_Int proxyPortTmp = 0;
#ifdef WINXP
	cJSON *server_config = NULL;
	cJSON *proxy = NULL;
#else // WINXP
	cJSON *ws_server = NULL;
	cJSON *WShost = NULL;
	cJSON *WSport = NULL;
	cJSON *proxy = NULL;
	cJSON *auto_bind = NULL;
	cJSON *ThingName = NULL;
	cJSON *autobind_host = NULL;
	cJSON *autobind_port = NULL;
	
#endif

	Sys_Char *function = "UpdateSideCarConfig";
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	pszBufScWS = ReadFileContent(pszScConfigFilepath);


	/*parsing the sidecar config*/
	if (pszBufScWS != NULL)
	{
		/*json object will have the parsed value of the data*/
		pJsonRoot = cJSON_Parse(pszBufScWS);
		Sys_Free(pszBufScWS);
		pszBufScWS = NULL;
		if (!pJsonRoot) {
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: --> INVALID JSON FILE", function);
			retVal = CONFIG_WRONG_IP_PARAMS;
			goto failCall;
		}

		//logic for appending "WS" in thingname for sedecar config
		temp = (Sys_Char*)Sys_Malloc(strlen(pConfigparam->m_ThingName) + 1);
		strcpy(temp, (pConfigparam->m_ThingName + 1));
		searched_string = strtok(temp, "-");
		int len = strlen(WSEMS);
		WS_EMSThing = (Sys_Char*)Sys_Malloc(strlen(searched_string) + len + 1);
		strcpy(WS_EMSThing, searched_string);
		strcat(WS_EMSThing, WSEMS);
		if (pConfigparam->m_ProxyPort) {				//Since NULL is not equal to ""
			if (!Sys_StringCmp(pConfigparam->m_ProxyPort, ""))
			{
				proxyPortTmp = 0;
			}
			else
			{
				proxyPortTmp = atoi(pConfigparam->m_ProxyPort);
			}
		}

#ifdef WINXP
		server_config = cJSON_GetObjectItem(pJsonRoot, XP_SERVER_CONFIG);
		cJSON_ReplaceItemInObject(server_config, XP_HOST_NAME, cJSON_CreateString(pConfigparam->m_HostName));

		cJSON_SetIntValue(cJSON_GetObjectItem(server_config, XP_PORT), pConfigparam->m_Port);

		cJSON_ReplaceItemInObject(server_config, XP_APP_KEY, cJSON_CreateString(pConfigparam->m_AppKey));

		cJSON_ReplaceItemInObject(server_config, XP_THING_NAME, cJSON_CreateString(WS_EMSThing));

		proxy = cJSON_GetObjectItem(server_config, XP_PROXY);
		cJSON_ReplaceItemInObject(proxy, XP_PROXY_HOST, cJSON_CreateString(pConfigparam->m_ProxyHostName));

		cJSON_SetIntValue(cJSON_GetObjectItem(proxy, XP_PROXY_PORT), proxyPortTmp);

		// Enable the below line if the proxy_port value is string in the Sidecar config.json.
		//cJSON_ReplaceItemInObject(proxy, XP_PROXY_PORT, cJSON_CreateString(pConfigparam->m_ProxyPort));

#else /*WIN32 , LINUX */

		/*Gets the 1st JSON item in the JSON object*/
		ws_server = cJSON_GetObjectItem(pJsonRoot, SC_WS_SERVER);
		if (ws_server == NULL) {
			retVal = CONFIG_FILE_RW_ERROR;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error reading config json header!", function);
			goto failCall;
		}
		WShost = cJSON_GetArrayItem(ws_server, 0);
		cJSON_ReplaceItemInObject(WShost, SC_HOSTNAME, cJSON_CreateString(pConfigparam->m_HostName));

		strcpy(cJSON_GetObjectItem(WShost, SC_HOSTNAME)->valuestring, pConfigparam->m_HostName);

		WSport = cJSON_GetArrayItem(ws_server, 0);
		cJSON_SetIntValue(cJSON_GetObjectItem(WSport, SC_PORT), pConfigparam->m_Port);

		proxy = cJSON_GetObjectItem(pJsonRoot, SC_PROXY);
		if (proxy) {
			if (pConfigparam->m_ProxyHostName) {
				cJSON_ReplaceItemInObject(proxy, SC_PROXY_HOST, cJSON_CreateString(pConfigparam->m_ProxyHostName));
			}
			else
			{
				cJSON_ReplaceItemInObject(proxy, SC_PROXY_HOST, cJSON_CreateString("\0"));
			}

			cJSON_SetIntValue(cJSON_GetObjectItem(proxy, SC_PROXY_PORT), proxyPortTmp);
		}
		
		// Enable the below line if the proxy_port value is string in the Sidecar config.json.
		//cJSON_ReplaceItemInObject(proxy, SC_PROXY_PORT, cJSON_CreateString(pConfigparam->m_ProxyPort));

		auto_bind = cJSON_GetObjectItem(pJsonRoot, SC_AUTO_BIND);
		ThingName = cJSON_GetArrayItem(auto_bind, 0);
		
		cJSON_ReplaceItemInObject(ThingName, SC_THINGNAME, cJSON_CreateString(WS_EMSThing));

		autobind_host = cJSON_GetArrayItem(auto_bind, 0);
		cJSON_ReplaceItemInObject(autobind_host, SC_HOSTNAME, cJSON_CreateString(pConfigparam->m_HostName));

		autobind_port = cJSON_GetArrayItem(auto_bind, 0);
		cJSON_SetIntValue(cJSON_GetObjectItem(autobind_port, SC_PORT), pConfigparam->m_Port);
				
		cJSON_ReplaceItemInObject(pJsonRoot, SC_APPKEY, cJSON_CreateString(pConfigparam->m_AppKey));

#endif //WINXP

		out = cJSON_Print(pJsonRoot);
		FILE *f = SYS_FOPEN(pszScConfigFilepath, "w");
		fprintf(f, "%s\n", out);
		SYS_FCLOSE(f);
		/* Enable this line to print the updated config.json in the keysight logs as well */
		//printf("%s\n", out);
		SysAppLog(SYS_INFO, MODULE_EMS_CONFIG, "%s: --> SIDECAR CONFIG AUTO-UPDATION IS DONE", function);
		free(out);

		if (pszScConfigFilepath) {
			Sys_Free(pszScConfigFilepath);
			pszScConfigFilepath = NULL;
		}
		if (WS_EMSThing) {
			Sys_Free(WS_EMSThing);
			WS_EMSThing = NULL;
		}
		if (pJsonRoot != NULL) {
			cJSON_Delete(pJsonRoot);
			pJsonRoot = NULL;
		}

		if (temp) {
			Sys_Free(temp);
			temp = NULL;
		}

		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: --> exited ", function);
		return retVal;
	}

failCall:

	if (pszScConfigFilepath) {
		Sys_Free(pszScConfigFilepath);
		pszScConfigFilepath = NULL;
	}

	if (WS_EMSThing) {
		Sys_Free(WS_EMSThing);
		WS_EMSThing = NULL;
	}

	if (pJsonRoot) {
		cJSON_Delete(pJsonRoot);
		pJsonRoot = NULL;
	}

	if (temp) {
		Sys_Free(temp);
		temp = NULL;
	}
}