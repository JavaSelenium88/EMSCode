/*****************************************************************************
//
//  Copyright © 2016 ITC .  All rights reserved.
//
******************************************************************************
//
//  Filename   :  init.h
//
//  Subsystem  :  KeySight
//
//  Author: Soumya Ranjan Bej
//
//  Description:
//
//                Initilization of connection with Thingworx Platform and binding the EMS
//                agent as a "Thing"
//
******************************************************************************/

#ifndef EMS_CONFIG_H_
#define EMS_CONFIG_H_

#include "SysThread.h"
#include "twOSPort.h"
#include "twApi.h"

/********************************************** Interface Datatypes **********************************************/
#define KEYSIGHT_VERSION "2.0.0"
typedef void *pConfHdl;
#define STR_ENV_PARAMS "Enviornment_params"
#define STR_HEALTH_PARAMS "Health_params"

/*
* WinCE device Location for storing Message and Log files
* */
#ifdef WINCE
#ifdef WINCE_ARM
#define WINCE_LOG_MSG_ROOT_FOLDER "\\InternalSD2\\"
#else /**WinCE_x86**/
#define WINCE_LOG_MSG_ROOT_FOLDER "\\Temp\\"
#endif /**End of WINCE_ARM**/
#endif /**End of WINCE**/


typedef enum Config_Error_Codes_T {
	CONFIG_SUCCESS = 0, /**< No error */
	CONFIG_INSUFFICIENT_MEMORY = -1, /**< Memory allocation failed */
	CONFIG_WRONG_IP_PARAMS = -2, /**< Wrong input/invalid parameters passed */
	CONFIG_SYSTEM_ERROR = -3, /**< Some issue with system/platform */
	CONFIG_TWX_ERROR = -4, /**< Thingworx api/c-sdk related errors */
	CONFIG_FILE_RW_ERROR = -5, /**< File read-write error */
	CONFIG_EMS_AGENT_ERROR = -6, /**< EMS Agent error */
	CONFIG_FW_ERROR = -7, /**< File Watcher Fuctionality errors */
	CONFIG_WRONG_PROXY_PARAMS = -8 /**< Wrong input/invalid proxy parameters passed */
}ConfigErrCodes;

typedef enum Asset_Type_T {
	ASSET,
	PLUM,
	SYSTEM_CONTROLLER
}Asset_Type;

typedef struct Asset_Details_T {
	Sys_Char *pId; /**< Asset ID/MAC number */
	Asset_Type Type; /**< Type of Asset */
	Sys_Char *comType; /**< Type of Asset Communication */
	Sys_Char *comAddr; /**< Address of Communication */
	Sys_Char *comPort; /**< Port of Communication */
	Sys_Char *appName; /**< Application Name */
	Sys_Double refVolt; /**< Plum Reference voltage */
	Sys_Char *misc; /**< Miscellaneous items */
}Asset_Details, *pAssetDetails;

typedef enum DataRateUnits_T {
	UNIT_MSEC, /**< mili seconds */
	UNIT_SEC, /**< seconds */
	UNIT_MIN, /**< minutes */
	UNIT_HOUR, /**< hours */
	UNIT_DAY /**< days */
}DataRateUnits;

typedef struct DataRate_T {
	DataRateUnits unit; /**< Unit per rate */
	Sys_Ulong health; /**< Health rate */
	Sys_Ulong environment; /**< Environment rate */
	Sys_Ulong utilization; /**< Utilization rate */
	Sys_Ulong information; /**< Information rate */
}DataRate, *pDataRate;

typedef struct ConfigParam_T
{
	Asset_Details m_Asset;
	Sys_Bool m_EmsStatus;
	Sys_Char *m_ConfigVersion;
	Sys_Char *m_ThingName;
	Sys_Char *m_HostName;
	Sys_Char *PEMCertFile;
	Sys_Int m_Port;
	Sys_Char *m_AppKey;
	Sys_Char *m_Encryption;
	Sys_Ulong Max_Message_Size;
	DataRate acquisition;
	//Posting rate is removed from config.josn.
	//DataRate posting;
	Sys_Bool configDone;
	Sys_Bool logDone;
	Sys_Bool offlineDone;
	Sys_Char *m_ProxyHostName;//May 02,2018 -Adding to support Proxy server configuration
	Sys_Char *m_ProxyPort;
	SYS_MUTEX mutexHdl;
}configparam;

/********************************************** Interface APIs **********************************************/

ConfigErrCodes EMSConfig_Init(
	void **ppHdl /**< Opaque handle to be registered */
	);

ConfigErrCodes EMSConfig_Uninit(
	void *pHdl /**< Opaque handle */
	);

ConfigErrCodes EMSConfig_Start(
	void *pHdl /**< Opaque handle */
	);

ConfigErrCodes EMSConfig_Stop(
	void *pHdl /**< Opaque handle */
	);

Sys_Int ConnectToTWPlatform_Start(
	void *pHdl /**< Opaque handle */
);

ConfigErrCodes GetConfigData(configparam **pConfig);

ConfigErrCodes FreeConfigData(configparam *pConfig);

#endif /* EMS_CONFIG_H_ */