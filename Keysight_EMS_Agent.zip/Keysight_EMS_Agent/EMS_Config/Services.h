/******************************************************************************
//
//  Filename   : services.h
//
//  Subsystem  : KeySight
//
//  Author     : Akshata N
//
//  Description:
//
//                Services related functionality are handled here.
//
******************************************************************************/


#ifndef SERVICES_H_
#define SERVICES_H_
#include "twInfoTable.h"
#include "OS_Utilities.h"
/*
 * Invokes a service on the platform by sending ThingName and AppKey
 * */
Sys_Int Register();
Sys_Int RegisterServices();

/* Callback function to retreive Timestamp and send it to the server*/
enum msgCodeEnum GetEMSTimestampCallback(const char * entityName,
	const char * serviceName,
	twInfoTable * params,
	twInfoTable ** content,
	void * userdata);

/* Callback function to Start EMS remotly*/
enum msgCodeEnum StartEMSCallback(const char * entityName,
	const char * serviceName,
	twInfoTable * params,
	twInfoTable ** content,
	void * userdata);

/* Callback function to Stop EMS remotly*/
enum msgCodeEnum StopEMSCallback(const char * entityName,
	const char * serviceName,
	twInfoTable * params,
	twInfoTable ** content,
	void * userdata);

/* Callback function to Stop EMS remotly*/
enum msgCodeEnum StopEMSGracefullyCallback(const char * entityName,
	const char * serviceName,
	twInfoTable * params,
	twInfoTable ** content,
	void * userdata);

/* Callback function to Start Sidecar/LSR remotely*/
enum msgCodeEnum StartSideCarCallback(const char * entityName,
	const char * serviceName,
	twInfoTable * params,
	twInfoTable ** content,
	void * userdata);

/* Callback function to Stop Sidecar/LSR remotly*/
enum msgCodeEnum StopSideCarCallback(const char * entityName,
	const char * serviceName,
	twInfoTable * params,
	twInfoTable ** content,
	void * userdata);

/* Function to Stop Sidecar/LSR manually*/
Sys_Int StopSideCarFunction(Sys_Char *dumpFilePath);

#endif /* SERVICES_H_ */
