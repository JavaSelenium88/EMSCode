//*****************************************************************************
//
//  Copyright � 2016 ITC .  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  FileWatcher.h
//
//  Subsystem  :  Keysight
//
//  Author: Akshata N
//
//  Description:
//
//                Observes for file transfer updates
//
//*****************************************************************************
#ifndef FILEWATCHER_H_
#define FILEWATCHER_H_
#include "twFileManager.h" 


void FileWatcherTask(DATETIME now, void *params);
void FileCallbackFunc(Sys_Char fileRcvd, twFileTransferInfo *info, void *userdata);
Sys_Int configChangeCallback(Sys_Char *pszConfigFolderPath, Sys_Char *pszConfigFolderName);

#endif /* FILEWATCHER_H_ */
