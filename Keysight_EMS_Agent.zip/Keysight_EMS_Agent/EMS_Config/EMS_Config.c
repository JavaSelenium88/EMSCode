/*****************************************************************************
//
//  Copyright © 2016 ITC .  All rights reserved.
//
******************************************************************************
//
//  Filename   :  init.c
//
//  Subsystem  :  KeySight
//
//  Author: Soumya Ranjan Bej
//
//  Description: Initilization of connection with Thingworx Platform and binding the EMS
//                agent as a "Thing"
//
******************************************************************************/

#include "Properties.h"
#include "Services.h"
#include "FileWatcher.h"
#include "SysEvent.h"
#include "SysLog.h"
#include "JsonObjectCreator.h"
#include "Sysapi.h"
#include "OS_Utilities.h"
#include "EMS_Config.h"
#include "EMS_Config_Utils.h"

#define DATA_UPDATION_RATE_MSEC 5000
#define FILE_WATCHER_RATE_MSEC 5000

// Function Prototypes fpr local functions
//Sys_Int ConnectToTWPlatform_Start();
//Sys_Int ConnectToTWPlatform_Initalize();
//Sys_Int InitSecureConnection(char *PEMFiles);


//Globals for SideCar Config parsing Utility--- Start***************
#define MAX 254
int val1 = 0, val2 = 0; /*temporary variable*/
#ifndef WINXP
//char fname[MAX] = "C:\\Program Files\\Keysight\\Keysight_EMS_Agent\\SideCar_EMS\\etc\\config.json"; // File to modified
char fname[MAX] = "./SideCar_EMS/etc/config.json";

#endif
#ifdef WINXP
char fname[MAX] = "./SideCar_EMS/ConfigFiles/server_config.json";
#endif
//char fname[MAX] = "config.json";

/*variables to store the replacing string line number in file*/
int wsServerHostlineNo = 0, wsServerPortlineNo = 0, autobindHostlineNo = 0, \
							autobindPortlineNo = 0, httpserverHostlineNo = 0, \
							httpserverPortlineNo = 0;

/* Not using this code as we have another method which auto updates the Sidecar Config.json using the JSON API*/
/*
	ConfigErrCodes EMSConfig_ReadSideCarConfig(Sys_Char *wsServer_Host, \
	Sys_Char *wsServer_Port, \
	Sys_Char *autobind_Name, \
	Sys_Char *autobind_Host, \
	Sys_Char *autobind_Port, \
	Sys_Char *file_Appkey)
{
	Sys_Char *function = "ReadSideCarConfig";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	//WsHostName
	Sys_Char ModifiedHost[MAX] = ": \"";
	strcat(ModifiedHost, pConfigparam->m_HostName);
	strcat(ModifiedHost, "\",\n");
	Sys_StringCpy(wsServer_Host, ModifiedHost, strlen(ModifiedHost) + 1);

	//WsPort
	Sys_Char ModifiedPort[MAX] = ": ";
	Sys_Char wsServer_PortTemp[20];
	sprintf(wsServer_PortTemp, "%d", pConfigparam->m_Port);
	strcat(ModifiedPort, wsServer_PortTemp);
#ifdef WINXP
	strcat(ModifiedPort, "\,\n");
#endif
#ifndef WINXP
	strcat(ModifiedPort, "\n");
#endif
	Sys_StringCpy(wsServer_Port, ModifiedPort, strlen(ModifiedPort) + 1);
	//SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "$$$$$$$$Value of Host- %s", wsServer_Port);

	//autobind_ThingName
	Sys_Char ModifiedThingName[MAX] = "";
	//Sys_Char *ModifiedTempThingName= pConfigparam->m_ThingName;
	Sys_Char temp[MAX] = ": \"";//temps for removing "-EMS"
	strcat(temp, pConfigparam->m_ThingName + 1);
	strcat(temp, "\0");
	strncpy(ModifiedThingName, temp, strlen(temp) - 4);//Removing the "-EMS"
	strcat(ModifiedThingName, "-WSEMS\",\n");
	Sys_StringCpy(autobind_Name, ModifiedThingName, strlen(ModifiedThingName) + 1);

	//AutoBindHostName
	Sys_StringCpy(autobind_Host, ModifiedHost, strlen(ModifiedHost) + 1);

	//AutoBindPort
	Sys_Char ModifiedAutoPort[MAX] = ": ";
	Sys_Char auto_PortTemp[20];
	sprintf(auto_PortTemp, "%d", pConfigparam->m_Port);
	strcat(ModifiedAutoPort, auto_PortTemp);
	strcat(ModifiedAutoPort, ",\n");
	Sys_StringCpy(autobind_Port, ModifiedAutoPort, strlen(ModifiedAutoPort) + 1);
	//SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "$$$$$$$$Value of Host- %s", autobind_Port);

	//AppKey
	Sys_Char ModifiedAppkey[MAX] = ": \"";
	strcat(ModifiedAppkey, pConfigparam->m_AppKey);
#ifdef WINXP
	strcat(ModifiedAppkey, "\",\n");
#endif

#ifndef WINXP
	strcat(ModifiedAppkey, "\"\n");
#endif
	Sys_StringCpy(file_Appkey, ModifiedAppkey, strlen(ModifiedAppkey) + 1);
	//SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "$$$$$$$$Value of Host- %s", file_Appkey);

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited", function);
	return CONFIG_SUCCESS;
}*/

//To find the line number of each replacing string in file
/*
int FindLine(const char *word, const char *file, int x)
{
	Sys_Char *function = "FindLine";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	char line[1024];
	val1 = 0;
	FILE* fp = fopen(file, "r");
	if (!fp)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Unable to open the Sidecar Config file!!\n.", function);
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited", function);
		return 0;
	}
	while (fgets(line, 1024, fp) != NULL)
	{
		if (x == 1)
			val1++;
		else
			val2++;
		if (strstr(line, word) != NULL)
		{
			if (x == 1) {
				if (val1>val2) {
					fclose(fp);
					SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited", function);
					return val1;
				}
			}
			else {
				fclose(fp);
				SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited", function);
				return val2;
			}
		}
	}
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited", function);
	return 0;
} 
*/
/*
char *replaceLine(char strKey[], const char *strVal) //Returns compete line to be replaced
{
	Sys_Char *function = "replaceLine";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	char *ptr = NULL;
	ptr = strchr(strKey, ':');
	if (ptr != NULL) {
		*ptr = '\0';
	}
	strcat(strKey, strVal);
	ptr = NULL;
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited", function);
	return strKey;
}
int replace(Sys_Char *wsServer_Host, Sys_Char *wsServer_Port, \
	Sys_Char *autobind_Name, Sys_Char *autobind_Host, \
	Sys_Char *autobind_Port, Sys_Char *file_Appkey)  //To modify the file
{
	Sys_Char *function = "replace";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	FILE *fptr1, *fptr2;
	int linectr = 0;
	char str[MAX];
	char temp[] = "temp.txt";
	fptr1 = fopen(fname, "r");
	if (!fptr1)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Unable to open the Sidecar Config file!!\n.", function);
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: Exited", function);
		return 0;
	}
	fptr2 = fopen(temp, "w");
	if (!fptr2)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Unable to open a temporary file to write!!\n", function);
		fclose(fptr1);
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: Exited", function);
		return 0;
	}
	// copy all contents to the temporary file other except specific line
	while (!feof(fptr1))
	{
		strcpy(str, "\0");
		fgets(str, MAX, fptr1);
		if (!feof(fptr1))
		{
			linectr++;
			if (linectr == wsServerHostlineNo) {
				fprintf(fptr2, "%s", replaceLine(str, wsServer_Host));
			}
			else if (linectr == wsServerPortlineNo) {
				fprintf(fptr2, "%s", replaceLine(str, wsServer_Port));
			}
#ifndef WINXP
			else if (linectr == autobindHostlineNo) {
				fprintf(fptr2, "%s", replaceLine(str, autobind_Host));
			}
			else if (linectr == autobindPortlineNo) {
				fprintf(fptr2, "%s", replaceLine(str, autobind_Port));
			}
#endif
			else if (linectr == httpserverHostlineNo) {
				fprintf(fptr2, "%s", replaceLine(str, autobind_Name));
			}
			else if (linectr == httpserverPortlineNo) {
				fprintf(fptr2, "%s", replaceLine(str, file_Appkey));
			}
			else {
				fprintf(fptr2, "%s", str);
			}
		}
	}
	fclose(fptr1);
	fclose(fptr2);
	remove(fname);
	rename(temp, fname);
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: Exited", function);
	return 0;
}*/
/*
ConfigErrCodes EMSConfig_SideCarConfigUpdate(Sys_Char *wsServer_Host, \
	Sys_Char *wsServer_Port, \
	Sys_Char *autobind_Name, \
	Sys_Char *autobind_Host, \
	Sys_Char *autobind_Port, \
	Sys_Char *file_Appkey)
{
	Sys_Char *function = "EMSConfig_SideCarConfigUpdate";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	ConfigErrCodes retVal = CONFIG_SUCCESS;
	const char *str1 = "port";
#ifdef WINXP
	const char *str2 = "host_name";
	const char *str3 = "thing_identifier";
	const char *str4 = "app_key";

	const char *param1 = "server_config";
#endif
#ifndef WINXP
	const char *str2 = "host";
	const char *str3 = "name";
	const char *str4 = "appKey";

	const char *param1 = "ws_servers";
	const char *param2 = "auto_bind";
	const char *param3 = "auto_bind";
#endif
#ifdef WINXP
	FindLine(param1, fname, 0);
	wsServerPortlineNo = FindLine(str1, fname, 1);
	wsServerHostlineNo = FindLine(str2, fname, 1);
	httpserverHostlineNo = FindLine(str3, fname, 1);
	httpserverPortlineNo = FindLine(str4, fname, 1);
	val2 = 0;
#endif
#ifndef WINXP
	FindLine(param1, fname, 0);
	wsServerHostlineNo = FindLine(str2, fname, 1);
	wsServerPortlineNo = FindLine(str1, fname, 1);
	val2 = 0;

	FindLine(param2, fname, 0);
	autobindHostlineNo = FindLine(str2, fname, 1);
	autobindPortlineNo = FindLine(str1, fname, 1);
	val2 = 0;

	FindLine(param3, fname, 0);
	httpserverHostlineNo = FindLine(str3, fname, 1);
	httpserverPortlineNo = FindLine(str4, fname, 1);
#endif
#ifdef WINXP
	//replace(wsServer_Host, wsServer_Port, autobind_Name, file_Appkey);//ToDo:Soumya-Handle the error
#endif
	replace(wsServer_Host, wsServer_Port, autobind_Name, autobind_Host, autobind_Port, file_Appkey);//ToDo:Soumya-Handle the error
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited", function);
	return CONFIG_SUCCESS;
}*/

//SideCar Config parsing Utility--- Stop***************

//SideCar LSR Config parsing Utility--- Start***************
ConfigErrCodes WriteToSidecarLua() {

	Sys_Char *function = "WriteToSidecarLua";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	ConfigErrCodes retVal = CONFIG_SUCCESS;

	FILE *configHandle, *tempHandle;
	Sys_Char * sideCarConfigLua = "config.lua";
	Sys_Char * tempConfigLua = "temp.lua";
	//Enable this if testing with the service
	/*Sys_Char *ConfigLuaFile = GetFilePathByName(SIDECAR_CONFIG_FOLDER_NAME, sideCarConfigLua);
	Sys_Char *tempLuaFile = GetFilePathByName(SIDECAR_CONFIG_FOLDER_NAME, tempConfigLua);*/
	//Enable this if testing with the solution
	//Sys_Char *ConfigLuaFile = "config.lua";//location of Solution exe-\ems\Keysight_EMS_Agent\Windows\x86
	//Sys_Char *tempLuaFile = "temp.lua";

	Sys_Char *ConfigLuaFile = "./SideCar_EMS/etc/config.lua";
	Sys_Char *tempLuaFile = "./SideCar_EMS/etc/temp.lua";
	Sys_Char line[200], search_string[] = "scripts[";
	Sys_Char *ModifiedScirpt = NULL, *scriptLine;
	//Sys_Char wsems[10]; //commenting it in order to supress the warning.
	Sys_Char *pWSEMS = "-WSEMS\"\]\=\{\n";
	configHandle = Sys_Fopen(ConfigLuaFile, "r"); // using this call to supress the warnings
	tempHandle = Sys_Fopen(tempLuaFile, "w"); // 

	if (!configHandle)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Unable to open the Sidecar lua file!!\n.", function);
		return 0;
	}
	if (!tempHandle)
	{
		//perror(tempHandle);
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Unable to open a temporary file to write!!\n", function);
		fclose(configHandle);
		return 0;
	}

	while (fgets(line, 200, configHandle) != NULL) /* read a line */
	{
		if (strstr(line, search_string)) {
			scriptLine = strtok(line, "[\"");
			ModifiedScirpt = (char*)malloc(strlen(scriptLine) + strlen(pConfigparam->m_ThingName) + strlen(pWSEMS));
			strcpy(ModifiedScirpt, scriptLine);
			strcat(ModifiedScirpt, "[\"");
			//temp[20] = pConfigparam->m_ThingName + 1;
			//strncpy(ModifiedScirpt, pConfigparam->m_ThingName + 1,strlen(temp)-5);
			Sys_Char temp[MAX]="",temp2[MAX]="";//temps for removing "-EMS"
			strcpy(temp, pConfigparam->m_ThingName + 1);
			strcat(temp, "\0");
			strncpy(temp2,temp,(strlen(temp)-4));//Removing the "-EMS"
			strcat(ModifiedScirpt, temp2);
			strcat(ModifiedScirpt, pWSEMS);
			fputs(ModifiedScirpt, tempHandle);
			printf("%s", ModifiedScirpt);
		}
		else
			fputs(line, tempHandle);
	}
	fclose(configHandle);
	fclose(tempHandle);
	remove(ConfigLuaFile);
	rename(tempLuaFile, ConfigLuaFile);
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited", function);
	return CONFIG_SUCCESS;
}
//SideCar LSR Config parsing Utility--- Stop***************

ConfigErrCodes EMSConfig_Init(void **ppHdl)
{
	Sys_Int err = TW_OK;
	pemsConfigHdl pECHdl = NULL; /*Added*/
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	Sys_Char *function = "EMSConfig_Init";

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	//Added
	if (*ppHdl == NULL) {
		pECHdl = (pemsConfigHdl)Sys_Malloc(sizeof(emsConfigHdl));
		if (pECHdl == NULL) {
			retVal = CONFIG_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Insufficient Memory!", function);
			goto failCall;
		}

		pECHdl->twApTskId = 0;

		pECHdl->pThrdStrct = NULL;
		pECHdl->pThrdStrct = SysCreateThreadStruct();
		if (pECHdl->pThrdStrct == NULL) {
			retVal = CONFIG_SYSTEM_ERROR;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pThrdStrct-create thread failed!", function);
			goto failCall;
		}
		pECHdl->pThrdStrct->m_waitMilliSec = INFINITE;
	}
	else {
		retVal = CONFIG_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Wrong IP ppHdl passed!", function);
		goto failCall;
	}

	*ppHdl = pECHdl;

	/** Initialize Config parameter handle */
	pConfigparam = (configparam *)Sys_Malloc(sizeof(configparam));
	if (pConfigparam == NULL) {
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Insufficient memory!", function);
		goto failCall;
	}

	pConfigparam->m_Asset.pId = NULL;
	pConfigparam->m_Asset.comAddr = NULL;
	pConfigparam->m_Asset.comPort = NULL;
	pConfigparam->m_Asset.comType = NULL;
	pConfigparam->m_Asset.appName = NULL;
	pConfigparam->m_Asset.refVolt = 0;
	pConfigparam->m_Asset.misc = NULL;
	pConfigparam->m_ConfigVersion = NULL;
	pConfigparam->m_ThingName = NULL;
	pConfigparam->m_HostName = NULL;
	pConfigparam->m_AppKey = NULL;
	pConfigparam->m_Encryption = NULL;
	pConfigparam->PEMCertFile = NULL;
	pConfigparam->mutexHdl = NULL;
	pConfigparam->configDone = SYS_FALSE;
	pConfigparam->logDone = SYS_FALSE;
	pConfigparam->offlineDone = SYS_FALSE;
	pConfigparam->m_ProxyHostName = NULL;
	pConfigparam->m_ProxyPort = NULL;

	pConfigparam->mutexHdl = SysMutex_Create();

	retVal = ReadConfigParams(); //ToDo:Soumya - Ideally we should validate the JSON files b/f populating the values
	if (retVal != CONFIG_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: failed!", function);
		goto failCall;
	}

	//WriteConfigParams(); //Enable for writing to json file.

	//Soumya- Updating SideCar Config
	//Host name and port name to be change which are under ws_servers, auto_bind and http_server
/* Commenting this call as we have another method which auto updates the Sidecar Config.json using the JSON API*/
	//Sys_Char wsServer_Host[MAX], wsServer_Port[MAX], file_Appkey[MAX], autobind_Name[MAX], \
	//	autobind_Host[MAX], autobind_Port[MAX];

	//retVal = EMSConfig_ReadSideCarConfig(wsServer_Host,wsServer_Port, autobind_Name,\
	//										 autobind_Host,autobind_Port, file_Appkey, proxyHost, proxyPort);
	//retVal = EMSConfig_SideCarConfigUpdate(wsServer_Host,wsServer_Port, autobind_Name, \
	//							   autobind_Host,autobind_Port, file_Appkey, proxyHost, proxyPort);
	retVal = UpdateSideCarConfig();
	if (retVal == CONFIG_SUCCESS)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Sidecar Config.json is updated", function);
	}
	else {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s:Failed to update the Sidecar config.json ", function);
	}

#ifndef WINXP
	//Soumya- Updating SideCar LSR Config
	retVal = WriteToSidecarLua();
	if (retVal == CONFIG_SUCCESS)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Sidecar lua is updated", function);
	}
	else 
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s:Failed to update the Sidecar lua ", function);
	}

#endif
	//-------------------------------

	retVal = ConnectToTWPlatform_Initalize();
	if (retVal != CONFIG_SUCCESS) {
		goto failCall;
	}

	SysAppLog(SYS_INFO, MODULE_EMS_AGENT, "%s: exited!", function);
	return retVal;

failCall:
	if (pECHdl) {
		if (pECHdl->pThrdStrct) {
			SysDestroyThreadStruct(pECHdl->pThrdStrct);
			pECHdl->pThrdStrct = NULL;
		}

		Sys_Free(pECHdl);
		pECHdl = NULL;
	}
	
	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited with failure.", function);
	return retVal;
}

ConfigErrCodes EMSConfig_Uninit(
	void *pHdl
	)
{
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	Sys_Char *function = "EMSConfig_Uninit";
	Sys_Int err = TW_OK;
	pemsConfigHdl pECHdl = (pemsConfigHdl)pHdl;
	
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	//Config Thread UnInit
	if (pECHdl != NULL) {
		if (pECHdl->twApTskId != 0) {
			twTasker_RemoveTask(pECHdl->twApTskId); //TODO: Vishal: This API is returning wrong value. So not handling.
			pECHdl->twApTskId = 0;
		}

		if (pECHdl->pThrdStrct) {
			SysDestroyThreadStruct(pECHdl->pThrdStrct);
			pECHdl->pThrdStrct = NULL;
		}

		Sys_Free(pECHdl);
		pECHdl = NULL;
	}
	else {
		retVal = CONFIG_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: wrong params passed!", function);
	}

	err = twApi_UnbindThing(pConfigparam->m_ThingName);
	if (err != TW_OK) {
		retVal = CONFIG_TWX_ERROR;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: twApi_UnbindThing() failed!", function);
	}

	twFileManager_UnregisterFileCallback(FileCallbackFunc, NULL, NULL); //TODO: Vishal: Need to handle return error codes.

	SysSleepMsec(100);

	err = twApi_Delete();
	if (err != TW_OK) {
		retVal = CONFIG_TWX_ERROR;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: twApi_Delete() failed!", function);
	}

	CleanUpJsonOBJ();

	retVal = FreeConfigData(pConfigparam);

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return retVal;
}

ConfigErrCodes EMSConfig_Start(
	void *pHdl
	)
{
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	Sys_Char *function = "EMSConfig_Start";
	pemsConfigHdl pECHdl = (pemsConfigHdl)pHdl;
	Sys_Int err = TW_OK;

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	if (pECHdl != NULL) {
		err = ConnectToTWPlatform_Start(pECHdl); 
		if (err != TW_OK) {
			//retVal = CONFIG_TWX_ERROR; //Vishal: No need to return, as based on this offline will start.
			SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: ConnectToTWPlatform_Start() failed!", function);
		}

		//Reverting the changes of Revision 461
		/*
		if (err == TW_INTERNAL_SERVER_ERROR) {
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Unable to Write Property. INVALID THINGNAME. Error Code: %d", function, err);
			return err;
		} */

		// start the thread
		if (pECHdl->pThrdStrct == NULL) {
			retVal = CONFIG_WRONG_IP_PARAMS;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s:pECHdl->pThrdStrct -Insufficient Memory!  ", function);
		}
		else{
			SysStartThread(pECHdl->pThrdStrct, ConfigThreadFunction);
		}
	}
	else {
		retVal = CONFIG_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: wrong params passed!", function);
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);

	return retVal;

}

ConfigErrCodes EMSConfig_Stop(
	void *pHdl
	)
{
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	Sys_Char *function = "EMSConfig_Stop";
	pemsConfigHdl pEAHdle = (pemsConfigHdl)pHdl;

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	if (pEAHdle != NULL) {
		// stop Thread 
		if (pEAHdle->pThrdStrct != NULL){
			SysStopThread(pEAHdle->pThrdStrct);
		}
	}
	else {
		retVal = CONFIG_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: wrong params passed!", function);
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return retVal;
}

ConfigErrCodes InitSecureConnection(char *PEMFile)
{
	Sys_Int err = TW_OK;
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	Sys_Char *function = "InitSecureConnection";
	Sys_Char* pszPEMFilePath = GetFilePathByName(CONFIG_FOLDER_NAME, PEMFile);

   SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
   /* Allow self signed certs */
   twApi_SetSelfSignedOk();
   /* Enable FIPS mode */
   //err = twApi_EnableFipsMode();
   //if (err)
   //{
	  // SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "Error enabling FIPS mode.  Error code: %d", err);
   //   exit(err);
   //}

   err = twApi_LoadCACert(pszPEMFilePath, 1);
   if (err == TW_NULL_OR_INVALID_MSG_HANDLER) {
	   retVal = CONFIG_TWX_ERROR;
	   SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "Error loading the pem certificate.  Error code: %d", err);
   }

   Sys_Free(pszPEMFilePath);
   SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);

   return retVal;
}
// ****************************************************************************

// ****************************************************************************
/*
* Returns the thingName (identifier string) with * prepended
* */
void GetThingName()
{
	Sys_Char *function = "GetThingName";
	Sys_Char *pszThingTemp = (Sys_Char*)Sys_Malloc(strlen(pConfigparam->m_ThingName) + 2);
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	strcpy(pszThingTemp, "*");
	strcat(pszThingTemp, pConfigparam->m_ThingName);

	Sys_Free(pConfigparam->m_ThingName);
	pConfigparam->m_ThingName = pszThingTemp;
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
}

ConfigErrCodes ConnectToTWPlatform_Initalize(
	void *pHdl /**< Opaque handle */
)
{
	Sys_Int err = TW_OK;
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	Sys_Int proxyErr = TW_OK;
	Sys_Int proxyPortTmp = 0;
	Sys_Char *function = "ConnectToTWPlatform_Initalize";

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "config.hostName  - OpenSSL %s", pConfigparam->m_HostName);
	err = twApi_Initialize(pConfigparam->m_HostName, pConfigparam->m_Port, TW_URI, pConfigparam->m_AppKey, NULL,
       twcfg.message_chunk_size, MESSAGE_CHUNK_SIZE, TRUE);
	if (err != TW_OK) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "Error initializing the API");
		retVal = CONFIG_TWX_ERROR;
		goto failCall;
	}

	//Setting up Proxy Server
	if (pConfigparam->m_ProxyPort) {
		proxyPortTmp = atoi(pConfigparam->m_ProxyPort);
	}
	if ((pConfigparam->m_ProxyHostName == NULL) || (proxyPortTmp == 0) || \
		(proxyPortTmp < 1025) || (proxyPortTmp > 49151)) {
		SysAppLog(SYS_INFO, MODULE_EMS_CONFIG, "%s: Proxy server is not configured as Proxy Host/Port is incorrect or not configured", function);
	}
	else {
		proxyErr = twApi_SetProxyInfo(pConfigparam->m_ProxyHostName, proxyPortTmp, "userXYZ", "passXYZ");
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Proxy server setup status - %d", function, proxyErr);
		SysAppLog(SYS_INFO, MODULE_EMS_CONFIG, "%s: ProxyHost - %s  & Port- %d", function, pConfigparam->m_ProxyHostName, proxyPortTmp);
	}

	retVal = InitSecureConnection(pConfigparam->PEMCertFile);
	if (retVal != CONFIG_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "Error Initialising the secure connection.  Error code: %d", err);
		goto failCall;
	}

	err= twFileManager_RegisterFileCallback(FileCallbackFunc, NULL, FALSE, NULL);
	if (err != TW_OK) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "Error Registering the file callback .  Error code: %d", err);
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return retVal;

failCall:
	SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: exited with failure!", function);
	return retVal;
}

Sys_Int ConnectToTWPlatform_Start(
	void *pHdl
)
{
	Sys_Int err = TW_OK;
	Sys_Char *function = "ConnectToTWPlatform_Start";
	pemsConfigHdl pECHdl = (pemsConfigHdl)pHdl;

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	/** Bind our thing **/
	err = twApi_BindThing(pConfigparam->m_ThingName);
	if (err != TW_OK)
	{
		// todo:  define failure scenario if bind fails.
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Unable to bind. Error Code: %d", function, err);
	}

	/* Connect to server */
	err = twApi_Connect(twcfg.connect_timeout, twcfg.connect_retries);
	if (err != TW_OK)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG,
			"%s: Server connection failed after %d attempts.  Error Code: %d", function,
			CONNECT_RETRIES, err);
		return err;
	}

#if 0 //Removing the Register functionality and binding the Thing before twApi_Connect() to counter offline bind failures.
	err = Register();
	if (err)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Registration has failed", function);
		/*todo:  Need to define the failure scenario if the Registration fails*/
		return err;
	}
	else
	{
		SysAppLog(SYS_TRACE, MODULE_EMS_CONFIG, "%s: Registration was successful", function);

		/** Bind our thing **/
		err = twApi_BindThing(pConfigparam->m_ThingName);
		if (err != TW_OK)
		{
			// todo:  define failure scenario if bind fails.
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Unable to bind. Error Code: %d", function,err);
		}
	}
#endif

	if (pECHdl != NULL) {
		err = twApi_CreateTask(FILE_WATCHER_RATE_MSEC, FileWatcherTask);
		if (err == TW_MAX_TASKS_EXCEEDED) {
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error calling the FileWatcherTask(). Id- %d !", function, err);
			return err;
		}
		else {
			pECHdl->twApTskId = err; /**< Storing thread id returned. */
			err = TW_OK;
		}
	}
	else {
		err = TW_INVALID_PARAM;
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: pECHdl- %d !", function, pECHdl);
		return err;
	}

	/*Register the properties */
	err= RegisterProperties();
	if (err != TW_OK) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error in registration of property ", function);
	}
	
	/*Register the services */
	err= RegisterServices(); 
	if (err != TW_OK) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error in registrating the service", function);
	}
	
	// One-time update of static properties
	err= StaticPropertyUpdate(); 
	if (err != TW_OK) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error in updating the static property", function);
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);

	return err;
}

ConfigErrCodes GetConfigData(configparam **pConfig)
{
	Sys_Int retVal = CONFIG_SUCCESS;
	Sys_Char *function = "GetConfigData";
	configparam *pConf = *pConfig;

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered!", function);

	if (pConf == NULL) {
		pConf = (configparam *)Sys_Malloc(sizeof(configparam));
		if (pConf == NULL) {
			retVal = CONFIG_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Insufficient Memory!", function);
			goto failCall;
		}

		pConf->m_Asset.pId = NULL;
		pConf->m_Asset.comType = NULL;
		pConf->m_Asset.comAddr = NULL;
		pConf->m_Asset.comPort = NULL;
		pConf->m_Asset.appName = NULL;
		pConf->m_Asset.refVolt = 0;
		pConf->m_ConfigVersion = NULL;
		pConf->m_Asset.misc = NULL;
		pConf->m_ThingName = NULL;
		pConf->m_HostName = NULL;
		pConf->m_AppKey = NULL;
		pConf->m_Encryption = NULL;
		pConf->PEMCertFile = NULL;
		pConf->m_ProxyHostName = NULL;
		pConf->m_ProxyPort = NULL;

		pConf->mutexHdl = SysMutex_Create();
	}

	if (pConf->m_Asset.pId) {
		Sys_Free(pConf->m_Asset.pId);
		pConf->m_Asset.pId = NULL;
	}
	pConf->m_Asset.pId = Sys_StrDup(pConfigparam->m_Asset.pId);
	if (pConf->m_Asset.pId == NULL)
	{
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->m_Asset.pId - Insufficient Memory!", function);
		goto failCall;
	}
	
	//Added Sept_19
	// Asset Connection Config
	if (pConf->m_Asset.comType) {
		Sys_Free(pConf->m_Asset.comType);
		pConf->m_Asset.comType = NULL;
	}
	pConf->m_Asset.comType = Sys_StrDup(pConfigparam->m_Asset.comType);
	if (pConf->m_Asset.comType == NULL)
	{
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->m_Asset.comType - Insufficient Memory!", function);
		goto failCall;
	}

	if (pConf->m_Asset.comAddr) {
		Sys_Free(pConf->m_Asset.comAddr);
		pConf->m_Asset.comAddr = NULL;
	}
	pConf->m_Asset.comAddr = Sys_StrDup(pConfigparam->m_Asset.comAddr);
	if (pConf->m_Asset.comAddr == NULL)
	{
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->m_Asset.comAddr - Insufficient Memory!", function);
		goto failCall;
	}

	if (pConf->m_Asset.comPort) {
		Sys_Free(pConf->m_Asset.comPort);
		pConf->m_Asset.comPort = NULL;
	}
	pConf->m_Asset.comPort = Sys_StrDup(pConfigparam->m_Asset.comPort);
	if (pConf->m_Asset.comPort == NULL)
	{
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->m_Asset.comPort - Insufficient Memory!", function);
		goto failCall;
	}
	//End Sept_19
	// For App Utilization
	if (pConf->m_Asset.appName) {
		Sys_Free(pConf->m_Asset.appName);
		pConf->m_Asset.appName = NULL;
	}
	pConf->m_Asset.appName = Sys_StrDup(pConfigparam->m_Asset.appName);
	if (pConf->m_Asset.appName == NULL)
	{
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->m_Asset.appName - Insufficient Memory!", function);
		goto failCall;
	}

	// For Plum reference voltage
	pConf->m_Asset.refVolt = pConfigparam->m_Asset.refVolt;

	if (pConf->m_Asset.misc) {
		Sys_Free(pConf->m_Asset.misc);
		pConf->m_Asset.misc = NULL;
	}
	if (pConfigparam->m_Asset.misc) {
		pConf->m_Asset.misc = Sys_StrDup(pConfigparam->m_Asset.misc);
	//	if (pConf->m_Asset.misc == NULL){
			// No error return since it's an option parameter
			/*retVal = CONFIG_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->m_Asset.misc - Insufficient Memory!", function);
			goto failCall;*/
		//}
	}

	if (pConf->m_ThingName) {
		Sys_Free(pConf->m_ThingName);
		pConf->m_ThingName = NULL;
	}
	pConf->m_ThingName = Sys_StrDup(pConfigparam->m_ThingName);
	if (pConf->m_ThingName == NULL)
	{
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->m_ThingName - Insufficient Memory!", function);
		goto failCall;
	}

	if (pConf->m_HostName) {
		Sys_Free(pConf->m_HostName);
		pConf->m_HostName = NULL;
	}
	pConf->m_HostName = Sys_StrDup(pConfigparam->m_HostName);
	if (pConf->m_HostName == NULL)
	{
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->m_HostName - Insufficient Memory!", function);
		goto failCall;
	}

	if (pConf->m_AppKey) {
		Sys_Free(pConf->m_AppKey);
		pConf->m_AppKey = NULL;
	}
	pConf->m_AppKey = Sys_StrDup(pConfigparam->m_AppKey);
	if (pConf->m_AppKey == NULL)
	{
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->m_AppKey - Insufficient Memory!", function);
		goto failCall;
	}

	if (pConfigparam->m_ProxyHostName) {
		if (pConf->m_ProxyHostName) {
			Sys_Free(pConf->m_ProxyHostName);
			pConf->m_ProxyHostName = NULL;
		}
		pConf->m_ProxyHostName = Sys_StrDup(pConfigparam->m_ProxyHostName);
		if (pConf->m_ProxyHostName == NULL)
		{
			retVal = CONFIG_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->m_ProxyHostName - Insufficient Memory!", function);
			goto failCall;
		}
	}

	if (pConfigparam->m_ProxyPort) {
		if (pConf->m_ProxyPort) {
			Sys_Free(pConf->m_ProxyPort);
			pConf->m_ProxyPort = NULL;
		}
		pConf->m_ProxyPort = Sys_StrDup(pConfigparam->m_ProxyPort);
		if (pConf->m_ProxyPort == NULL)
		{
			retVal = CONFIG_INSUFFICIENT_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->m_ProxyPort - Insufficient Memory!", function);
			goto failCall;
		}
	}

	if (pConf->m_Encryption) {
		Sys_Free(pConf->m_Encryption);
		pConf->m_Encryption = NULL;
	}
	pConf->m_Encryption = Sys_StrDup(pConfigparam->m_Encryption);
	if (pConf->m_Encryption == NULL)
	{
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->m_Encryption - Insufficient Memory!", function);
		goto failCall;
	}

	if (pConf->PEMCertFile) {
		Sys_Free(pConf->PEMCertFile);
		pConf->PEMCertFile = NULL;
	}
	pConf->PEMCertFile = Sys_StrDup(pConfigparam->PEMCertFile);
	if (pConf->PEMCertFile == NULL)
	{
		retVal = CONFIG_INSUFFICIENT_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: pConf->certificateFile - Insufficient Memory!", function);
		goto failCall;
	}
	
	pConf->m_Asset.Type = pConfigparam->m_Asset.Type;
	pConf->m_EmsStatus = pConfigparam->m_EmsStatus;
	pConf->m_Port = pConfigparam->m_Port;
	pConf->acquisition.unit = pConfigparam->acquisition.unit;
	pConf->acquisition.health = pConfigparam->acquisition.health;
	pConf->acquisition.environment = pConfigparam->acquisition.environment;
	pConf->acquisition.utilization = pConfigparam->acquisition.utilization;
	pConf->acquisition.information = pConfigparam->acquisition.information;
	//Posting rate is removed from the config.json
	/*pConf->posting.unit = pConfigparam->posting.unit;
	pConf->posting.health = pConfigparam->posting.health;
	pConf->posting.environment = pConfigparam->posting.environment;
	pConf->posting.utilization = pConfigparam->posting.utilization;*/
	pConf->configDone = pConfigparam->configDone;
	pConf->logDone = pConfigparam->logDone;
	pConf->offlineDone = pConfigparam->offlineDone;
	pConf->Max_Message_Size = pConfigparam->Max_Message_Size;

	*pConfig = pConf;

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited!", function);

	return retVal;

failCall:
	if (pConf != NULL) {
		if (pConf->m_Asset.pId) {
			Sys_Free(pConf->m_Asset.pId);
			pConf->m_Asset.pId = NULL;
		}

		//Added Sept_19
		if (pConf->m_Asset.comType) {
			Sys_Free(pConf->m_Asset.comType);
			pConf->m_Asset.comType = NULL;
		}

		if (pConf->m_Asset.comAddr) {
			Sys_Free(pConf->m_Asset.comAddr);
			pConf->m_Asset.comAddr = NULL;
		}

		if (pConf->m_Asset.comPort) {
			Sys_Free(pConf->m_Asset.comPort);
			pConf->m_Asset.comPort = NULL;
		}
		//End Sept_19
		// For App Utilization
		if (pConf->m_Asset.appName) {
			Sys_Free(pConf->m_Asset.appName);
			pConf->m_Asset.appName = NULL;
		}

		// Plum Ref Volt
		pConf->m_Asset.refVolt = 0;

		if (pConf->m_Asset.misc) {
			Sys_Free(pConf->m_Asset.misc);
			pConf->m_Asset.misc = NULL;
		}

		if (pConf->m_ThingName) {
			Sys_Free(pConf->m_ThingName);
			pConf->m_ThingName = NULL;
		}

		if (pConf->m_HostName) {
			Sys_Free(pConf->m_HostName);
			pConf->m_HostName = NULL;
		}

		if (pConf->m_AppKey) {
			Sys_Free(pConf->m_AppKey);
			pConf->m_AppKey = NULL;
		}

		if (pConf->m_ProxyHostName) {
			Sys_Free(pConf->m_ProxyHostName);
			pConf->m_ProxyHostName = NULL;
		}

		if (pConf->m_ProxyPort) {
			Sys_Free(pConf->m_ProxyPort);
			pConf->m_ProxyPort = NULL;
		}

		if (pConf->m_Encryption) {
			Sys_Free(pConf->m_Encryption);
			pConf->m_Encryption = NULL;
		}

		if (pConf->PEMCertFile) {
			Sys_Free(pConf->PEMCertFile);
			pConf->PEMCertFile = NULL;
		}

		Sys_Free(pConf);
		pConf = NULL;
	}
		
	SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: exited with failure!", function);

	return retVal;
}

ConfigErrCodes FreeConfigData(configparam *pConfig)
{
	Sys_Int retVal = CONFIG_SUCCESS;
	Sys_Char *function = "FreeConfigData";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered!", function);

	if (pConfig != NULL) {
		if (pConfig->m_Asset.pId != NULL) {
			Sys_Free(pConfig->m_Asset.pId);
			pConfig->m_Asset.pId = NULL;
		}

		//Added Sept_19
		if (pConfig->m_Asset.comType != NULL) {
			Sys_Free(pConfig->m_Asset.comType);
			pConfig->m_Asset.comType = NULL;
		}

		if (pConfig->m_Asset.comAddr != NULL) {
			Sys_Free(pConfig->m_Asset.comAddr);
			pConfig->m_Asset.comAddr = NULL;
		}

		if (pConfig->m_Asset.comPort != NULL) {
			Sys_Free(pConfig->m_Asset.comPort);
			pConfig->m_Asset.comPort = NULL;
		}
		//End Sept_19

		// For App Utilization
		if (pConfig->m_Asset.appName != NULL) {
			Sys_Free(pConfig->m_Asset.appName);
			pConfig->m_Asset.appName = NULL;
		}

		// For Plum Ref
		pConfig->m_Asset.refVolt = 0;

		if (pConfig->m_Asset.misc != NULL) {
			Sys_Free(pConfig->m_Asset.misc);
			pConfig->m_Asset.misc = NULL;
		}

		if (pConfig->m_ThingName != NULL) {
			Sys_Free(pConfig->m_ThingName);
			pConfig->m_ThingName = NULL;
		}

		if (pConfig->m_AppKey != NULL) {
			Sys_Free(pConfig->m_AppKey);
			pConfig->m_AppKey = NULL;
		}

		if (pConfig->PEMCertFile != NULL) {
			Sys_Free(pConfig->PEMCertFile);
			pConfig->PEMCertFile = NULL;
		}
		if (pConfig->m_Encryption != NULL) {
			Sys_Free(pConfig->m_Encryption);
			pConfig->m_Encryption = NULL;
		}

		if (pConfig->m_HostName != NULL) {
			Sys_Free(pConfig->m_HostName);
			pConfig->m_HostName = NULL;
		}

		if (pConfig->mutexHdl) {
			SysMutex_Delete(pConfig->mutexHdl);
			pConfig->mutexHdl = NULL;
		}

		if (pConfig->m_ProxyHostName != NULL) {
			Sys_Free(pConfig->m_ProxyHostName);
			pConfig->m_ProxyHostName = NULL;
		}

		if (pConfig->m_ProxyPort) {
			Sys_Free(pConfig->m_ProxyPort);
			pConfig->m_ProxyPort = NULL;
		}

		Sys_Free(pConfig);
		pConfig = NULL;
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited!", function);

	return retVal;
}              