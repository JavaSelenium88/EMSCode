//*****************************************************************************
//
//  Copyright � 2016 ITC .  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  FileWatcher.c
//
//  Subsystem  :  Keysight
//
//  Author: Akshata N
//
//  Description:
//
//                Observes for file transfer updates
//
//*****************************************************************************

#include "SysLog.h"
#include "EMS_Config.h"
#include "EMS_Agent.h"
#include "EMS_Config_Utils.h"
#include "FileWatcher.h"


/***************
 File Watcher Task
 ****************/
/*
 This function gets called at the rate defined in the task creation.  Monitor
 for new or changed files and automatically transfer them to the server.
 */
#define WATCHED_DIR "tw/hotfolder"

twList *pFileList = 0;
void FileWatcherTask(DATETIME now, void *params)
{
	Sys_Char *function = "FileWatcherTask";
	//ToDo:Soumya-commenting out the below error log as filewatcher is not in use currently
	//SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
   if (!pFileList)
   {
      /* This is the first time through - get the current listing */
	   pFileList = twFileManager_ListEntities(pConfigparam->m_ThingName, WATCHED_DIR, NULL,
      LIST_FILES);
   }
   if (pFileList)
   {
      /* Get a new listing and compare it with the old */
      ListEntry *pLE_Orig = NULL;
      ListEntry *pLE_New = NULL;
      twFile *pF_Orig = NULL;
      twFile *pF_New = NULL;
	  Sys_Char bFileFound = FALSE;
	  Sys_Char bFileChanged = FALSE;
	  twList *pNewList = twFileManager_ListEntities(pConfigparam->m_ThingName, WATCHED_DIR,
            NULL, LIST_FILES);
      if (!pNewList)
      {
		  SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s : Error getting file listing",function);
         return;
      }
      pLE_New = twList_Next(pNewList, NULL);
      while (pLE_New && pLE_New->value)
      {
         pF_New = (twFile *) pLE_New->value;
         pLE_Orig = twList_Next(pFileList, NULL);
         while (pLE_Orig && pLE_Orig->value)
         {
            bFileFound = FALSE;
            bFileChanged = FALSE;
            pF_Orig = (twFile *) pLE_Orig->value;
            /* Check if the file names are the same. If so check the timestamp */
            if (!strcmp(pF_New->virtualPath, pF_Orig->virtualPath))
            {
               bFileFound = TRUE;
               if (twTimeGreaterThan(pF_New->lastModified, pF_Orig->lastModified))
               {
				   SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG,
                        "FileWatcherTask: File %s has changed. Old timestamp %llu, New timestamp %llu Queueing for sending",	
                        pF_New->virtualPath, pF_Orig->lastModified,
                        pF_New->lastModified);
                  bFileChanged = TRUE;
                  break;
               }
               break;
            }
            pLE_Orig = twList_Next(pFileList, pLE_Orig);
         }
         if (!bFileFound || bFileChanged)
         {
			 Sys_Char *tid = 0;
			if (twFileManager_SendFile(pConfigparam->m_ThingName, pF_New->virtualPath,
                  pF_New->name, "SystemRepository", "/", pF_New->name, 60, TRUE,
                  &tid))
            {
				SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG,
					"%s : Error initiating file transfer",function);
            }
            if (tid)
            {
				SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG,
                     "%s : Transfering file %s.  tid = %s",function,
                     pF_New->name, tid ? tid : "UNKNOWN");
               Sys_Free(tid);
            }
         }
         pLE_New = twList_Next(pNewList, pLE_New);
      }
      /* Make the new list the old list and delete the old */
      twList_Delete(pFileList);
      pFileList = pNewList;
   } else
   {
	   //ToDo:Soumya-commenting out the below error log as filewatcher is not in use currently
	   //SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s : No file list to compare against",function);
      return;
   }
   SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
}
void FileCallbackFunc(Sys_Char fileRcvd, twFileTransferInfo *info, void *userdata)
{
	Sys_Char startTime[80];
	Sys_Char endTime[80];
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	NativeErrCodes natRetVal = NATIVE_SUCCESS;
	EMSAgentErrCodes eaRetVal = EMSAGENT_SUCCESS;
	Sys_Char *function = "FileCallbackFunc";

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	if (!info) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Function called with NULL info", function);
	}
	twGetTimeString(info->startTime, startTime, "%Y-%m-%d %H:%M:%S", 80, 1, 1);
	twGetTimeString(info->endTime, endTime, "%Y-%m-%d %H:%M:%S", 80, 1, 1);
	SysAppLog(SYS_INFO, MODULE_EMS_CONFIG,
		"\n\n*****************\nFILE TRANSFER NOTIFICATION:\nSource: %s:%s/%s\nDestination: %s:%s/%s\nSize: %9.0f\nStartTime: %s\nEndTime: %s\nDuration: %d msec\nUser: %s\nState: %s\nMessage: %s\nTransfer ID: %s\n*****************\n",
		info->sourceRepository, info->sourcePath, info->sourceFile,
		info->targetRepository, info->targetPath, info->targetFile, info->size,
		startTime, endTime, info->duration, info->user, info->state,
		info->message, info->transferId);

	if (strcmp(info->sourceFile, "Config.json") == 0) {
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: Function called", function);

		retVal = ReadConfigParams();//ToDo:Soumya - Ideally we should validate the JSON files b/f populating the values
		if (retVal != CONFIG_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: ReadConfigParams() failed!", function);
		}

		eaRetVal = EMSAgent_SetConfigData(pConfigparam);
		if (eaRetVal != EMSAGENT_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: EMSAgent_SetConfigData() failed!", function);
		}

		natRetVal = NatAgent_SetConfigData(pConfigparam);
		if (natRetVal != NATIVE_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: NativeAgent_SetConfigData() failed!", function);
		}
	}
			
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
}

Sys_Int configChangeCallback(Sys_Char *pszConfigFolderPath, Sys_Char *pszConfigFolderName)
{
	ConfigErrCodes retVal = CONFIG_SUCCESS;
	NativeErrCodes natRetVal = NATIVE_SUCCESS;
	EMSAgentErrCodes eaRetVal = EMSAGENT_SUCCESS;
	Sys_Char *function = "configChangeCallback";

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	SysAppLog(SYS_INFO, MODULE_EMS_CONFIG,
		"\n\n*****************\nFILE TRANSFER NOTIFICATION:\nDestination Location: %s\nDestination File: %s\n*****************\n", pszConfigFolderPath, pszConfigFolderName);

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: Function called", function);
	/*Static Params - Params which require a Reboot/Power Cycle
	  Dynamic param - Params which don't require Reboot and can be updated on the fly*/
	retVal = CheckForChangeConfig();
	if (!retVal) { //If retVal is zero it means there is change in Dynamic Params else Static params are changed

		retVal = ReadConfigParams();//ToDo:Soumya - Ideally we should validate the JSON files b/f populating the values
		if (retVal != CONFIG_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: ReadConfigParams() failed!", function);
			return retVal;
		}

		eaRetVal = EMSAgent_SetConfigData(pConfigparam);
		if (eaRetVal != EMSAGENT_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: EMSAgent_SetConfigData() failed!", function);
			return eaRetVal;
		}

		natRetVal = NatAgent_SetConfigData(pConfigparam);
		if (natRetVal != NATIVE_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: NativeAgent_SetConfigData() failed!", function);
			return natRetVal;
		}
	}
	else if (retVal == CONFIG_FW_ERROR) { //If retVal = CONFIG_FW_ERROR means there was change in Static Params
		SysAppLog(SYS_FORCE, MODULE_EMS_CONFIG, "%s: Static Params change. EMS Needs a Restart", function);
		return retVal;
	}
	else {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: CheckForChangeConfig() failed!", function);
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return CONFIG_SUCCESS;
}