/*****************************************************************************
//
//  Copyright � 2016 ITC .  All rights reserved.
//
******************************************************************************
//
//  Filename   : configParams.h
//
//  Subsystem  : KeySight
//
//  Author     : Akshata N
//
//  Description:
//
//                Fetches values from JSON files and sets the parameters of network
//                connection, logging, offline message store & file transfer.
//
//
******************************************************************************/
#ifndef GENERALDEFINES_H_
#define GENERALDEFINES_H_
#include "Native_Agent.h"
#include "EMS_Config.h"


#define STR_DELIM_FWDSLSH "\\"
#define STR_DELIM_DOT "."
#define CHAR_NULL "\0"

#define STR_OFFLINE_MSG "offline_msg_store"
#define STR_MSG_SIZE "max_size"
#define STR_DIRECTORY "directory"
#define PAYLOAD_MULTIPLIER 10

/* Config .json*/
#define STR_HYRAX_SERVER "hyrax_server"
#define STR_ASSET "Asset"
#define STR_ACQUISITION "Acquisition"
#define STR_POSTING "Posting"
#define STR_ASSET_ID "id"
#define STR_ASSET_TYPE "type"
#define STR_ASSET_COM_TYPE "asset_com_type"
#define STR_ASSET_COM_ADDR "asset_com_addr"
#define STR_ASSET_COM_PORT "asset_com_port"
#define STR_ASSET_APP_NAME "asset_app_name"
#define STR_ASSET_REF_VOLT "asset_ref_volt"
#define STR_ASSET_MISC "asset_misc"
#define STR_EMS_STATUS "ems_status"
#define STR_CONFIG_VERSION "config_version"
#define STR_THINGNAME "thing_name"
#define STR_HOSTNAME "hostname"
#define STR_PORT "port"
#define STR_PROXY_HOSTNAME "proxy_hostname"
#define STR_PROXY_PORT "proxy_port"
#define STR_PEM_FILE "PEM_file"
#define STR_APPKEY "app_key"
#define STR_ENCRYPTION "encryption"
#define STR_UNIT "unit"
#define STR_HEALTH_RATE "Health_rate"
#define STR_ENV_RATE "Environment_rate"
#define STR_UTILIZATION_RATE "Utilization_rate"
#define STR_INFORMATION_RATE "Information_rate"

#define STR_POSTING_UNIT "Posting_unit"
#define STR_POSTING_RATE "Posting_rate"
#define STR_CONNECTION_TIMEOUT "connect_timeout"
#define STR_CONNECT_RETRY_INTERVAL "connect_retry_interval"
#define STR_MAX_CONNECT_DELAY "max_connect_delay"

#define STR_FILE_TRANSFER "File_Transfer"
#define STR_BUFFER_SIZE "buffer_size"
#define STR_MAX_FILE_SIZE "max_file_size"
#define STR_MAX_MESSAGE_SIZE "max_message_size"
#define STR_STAGING_DIR "staging_dir"
#define STR_EMS_CONFIG_FILES "EMSConfigFiles"
#define STR_SYSTEM_LOG "SystemLogs"

#define STR_FILE_OFFLINE_MSG "offline_msg.json"
#define STR_FILE_WS_CONNECTION "Config.json"
#define CONFIG_FOLDER_NAME "Config_Files"
#define STR_FILE_WS_CONNECTIONS "Config2.json"

#ifdef WINXP
#define SIDECAR_CONFIG_FOLDER_NAME "SideCar_EMS\\ConfigFiles"
#define SC_FILE_WS_CONNECTION "server_config.json"
#else
#define SC_FILE_WS_CONNECTION "config.json"
#define SIDECAR_CONFIG_FOLDER_NAME "SideCar_EMS/etc"
#endif


/*sidecar config*/

#define SC_WS_SERVER "ws_servers"
#define SC_HOSTNAME "host"
#define SC_PORT "port"
#define SC_PROXY "proxy"
#define SC_PROXY_HOST "host"
#define SC_PROXY_PORT "port"
#define SC_AUTO_BIND "auto_bind"
#define SC_THINGNAME "name"
#define SC_HTTP_SERVER_HOST "host"
#define SC_HTTP_SERVER_PORT "port"
#define SC_APPKEY "appKey"

/* Winxp_sideCar config */
#ifdef WINXP
#define XP_SERVER_CONFIG "server_config"
#define XP_HOST_NAME "host_name"
#define XP_PORT "port"
#define XP_APP_KEY "app_key"
#define XP_THING_NAME "thing_identifier"
#define XP_PROXY "proxy"
#define XP_PROXY_HOST "host"
#define XP_PROXY_PORT "port"
#endif // WINXP



/* Enviorment json  keys */
#define STR_DEVICE_ASSET "Asset"
#define STR_DEVICE_ASSET_ID "Id"
#define STR_DEVICE_ASSET_TYPE "Type"
#define STR_DEVICE_SOURCE "Source"
#define STR_ACCELEROMETER "Accelerometer"
#define STR_XAXIS "XAxis"
#define STR_YAXIS "YAxis"
#define STR_ZAXIS "ZAxis"
#define STR_CURRENT_SENSOR "Current_Sensor"
#define STR_HUMIDITY_SENSOR "Humidity_Sensor"
#define STR_LIGHT_SENSOR "Light_Sensor"
#define STR_PRESSURE_SENSOR "Pressure_Sensor"
#define STR_TEMPERATURE_SENSOR "Temperature_Sensor"
#define STR_VOLTAGE_SENSOR "Voltage_Sensor"

/* Health json  keys */
#define STR_ATTENUATOR "Attenuator"
#define STR_BATTERY "Battery"
#define STR_LIFE_REMAINING "Life_Remaining"
#define STR_CYCLE "Cycles"
#define STR_DEFINED_PART "Defined_Part"
#define STR_DISPLAY "Display"
#define STR_LASER "Laser"
#define STR_MEMORY "Memory"
#define STR_BYTES_AVAIL "Bytes_Available"
#define STR_BYTES_USED "Bytes_Used"
#define STR_OS_VERSION "OS_Version"
#define STR_MOTOR "Motor"
#define STR_REVOLUTIONS "Revolutions"
#define STR_MOVEMENTS "Movements"
#define STR_MOVING_TIME "Moving_Time"
#define STR_ON_TIME "On_Time"
#define STR_OUTPUT "Output"
#define STR_PART "Part"
#define STR_PRODUCT "Product"
#define STR_SWITCH "Switch"

/* Utilization.json  keys */
#define STR_UTIL_PARAMS "Utilization_params"
#define STR_SCPI_INT "SCPI_Int"
#define STR_FRONT_PANEL "Front_Panel"
#define STR_LICENSES "Licenses"
#define STR_SCPI "SCPI"
#define STR_OS_INIT "OS_Int"
#define STR_KEYBOADR "Keyboard"
#define STR_MOUSE "Mouse"

//Added
#define FIVE_MIN_IN_MSEC_KEYSIGHT 300000
#define HOUR_IN_MSEC_KEYSIGHT 3600000
#define DEFAULT_ACQ_RATE_KEYSIGHT 5000 //In milli seconds
#define CONNECT_TIMEOUT_KEYSIGHT 2000
#define CONNECT_RETRY_INTERVAL_KEYSIGHT 10000
#define MAX_CONNECT_DELAY_KEYSIGHT 100
#define MAX_DAYS_IN_MSEC 4233600000
#define TWENTY_SECOND_IN_MSEC_KEYSIGHT 20000

typedef struct emsConfigHdl_T {
	pSysThreadStruct	pThrdStrct; /**< Thread structure per handle */
	Sys_Int				twApTskId; /**< Thread id returned by twApi_CreateTask() for FileWatcherTask */
}emsConfigHdl, *pemsConfigHdl;

configparam *pConfigparam;

// function prototypes
#ifdef WIN32
DWORD WINAPI ConfigThreadFunction(void* pVoid);
#else
void* ConfigThreadFunction(void* pVoid);
#endif

Sys_Char *ReadJsonFile(Sys_Char *fileName);

ConfigErrCodes ConnectToTWPlatform_Initalize();
void SetOfflineParam();
ConfigErrCodes ReadConfigParams();
ConfigErrCodes WriteConfigParams();
Sys_Char *GetUnitType(Sys_Int);
ConfigErrCodes AddEMSConfigVirtualDir(Sys_Char *pszEMSDir);
ConfigErrCodes AddSyslogVirtualDir(Sys_Char *pszSysDir);
void GetThingName();
ConfigErrCodes InitSecureConnection(char *PEMFiles);

//Added
Sys_Ulong TimerReconfig(Sys_Ulong delayTime);
Sys_Ulong GetInMSec(Sys_Uint rate, DataRateUnits unit);
Sys_Ullong GetDiskFreeSize();
Sys_Ulong delay_generator();
Sys_Int CheckForChangeConfig(void);
ConfigErrCodes UpdateSideCarConfig();

#endif /* GENERALDEFINES_H_ */
