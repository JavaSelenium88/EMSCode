/******************************************************************************
//
//  Filename   : properties.c
//  Subsystem  : KeySight
//  Author     : Soumya Ranjan Bej
//
//  Description: Property related functionality are handled here.
//
******************************************************************************/

#include "Properties.h"
#include "EMS_Config_Utils.h"
#include "SysLog.h"

/** Property handler **/
enum msgCodeEnum PropertyHandler(const Sys_Char *entityName,
	const Sys_Char *propertyName, twInfoTable **value, Sys_Char isWrite,
	void *userdata)
{
	Sys_Char *function = "PropertyHandler";
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return TWX_SUCCESS;
}

Sys_Int RegisterProperties()
{
	Sys_Char *function = "RegisterProperties";
	Sys_Int err = TW_OK;
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	/* Register our properties */
	err= twApi_RegisterProperty(TW_THING, pConfigparam->m_ThingName, "Keysight_Version", TW_STRING,		NULL, "ALWAYS", 0, PropertyHandler, NULL);
	if (err)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Registration of the property to TW has failed", function);
	}

	err = twApi_RegisterProperty(TW_THING, pConfigparam->m_ThingName, "Config_Version", TW_STRING, NULL, "ALWAYS", 0, PropertyHandler, NULL);
	if (err)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Registration of the property to TW has failed", function);
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return err;
}

/** Update the properties' status once to platform **/
Sys_Int StaticPropertyUpdate()
{
	Sys_Char *function = "StaticPropertyUpdate";
	Sys_Int err = TW_OK;
	twPrimitive * pKeySightValue = NULL;
	twPrimitive * pConfigVersion = NULL;
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	//twPrimitive * pKeySightValue = NULL;
	properties.m_KeysightVersion = KEYSIGHT_VERSION;
	pKeySightValue = twPrimitive_CreateFromString(properties.m_KeysightVersion, TRUE);
	err = twApi_WriteProperty(TW_THING, pConfigparam->m_ThingName, "Keysight_Version", pKeySightValue, -1, 0);
	if (err)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error in registrating static property to TW", function);
	}
	twPrimitive_Delete(pKeySightValue);

	//----------------------------------------------------------
	properties.m_ConfigVersion = pConfigparam->m_ConfigVersion;
	pConfigVersion = twPrimitive_CreateFromString(pConfigparam->m_ConfigVersion, TRUE);
	err = twApi_WriteProperty(TW_THING, pConfigparam->m_ThingName, "Config_Version", pConfigVersion, -1, 0);
	if (err)
	{
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error in registrating static property to TW", function);
	}
	twPrimitive_Delete(pConfigVersion);
	
	//	---------------------------------------------------------
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return err;
}