/******************************************************************************
//
//  Filename   : services.c
//
//  Subsystem  : KeySight
//
//  Author     : Soumya Ranjan Bej
//
//  Description:
//
//                Services related functionality are handled here.
//
******************************************************************************/

#include "SysLog.h"
#include "twApi.h"
#include "EMS_Config_Utils.h"
#include "Sysapi.h"
#include "Services.h"
#include "EMS_Agent.h"
#include "Self_Monitor.h"

#define TIMESTAMP_SERVICE_NAME "Get_EMS_Timestamp"
#define START_EMS_SERVICE "Start_EMS"
#define STOP_EMS_SERVICE "Stop_EMS"
#define START_SIDECAR_SERVICE "Start_sidecar" //Changed in accordance to Hyrax
#define STOP_SIDECAR_SERVICE "Stop_sidecar" //Changed in accordance to Hyrax
#define STOP_EMS_GRACEFULLY "Gracefully_Exit_EMS"
SYS_MUTEX SideCarMtx = NULL;

extern Sys_Int INTR_FLAG;

Sys_Int Register()
{
	Sys_Char *function = "Register";
   twDataShape *ds = NULL;
   twInfoTableRow *row = NULL;

   twInfoTable *values = NULL;
   twInfoTable *result = NULL;

   /*Initilizing with some random value as retun values to this var is "0" or positive integer*/
   Sys_Int res = 10;
   Sys_Int finalResult = 10;
   Sys_Int err = TW_OK;

   SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
   ds = twDataShape_Create(twDataShapeEntry_Create("ThingName", NULL, TW_STRING));
   err= twDataShape_AddEntry(ds, twDataShapeEntry_Create("AppKey", NULL, TW_STRING));
   if (err)
   {
	   SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error adding the Appkey to data shape", function);
   }
   values = twInfoTable_Create(ds);

   if (!values) {
	   SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "Register: Error creating infotable");
          twDataShape_Delete(ds);
          return TWX_INTERNAL_SERVER_ERROR;
      }

   row = twInfoTableRow_Create(twPrimitive_CreateFromString(pConfigparam->m_ThingName, TRUE));
   twInfoTableRow_AddEntry(row, twPrimitive_CreateFromString(pConfigparam->m_AppKey, TRUE));
   twInfoTable_AddRow(values, row);

   res = twApi_InvokeService(TW_THING, pConfigparam->m_ThingName, "RegisterConnection", values,
         &result, -1, FALSE);
   SysAppLog(SYS_INFO, MODULE_EMS_CONFIG, "invokeService - %d", res);

   twInfoTable_GetInteger(result, "result", 0, &finalResult);
   err = finalResult;
   SysAppLog(SYS_INFO, MODULE_EMS_CONFIG, "Got finalResult. Value:%d", finalResult);

    /*Cleaning up the temporary DataShapes/infoTables*/
   /*twDataShape_Delete(ds);*/
   twInfoTable_Delete(values);
   twInfoTable_Delete(result);

   SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
   return err;
}
Sys_Int RegisterServices()
{
	/* Register our services */
	Sys_Int err = SYS_OK;

	err = twApi_RegisterService(TW_THING, pConfigparam->m_ThingName, TIMESTAMP_SERVICE_NAME, NULL, NULL, TW_STRING, NULL, GetEMSTimestampCallback, NULL);
	if (err != SYS_OK) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "Error Registering the Service callback .  Error code: %d", err);
	}
	err = twApi_RegisterService(TW_THING, pConfigparam->m_ThingName, START_EMS_SERVICE, NULL, NULL, TW_STRING, NULL, StartEMSCallback, NULL);
	if (err != SYS_OK) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "Error Registering the EMS Start Service callback .  Error code: %d", err);
	}
	err = twApi_RegisterService(TW_THING, pConfigparam->m_ThingName, STOP_EMS_SERVICE, NULL, NULL, TW_STRING, NULL, StopEMSCallback, NULL);
	if (err != SYS_OK) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "Error Registering the EMS Stop Service callback .  Error code: %d", err);
	}
	err = twApi_RegisterService(TW_THING, pConfigparam->m_ThingName, START_SIDECAR_SERVICE, NULL, NULL, TW_BOOLEAN, NULL, StartSideCarCallback, NULL);
	if (err != SYS_OK) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "Error Registering the Service callback .  Error code: %d", err);
	}

	err = twApi_RegisterService(TW_THING, pConfigparam->m_ThingName, STOP_SIDECAR_SERVICE, NULL, NULL, TW_STRING, NULL, StopSideCarCallback, NULL);
	if (err != SYS_OK) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "Error Registering the Service callback .  Error code: %d", err);
	}

	err = twApi_RegisterService(TW_THING, pConfigparam->m_ThingName, STOP_EMS_GRACEFULLY, NULL, NULL, TW_STRING, NULL, StopEMSGracefullyCallback, NULL);
	if (err != SYS_OK) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "Error Registering the Service callback .  Error code: %d", err);
	}

	return err;
}


enum msgCodeEnum GetEMSTimestampCallback(const char *pszEntityName, const char *pszServiceName,
	twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
	Sys_Int retVal = 0;
	twInfoTable *pInfoTable = NULL;
	enum msgCodeEnum twMsgRetVal = TWX_SUCCESS;
	Sys_Char *function = "GetEMSTimestampCallback";
	Sys_Char timeStr[80];
	Sys_Char final_String[92];
	Sys_Char *delim_Char = "#";

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);

	//final_String = Sys_Malloc(Sys_StringLength(timeStr) + Sys_StringLength(EMS_AGENT_PLATFORM) + Sys_StringLength(EMS_AGENT_VERSION) + 1);
	//if (final_String == NULL)
	//	SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: Error allocating Memory!", function);

	retVal = Sys_GetTimeStamp(timeStr, "%Y-%m-%d %H:%M:%S", 80, 0, 0);//09/04/2017:UTC time is now provided
	if (retVal != SYS_RET_OK) {
		retVal = SYSLOG_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error getting TimeStamp. Error code = %s", function, retVal);
	}

	/**< Added for concatenating EMS version to timestamp */
	Sys_StringCpy(final_String, timeStr, Sys_StringLength(timeStr) + 1);
	Sys_StringCat(final_String, delim_Char, Sys_StringLength(delim_Char) + 1);
	Sys_StringCat(final_String, EMS_AGENT_PLATFORM, Sys_StringLength(EMS_AGENT_PLATFORM) + 1);
	Sys_StringCat(final_String, EMS_AGENT_VERSION, Sys_StringLength(EMS_AGENT_VERSION) + 1);

	*ppItContent = twInfoTable_CreateFromString("result", final_String, TRUE);
	if (*ppItContent == NULL)
		twMsgRetVal = TWX_UNSUPPORTED_CONTENT_FORMAT;

	twInfoTable_Delete(pInfoTable);

	//if (final_String) {
	//	Sys_Free(final_String);
	//	final_String = NULL;
	//}
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return twMsgRetVal;
}

enum msgCodeEnum StartEMSCallback(const char *pszEntityName, const char *pszServiceName,
	twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
	Sys_Int retVal = SYS_OK;
	twInfoTable *pInfoTable = NULL;
	Sys_Char *function = "StartEMSCallback";
	enum msgCodeEnum twMsgRetVal = TWX_SUCCESS;
	configparam *sConf = NULL;

	if (pConfigparam->m_EmsStatus)
		*ppItContent = twInfoTable_CreateFromString("result", "EMS is already ONLINE", TRUE);
	else {
		pConfigparam->m_EmsStatus = TRUE;
		retVal = EMSAgent_SetConfigData(pConfigparam);
		if (retVal != CONFIG_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: GetConfigData() failed!", function);
		}
		*ppItContent = twInfoTable_CreateFromString("result", "SUCCESS. EMS is now ONLINE", TRUE);
	}
	if (*ppItContent == NULL)
		twMsgRetVal = TWX_UNSUPPORTED_CONTENT_FORMAT;

	twInfoTable_Delete(pInfoTable);
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return twMsgRetVal;

}

enum msgCodeEnum StopEMSCallback(const char *pszEntityName, const char *pszServiceName,
	twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
	Sys_Int retVal = SYS_OK;
	twInfoTable *pInfoTable = NULL;
	Sys_Char *function = "StopEMSCallback";
	enum msgCodeEnum twMsgRetVal = TWX_SUCCESS;
	configparam *sConf = NULL;

	if (!pConfigparam->m_EmsStatus)
		*ppItContent = twInfoTable_CreateFromString("result", "EMS is already OFFLINE", TRUE);
	else {
		pConfigparam->m_EmsStatus = FALSE;
		retVal = EMSAgent_SetConfigData(pConfigparam);
		if (retVal != CONFIG_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: GetConfigData() failed!", function);
		}
		*ppItContent = twInfoTable_CreateFromString("result", "SUCCESS. EMS is now OFFLINE", TRUE);
	}
	if (*ppItContent == NULL)
		twMsgRetVal = TWX_UNSUPPORTED_CONTENT_FORMAT;

	twInfoTable_Delete(pInfoTable);
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);
	return twMsgRetVal;

}

enum msgCodeEnum StopEMSGracefullyCallback(const char *pszEntityName, const char *pszServiceName,
	twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
	Sys_Int retVal = SYS_OK;
	twInfoTable *pInfoTable = NULL;
	Sys_Char *function = "StopEMSServiceCallback";
	enum msgCodeEnum twMsgRetVal = TWX_SUCCESS;
	configparam *sConf = NULL;

	INTR_FLAG = 0;
	
	*ppItContent = twInfoTable_CreateFromString("result", "Keysight_EMS_Agent is getting stop", TRUE);
	if (*ppItContent == NULL)
		twMsgRetVal = TWX_UNSUPPORTED_CONTENT_FORMAT;
	twInfoTable_Delete(pInfoTable);
	return twMsgRetVal;
}


//Service to start the sidecar
enum msgCodeEnum StartSideCarCallback(const char *pszEntityName, const char *pszServiceName,
	twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
	Sys_Int retVal = 0;
	twInfoTable *pInfoTable = NULL;
	enum msgCodeEnum twMsgRetVal = TWX_SUCCESS;
	Sys_Char* buff = NULL;
	Sys_Char *function = "StartSideCarCallback";
	Sys_Int lenCWD = 0;
	Sys_Char *cdCMD = "cd ";
#ifdef WIN32
	Sys_Char * PathOfTheSideCar = "\\SideCar_EMS ";
	Sys_Char * wsemsExe = "&& start wsems.exe";
	Sys_Char * luaScriptExe = "&& start luaScriptResource.exe";
#else //For Linux ARM
	Sys_Char * PathOfTheSideCar = "/SideCar_EMS ";
	Sys_Char * wsemsExe = "&& ./wsems &";
	Sys_Char * luaScriptExe = "&& ./luaScriptResource &";
#endif
	Sys_Char *wsemsCompletePath = NULL;
	//static int count = 0;

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	buff = GetCWD();
	lenCWD = (Sys_Int)strlen(buff);
#ifndef WINXP
	Sys_Char *luaCompletePath = NULL;
	luaCompletePath = (Sys_Char*)Sys_Malloc(strlen(buff) + strlen(cdCMD) + strlen(PathOfTheSideCar) + strlen(luaScriptExe) + 1);
	strcpy(luaCompletePath, cdCMD);
	strcat(luaCompletePath, buff);
	strcat(luaCompletePath, PathOfTheSideCar);
	strcat(luaCompletePath, luaScriptExe);
#endif
	wsemsCompletePath = (Sys_Char*)Sys_Malloc(strlen(buff) + strlen(cdCMD) + strlen(PathOfTheSideCar) + strlen(wsemsExe) + 1);
	strcpy(wsemsCompletePath, cdCMD);
	strcat(wsemsCompletePath, buff);
	strcat(wsemsCompletePath, PathOfTheSideCar);
	strcat(wsemsCompletePath, wsemsExe);

	//Runs the wsems.exe 
	if (!SideCarMtx)
	{
		SideCarMtx = SysMutex_Create();
		retVal = system(wsemsCompletePath);
		//Runs the luaScriptResource.exe 
#ifndef WINXP
		retVal = system(luaCompletePath);
#endif
		//count++;
		if (retVal != SYS_RET_OK) {
			retVal = SYSLOG_WRONG_IP_PARAMS;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error in starting Sidecar. Errorcode = %d", function, retVal);
			*ppItContent = twInfoTable_CreateFromString("result", "Error in starting Sidecar", TRUE);
			SysMutex_Delete(SideCarMtx);
			SideCarMtx = NULL;
		}
		else {
			*ppItContent = twInfoTable_CreateFromString("result", "SUCCESS. Sidecar Started", TRUE);
			SysAppLog(SYS_INFO, MODULE_EMS_CONFIG, "%s: Sidecar Started", function);
		}
	}
	else
		*ppItContent = twInfoTable_CreateFromString("result", "WARNING. Side car is already running", TRUE);
		
	if (*ppItContent == NULL)
			twMsgRetVal = TWX_UNSUPPORTED_CONTENT_FORMAT;

	twInfoTable_Delete(pInfoTable);
	if (wsemsCompletePath) {
		Sys_Free(wsemsCompletePath);
		wsemsCompletePath = NULL;
	}
#ifndef WINXP
	if (luaCompletePath) {
		Sys_Free(luaCompletePath);
		luaCompletePath = NULL;
	}
#endif

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);

	return twMsgRetVal;
}

//Service to stop the sidecar
enum msgCodeEnum StopSideCarCallback(const char *pszEntityName, const char *pszServiceName,
	twInfoTable *pItParams, twInfoTable **ppItContent, void *pUserdata)
{
	Sys_Int retVal = 0;
	twInfoTable *pInfoTable = NULL;
	enum msgCodeEnum twMsgRetVal = TWX_SUCCESS;
	Sys_Char* buff = NULL;
	Sys_Char *function = "StopSideCarCallback";
	Sys_Int lenCWD = 0;
	Sys_Char *cdCMD = "cd ";
#ifdef WIN32
	Sys_Char * PathOfTheSideCar = "\\SideCar_EMS ";
	Sys_Char * wsemsExe = "&& Taskkill /F /IM wsems.exe"; //Added as in Win 8 forceful termination was needed
	Sys_Char * luaScriptExe = "&& Taskkill /F /IM luaScriptResource.exe"; //Added as in Win 8 forceful termination was needed
#else //For  Linux ARM
	Sys_Char * PathOfTheSideCar = "/SideCar_EMS ";
	Sys_Char * wsemsExe = "&& kill -9 `pidof wsems`";
	Sys_Char * luaScriptExe = "&& kill -9 `pidof luaScriptResource`";
#endif
	Sys_Char *wsemsCompletePath = NULL;

	Sys_Char *luaCompletePath = NULL;

	//static int count = 0;

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	buff = GetCWD();
	wsemsCompletePath = (Sys_Char*)Sys_Malloc(strlen(buff) + strlen(cdCMD) + strlen(PathOfTheSideCar) + strlen(wsemsExe) + 1);
	luaCompletePath = (Sys_Char*)Sys_Malloc(strlen(buff) + strlen(cdCMD) + strlen(PathOfTheSideCar) + strlen(luaScriptExe) + 1);

	buff = GetCWD();
	lenCWD = (Sys_Int)strlen(buff);
	strcpy(wsemsCompletePath, cdCMD);
	strcpy(luaCompletePath, cdCMD);
	strcat(wsemsCompletePath, buff);
	strcat(luaCompletePath, buff);
	strcat(wsemsCompletePath, PathOfTheSideCar);
	strcat(luaCompletePath, PathOfTheSideCar);
	strcat(wsemsCompletePath, wsemsExe);
	strcat(luaCompletePath, luaScriptExe);
	if (SideCarMtx)
	{
		SysMutex_Delete(SideCarMtx);
		SideCarMtx = NULL;
		//To stop the sidecar
		retVal = system(wsemsCompletePath);
		//To stop the sidecar
		retVal = system(luaCompletePath);
		if (retVal < SYS_EINIT) {
			retVal = SYSLOG_WRONG_IP_PARAMS;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error in stopping Sidecar. Errorcode= %d", function, retVal);
			*ppItContent = twInfoTable_CreateFromString("result", "Error in stopping Sidecar", TRUE);
			SideCarMtx = SysMutex_Create();
		}
		else {
			*ppItContent = twInfoTable_CreateFromString("result", "SUCCESS. Sidecar Stoped", TRUE);
			SysAppLog(SYS_INFO, MODULE_EMS_CONFIG, "%s: Sidecar Stopped", function);
		}
	}
	else { //When the EMS has restarted
		retVal = system(wsemsCompletePath);
		retVal = system(luaCompletePath);

		if (retVal < SYS_EINIT) {
			retVal = SYSLOG_WRONG_IP_PARAMS;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error in stopping Sidecar. Errorcode= %d", function, retVal);
			*ppItContent = twInfoTable_CreateFromString("result", "Error in stopping Sidecar", TRUE);
		}
		else
			*ppItContent = twInfoTable_CreateFromString("result", "SUCCESS. Sidecar Stoped", TRUE);
	}

	if (*ppItContent == NULL)
			twMsgRetVal = TWX_UNSUPPORTED_CONTENT_FORMAT;

	twInfoTable_Delete(pInfoTable);
	Sys_Free(wsemsCompletePath);
	Sys_Free(luaCompletePath);


	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);

	return twMsgRetVal;
}

/* Function to Stop Sidecar/LSR manually*/
Sys_Int StopSideCarFunction(Sys_Char *dumpFilePath)
{
	Sys_Int retVal = 0;
	twInfoTable *pInfoTable = NULL;
	enum msgCodeEnum twMsgRetVal = TWX_SUCCESS;
	Sys_Char* buff = NULL;
	Sys_Char *function = "StopSideCarCallback";
	Sys_Int lenCWD = 0;
	Sys_Char *cdCMD = "cd ";
#ifdef WIN32
	Sys_Char * PathOfTheSideCar = "\\SideCar_EMS ";
	Sys_Char * wsemsExe = "&& Taskkill /F /IM wsems.exe"; //Added as in Win 8 forceful termination was needed
	Sys_Char * luaScriptExe = "&& Taskkill /F /IM luaScriptResource.exe"; //Added as in Win 8 forceful termination was needed
#else //For  Linux ARM
	Sys_Char * PathOfTheSideCar = "/SideCar_EMS ";
	Sys_Char * wsemsExe = "&& kill -9 `pidof wsems`";
	Sys_Char * luaScriptExe = "&& kill -9 `pidof luaScriptResource`";
#endif
	Sys_Char *wsemsCompletePath = NULL;
	Sys_Char *luaCompletePath = NULL;

	//static int count = 0;

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered.", function);
	buff = GetCWD();
	wsemsCompletePath = (Sys_Char*)Sys_Malloc(strlen(buff) + strlen(cdCMD) + strlen(PathOfTheSideCar) + strlen(wsemsExe) + 1);

	luaCompletePath = (Sys_Char*)Sys_Malloc(strlen(buff) + strlen(cdCMD) + strlen(PathOfTheSideCar) + strlen(luaScriptExe) + 1);

	buff = GetCWD();
	lenCWD = (Sys_Int)strlen(buff);
	strcpy(wsemsCompletePath, cdCMD);
	strcpy(luaCompletePath, cdCMD);
	strcat(wsemsCompletePath, buff);
	strcat(luaCompletePath, buff);
	strcat(wsemsCompletePath, PathOfTheSideCar);
	strcat(luaCompletePath, PathOfTheSideCar);
	strcat(wsemsCompletePath, wsemsExe);
	strcat(luaCompletePath, luaScriptExe);

	if (SideCarMtx)
	{
		SysMutex_Delete(SideCarMtx);
		SideCarMtx = NULL;
	}

	//To stop the sidecar
	retVal = system(wsemsCompletePath);
	//To stop the LSR
	retVal = system(luaCompletePath);
	if (retVal < SYS_EINIT) {
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Error in stopping Sidecar/LSR. Errorcode= %d", function, retVal);
		SideCarMtx = SysMutex_Create();
	}
	else
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "SUCCESS. Sidecar/LSR Stopped", function);

	retVal = remove(dumpFilePath);
	if (!retVal)
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "Success in deleting temp dump file", function);
	else
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "Failed to delete temp dump file", function);

	if (wsemsCompletePath) {
		Sys_Free(wsemsCompletePath);
		wsemsCompletePath = NULL;
	}
	if (luaCompletePath) {
		Sys_Free(luaCompletePath);
		luaCompletePath = NULL;
	}


	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: exited.", function);

	return retVal;
}
