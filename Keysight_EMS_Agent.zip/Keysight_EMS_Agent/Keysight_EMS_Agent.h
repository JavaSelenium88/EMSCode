
#ifndef KEYSIGHT_EMS_AGENT_H_
#define KEYSIGHT_EMS_AGENT_H_

typedef void *keySightEHdle;

typedef enum KeysightEMSError_Codes_T {
	KEYSIGHT_EMS_SUCCESS = 0, /**< No error */
	KEYSIGHT_EMS_INSUFFICIENT_MEMORY = -1, /**< Memory allocation failed */
	KEYSIGHT_EMS_WRONG_IP_PARAMS = -2, /**< Wrong input parameters passed */
	KEYSIGHT_EMS_SYSTEM_ERROR = -3, /**< Some issue with system/platform */
	KEYSIGHT_EMS_CONFIG_FAIL = -4, /**< EMS_Config module failed */
	KEYSIGHT_EMS_SHUTDOWN_FAIL = -5, /**< EMS shutdown failed */
	KEYSIGHT_TWX_ERROR = -6, /**< Thingworx api/c-sdk related errors */
	KEYSIGHT_SYS_LOG_FAILURE = -7, /**< EMS SysLog module failure */
	KEYSIGHT_EMS_AGENT_FAIL = -8, /**< EMS Agent failure */
	KEYSIGHT_EMS_AGENT_ACQ_FAIL = -9, /**< EMS Agent Acq Thread failure */
	KEYSIGHT_EMS_AGENT_POST_FAIL = -10, /**< EMS Agent Post Thread failure */
	KEYSIGHT_EMS_CONFIG_STOP_FAIL = -11, /**< EMS Config Shutdown failure */
	KEYSIGHT_EMS_CONFIG_UNINIT_FAIL = -12, /**< EMS Config Uninit failure */
}KeysightEMSErrCodes;



KeysightEMSErrCodes EMS_Initialize();
KeysightEMSErrCodes EMS_Start();
KeysightEMSErrCodes EMSWait();
KeysightEMSErrCodes EMSShutdown();
KeysightEMSErrCodes EMSStop();
Sys_Int dumpFileDetect(Sys_Char *dumpFilePath);

void  IntHandler(int);

#endif /* KEYSIGHT_EMS_AGENT_H_ */
