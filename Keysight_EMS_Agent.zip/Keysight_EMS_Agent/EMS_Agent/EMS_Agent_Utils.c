/*****************************************************************************
//  Copyright © 2016 ITC .  All rights reserved.
//
******************************************************************************
//
//  Filename   : ThreadMgr_Utils.c
//
//  Subsystem  : KeySight
//
//  Author     : Soumya Ranjan Bej
//
//  Description: Thread related functions are handled here.
//
******************************************************************************/
#include "Sysapi.h"
#include "SysLog.h"
#include "cJSON.h"
#include "SysEvent.h"
#include "EMS_Config.h"
#include "JsonObjectCreator.h"
#include "EMS_Agent.h"
#include "EMS_Agent_Utils.h"

//*****************************************************************************
//   *********************   Support  Functions   *****************************
//*****************************************************************************

#define FIRST_SLEEP_TIME 10000
//Reverting the changes of Revision 461
/*
static Sys_Bool validThing = TRUE;

Sys_Bool ThingnameValidation() {
	if (validThing)
		return TRUE;
	else
		return FALSE;
}
*/

EMSAgentErrCodes InitNatData()
{
	Sys_Char *function = "InitNatData";
	EMSAgentErrCodes retVal = EMSAGENT_SUCCESS;
	pNatDataHdle = NULL;

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: entered.", function);
	
	pNatDataHdle = (pNatData)Sys_Malloc(sizeof(NatData));
	if (pNatDataHdle == NULL) {
		retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
		SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: Insufficient Memory! \n", function);
		goto failCall;
	}

	//pNatDataHdle->pHPrm = NULL;
	//pNatDataHdle->pEPrm = NULL;
	//pNatDataHdle->pUPrmS = NULL;
	//pNatDataHdle->pIPrmO = NULL;
	//pNatDataHdle->pUPrmO = NULL;
	//pNatDataHdle->pStrToSend = NULL;
	pNatDataHdle->pMutHdl = NULL;
	pNatDataHdle->pBfrToSend = NULL;
	pNatDataHdle->buffer_Length = 0;// (Sys_Uint)NULL;
	pNatDataHdle->pMutHdl = SysMutex_Create();
	
	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited.", function);
	return retVal;
	
failCall:
	if (pNatDataHdle) {
		//if (pNatDataHdle->pStrToSend) {
		//	Sys_Free(pNatDataHdle->pStrToSend);
		//	pNatDataHdle->pStrToSend = NULL;
		//}

		if (pNatDataHdle->pBfrToSend) {
			Sys_Free(pNatDataHdle->pBfrToSend);
			pNatDataHdle->pBfrToSend = NULL;
		}

		Sys_Free(pNatDataHdle);
		pNatDataHdle = NULL;
	}
	
	SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: exited with failure!", function);
	return retVal;
}

EMSAgentErrCodes UninitNatData()
{
	Sys_Char *function = "UninitNatData";
	EMSAgentErrCodes retVal = EMSAGENT_SUCCESS;

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: entered.", function);

	if (pNatDataHdle) {
		//if (pNatDataHdle->pStrToSend) {
		//	Sys_Free(pNatDataHdle->pStrToSend);
		//	pNatDataHdle->pStrToSend = NULL;
		//}

		if (pNatDataHdle->pBfrToSend) {
			Sys_Free(pNatDataHdle->pBfrToSend);
			pNatDataHdle->pBfrToSend = NULL;
		}

		if (pNatDataHdle->pMutHdl) {
			SysMutex_Delete(pNatDataHdle->pMutHdl);
			pNatDataHdle->pMutHdl = NULL;
		}
		
		Sys_Free(pNatDataHdle);
		pNatDataHdle = NULL;
	}

	return retVal;
	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited.", function);
}


Sys_Char *NativeAgent_TranslateError(NativeErrCodes errCode)
{
	Sys_Char *function = "NativeAgent_TranslateError";
	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: entered.", function);
	switch (errCode) {
	case NATIVE_SUCCESS: return "NATIVE_SUCCESS"; break;
	case NATIVE_INSUFFICIENT_MEMORY: return "NATIVE_INSUFFICIENT_MEMORY"; break;
	case NATIVE_WRONG_IP_PARAMS: return "NATIVE_WRONG_IP_PARAMS"; break;
	case NATIVE_SYSTEM_ERROR: return "NATIVE_SYSTEM_ERROR"; break;
	default: return "NATIVE_SUCCESS"; break;
	}
	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited.", function);
	return "NATIVE_SUCCESS";
}


void count_LCM_generator(Sys_Ullong *count, Sys_Ullong *least_multiple)
{
	Sys_Ulong acqHealth = 0; 
	Sys_Ulong acqUtil = 0;
	Sys_Ulong acqEnv = 0;
	Sys_Ulong acqInfo = 0;
	Sys_Ullong MinMulti = 0;
	Sys_Ulong num[4];
	Sys_Ulong temp = 0;
	int i = 0;
	int j = 0;

	Sys_Char *function = "count_LCM_generator";
	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: entered.", function);

	//SysMutex_Lock(gConf->mutexHdl);
	acqHealth = gConf->acquisition.health; //t1
	acqUtil = gConf->acquisition.utilization; //t2
	acqEnv = gConf->acquisition.environment; //t3
	acqInfo = gConf->acquisition.information; //t4
	//SysMutex_Unlock(gConf->mutexHdl);

	//if ((acqHealth <= acqUtil) && (acqHealth <= acqEnv) && (acqHealth <= acqInfo))
	//	*count = acqHealth;
	//else if ((acqUtil <= acqHealth) && (acqUtil <= acqEnv) && (acqUtil <= acqInfo))
	//	*count = acqUtil;
	//else if ((acqEnv <= acqUtil) && (acqEnv <= acqHealth) && (acqEnv <= acqInfo))
	//	*count = acqEnv;
	//else
	//	*count = acqInfo;

	num[0] = acqHealth;
	num[1] = acqUtil;
	num[2] = acqEnv;
	num[3] = acqInfo;

	for (i = 0; i < 4; ++i)
	{
		for (j = i + 1; j < 4; ++j)
		{
			if (num[i] > num[j])
			{
				temp = num[i];
				num[i] = num[j];
				num[j] = temp;
			}
		}
	}

	i = 0;
	if (num[i] > 0)
		*count = num[i];
	else {
		while (num[i] <= 0)
			i++;
		*count = num[i];
	}


	//Find LCM of numbers
	if (acqHealth <= 0) {
		acqHealth = 1;
	}
	if (acqUtil <= 0) {
		acqUtil = 1;
	}
	if (acqEnv <= 0) {
		acqEnv = 1;
	}
	if (acqInfo <= 0) {
		acqInfo = 1;
	}
	MinMulti = *count;
	while (1)
	{
		if ((MinMulti%acqHealth == 0) && (MinMulti%acqUtil == 0) && (MinMulti%acqEnv == 0) && (MinMulti%acqInfo == 0))
		{
			//printf("The LCM is %d\n", MinMulti);
			break;
		}
		++MinMulti;
	}
	*least_multiple = MinMulti;
	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited.", function);
}

//*****************************************************************************
#ifdef WIN32
DWORD WINAPI AcquisitionThreadFunction(void* pVoid)
#else
void* AcquisitionThreadFunction(void* pVoid)
#endif
{
	Sys_Ulong waitReturnCondition = WAIT_OBJECT_0;
	DATETIME wakeupTime = 0;
	/* Sys_Int twRetCode = TW_OK; */
	NativeErrCodes retValNat = NATIVE_SUCCESS;
	/* void *assets = NULL; */
	Sys_Ulong acqHealth = 0;
	Sys_Ulong acqUtil = 0;
	Sys_Ulong acqEnv = 0;
	Sys_Ulong acqInfo = 0;

	DATETIME now = 0;
	Sys_Ulong loopTime = 0;
	/* twPrimitive *pJsonHealthValue = NULL; */
	DATETIME previousWakeupTime = 0;
	SysThreadStruct* pThrdStrct = NULL;
	Sys_Char *function = "AcquisitionThreadFunction";
	/* cJSON *pJsonHealth = NULL; ToDo-Soumya-test code for CJON object */
	ConfigErrCodes confRetVal = CONFIG_SUCCESS;
	Param_Type natPrmType = PRM_HEALTH_SCPI;
	Param_Source natPrmSrc = SCPI_INT;
	SysThreadStruct *pPostThrdStrct = NULL;

	/* Variable rate help parameters*/
	Sys_Ullong least_multiple = 0;
	Sys_Ullong count = 0;
	Sys_Ullong reset = 0;
	Sys_Ullong countPrev = 0;
	Sys_Ullong f1 = 0;
	Sys_Ullong f2 = 0;
	Sys_Ullong f3 = 0;
	Sys_Ullong f4 = 0;
	Sys_Ulong sleeptime = 0;
	Sys_Bool first_iteration = FALSE; // Will be used at thread init
	Sys_Bool sec_iteration = FALSE; // Will be used for the #FIRST_SLEEP_TIME delay for the first payload

	/* Variables for new logic*/
	Sys_Ullong num[4];
	Sys_Ullong temp = 0;
	Sys_Uint bufLen = 0;
	Sys_Uint MaxBufLen = 0;
	Sys_Uint i = 0;
	Sys_Uint j = 0;

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: entered.", function);

	confRetVal = GetConfigData(&gConf);
	if (confRetVal != CONFIG_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: GetConfigData() failed!", function);
	}

	if (gConf->m_EmsStatus) {
		SysMutex_Lock(gConf->mutexHdl);
		count_LCM_generator(&count, &least_multiple);

		acqHealth = gConf->acquisition.health; //t1
		acqUtil = gConf->acquisition.utilization; //t2
		acqEnv = gConf->acquisition.environment; //t3
		acqInfo = gConf->acquisition.information; //t4
		SysMutex_Unlock(gConf->mutexHdl);

		reset = count;
		f1 = acqHealth;
		f2 = acqUtil;
		f3 = acqEnv;
		f4 = acqInfo;
	}
	// The pVoid input parameter is always the thread struct pointer
	pThrdStrct = (SysThreadStruct*)pVoid;
	if (!pThrdStrct) {
		// Log error & exit
		SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "%s:  Thread struct is NULL. Exiting thread!", function);
		return -1;
	}

	//while (!gConf->m_EmsStatus) //Added for the feature of EMS_Status to start, stop EMS Agent dynamically 

	pPostThrdStrct = (pSysThreadStruct) pThrdStrct->m_parameter2;
	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s:  Thread started.  Thread id = %lu", function, pThrdStrct->m_threadId);

	pThrdStrct->m_waitMilliSec = (Sys_Ulong)count; //Abhishek Added
	// continue processing data forever or at post rate while bRunning
	while (pThrdStrct->m_bRunning)
	{
		//SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s:  Thread timer-%d", function, acqRate);
		while (gConf->m_EmsStatus) {   //Added for the feature of EMS_Status to start, stop EMS Agent dynamically
			previousWakeupTime = wakeupTime;
			wakeupTime = SysGetSystemTime(TRUE);
			if (previousWakeupTime != 0) {
				SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "%s: delay b/w hits = %i ms. ", function, wakeupTime - previousWakeupTime);
			}

			SysMutex_Lock(gConf->mutexHdl);
			//Added
			if (!pNatDataHdle->pBfrToSend) {
				pNatDataHdle->pBfrToSend = (char *)Sys_Malloc(gConf->Max_Message_Size + 1);
				if (pNatDataHdle->pBfrToSend == NULL)
					SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: Insufficient Memory!", function);
			}
			bufLen = gConf->Max_Message_Size;
			Sys_Memset(pNatDataHdle->pBfrToSend, 0, bufLen);
			MaxBufLen = bufLen;
			//Will be hit only when we have a File transfer

			if ((acqHealth != gConf->acquisition.health) || (acqUtil != gConf->acquisition.utilization) || (acqEnv != gConf->acquisition.environment) || (acqInfo != gConf->acquisition.information)) {
				count_LCM_generator(&count, &least_multiple); //Abhishek Added
				acqHealth = gConf->acquisition.health; //t1
				acqUtil = gConf->acquisition.utilization; //t2
				acqEnv = gConf->acquisition.environment; //t3
				acqInfo = gConf->acquisition.information; //t4
				SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "CHECK");

				reset = count;
				f1 = acqHealth;
				f2 = acqUtil;
				f3 = acqEnv;
				f4 = acqInfo;
			}
			SysMutex_Unlock(gConf->mutexHdl);

			/** Retrieve Health parameters */
			/*natPrmType = PRM_HEALTH_SCPI;
			twMutex_Lock(pNatDataHdle->pMutHdl);
			retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, \
			(void **)&pNatDataHdle->pHPrm); */

			//ToDo:Akshata Added for testing purpose , Has to be removed once thread logic is available
			/*
			natPrmType = PRM_ENVIRONMENT_SCPI;
			retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, \
			(void **)&pNatDataHdle->pEPrm);
			SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "Value of Enviorment properties  %s ", pNatDataHdle->pEPrm);

			natPrmType = PRM_UTILIZATION_SCPI;
			retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, \
			(void **)&pNatDataHdle->pUPrmS);
			SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "Value of Utilization properties %s ", pNatDataHdle->pUPrmS);

			natPrmType = PRM_INFORMATION_SCPI;
			retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, \
			(void **)&pNatDataHdle->pIPrmO);
			SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "Value of Information properties %s ", pNatDataHdle->pIPrmO);
			*/

			//twMutex_Unlock(pNatDataHdle->pMutHdl);

			//"Akshata: JSON merge for future use" and commit the code.
			/** Retrieve Enviorment  parameters */

			/*natPrmType = PRM_ENVIRONMENT_SCPI;
			twMutex_Lock(pNatDataHdle->pMutHdl);
			retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, \
			(void **)&pNatDataHdle->pHPrm);
			twMutex_Unlock(pNatDataHdle->pMutHdl);
			*/
			if (!first_iteration)
			{
				sleeptime = FIRST_SLEEP_TIME; // (Sys_Ulong)count;
				first_iteration = TRUE;
			}
			else if (!sec_iteration) {

				SysMutex_Lock(pNatDataHdle->pMutHdl);
				/** Retrieve All parameters and Send for FIRST_SLEEP_TIME*/
				natPrmType = PRM_HEALTH_SCPI;
				pNatDataHdle->buffer_Length = bufLen;
				retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, (pNatDataHdle->pBfrToSend + (MaxBufLen - bufLen)), &pNatDataHdle->buffer_Length);
				if (retValNat == NATIVE_SUCCESS) {
					bufLen -= pNatDataHdle->buffer_Length;
				}

				natPrmType = PRM_UTILIZATION_SCPI;
				pNatDataHdle->buffer_Length = bufLen;
				retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, (pNatDataHdle->pBfrToSend + (MaxBufLen - bufLen)), &pNatDataHdle->buffer_Length);
				if (retValNat == NATIVE_SUCCESS) {
					bufLen -= pNatDataHdle->buffer_Length;
				}

				natPrmType = PRM_ENVIRONMENT_SCPI;
				pNatDataHdle->buffer_Length = bufLen;
				retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, (pNatDataHdle->pBfrToSend + (MaxBufLen - bufLen)), &pNatDataHdle->buffer_Length);
				if (retValNat == NATIVE_SUCCESS) {
					bufLen -= pNatDataHdle->buffer_Length;
				}

				natPrmType = PRM_INFORMATION_SCPI;
				pNatDataHdle->buffer_Length = bufLen;
				retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, (pNatDataHdle->pBfrToSend + (MaxBufLen - bufLen)), &pNatDataHdle->buffer_Length);
				if (retValNat == NATIVE_SUCCESS) {
					bufLen -= pNatDataHdle->buffer_Length;
				}
				SysMutex_Unlock(pNatDataHdle->pMutHdl);

				pNatDataHdle->buffer_Length = gConf->Max_Message_Size - bufLen;
				SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "Final value %s ", pNatDataHdle->pBfrToSend); //ToDo Abhishek: Update the logging level to Debug 
				//Signal the Post thread
				SysSignalThread(pPostThrdStrct);

				sleeptime = (Sys_Ulong)count;
				sec_iteration = TRUE;
			}
			else
			{
				if (count < least_multiple + 1)
				{
				//	pNatDataHdle->check_Byte = 0;
					if (acqHealth > 0) {
						if (count%acqHealth == 0)
						{
							/** Retrieve Health parameters */
							natPrmType = PRM_HEALTH_SCPI;
							SysMutex_Lock(pNatDataHdle->pMutHdl);
							pNatDataHdle->buffer_Length = bufLen;
							retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, (pNatDataHdle->pBfrToSend + (MaxBufLen - bufLen)), &pNatDataHdle->buffer_Length);
							if (retValNat == NATIVE_SUCCESS) {
								bufLen -= pNatDataHdle->buffer_Length;
							}
							//pNatDataHdle->pBfrToSend[pNatDataHdle->buffer_Length] = '\0';
						//	pNatDataHdle->check_Byte = pNatDataHdle->check_Byte | 1; //Health for 0001
						//	SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "Value of Health properties %s ", pNatDataHdle->pBfrToSend);
							SysMutex_Unlock(pNatDataHdle->pMutHdl);

							f1 = count + acqHealth;
						}
					}
					if (acqUtil > 0) {
						if (count%acqUtil == 0)
						{
							natPrmType = PRM_UTILIZATION_SCPI;
							SysMutex_Lock(pNatDataHdle->pMutHdl);
							pNatDataHdle->buffer_Length = bufLen;
							retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, (pNatDataHdle->pBfrToSend + (MaxBufLen - bufLen)), &pNatDataHdle->buffer_Length);
							if (retValNat == NATIVE_SUCCESS) {
								bufLen -= pNatDataHdle->buffer_Length;
							}
							//pNatDataHdle->pBfrToSend[pNatDataHdle->buffer_Length] = '\0';
						//	pNatDataHdle->check_Byte = pNatDataHdle->check_Byte | 2; //Util for 0010
						//	SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "Value of Utilization properties %s ", pNatDataHdle->pBfrToSend);
							SysMutex_Unlock(pNatDataHdle->pMutHdl);

							f2 = count + acqUtil;
						}
					}
					if (acqEnv > 0) {
						if (count%acqEnv == 0)
						{
							natPrmType = PRM_ENVIRONMENT_SCPI;
							SysMutex_Lock(pNatDataHdle->pMutHdl);
							pNatDataHdle->buffer_Length = bufLen;
							retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, (pNatDataHdle->pBfrToSend + (MaxBufLen - bufLen)), &pNatDataHdle->buffer_Length);
							if (retValNat == NATIVE_SUCCESS) {
								bufLen -= pNatDataHdle->buffer_Length;
							}
							//pNatDataHdle->pBfrToSend[pNatDataHdle->buffer_Length] = '\0';
						//	pNatDataHdle->check_Byte = pNatDataHdle->check_Byte | 4; //Env for 0100
						//	SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "Value of Enviorment properties  %s ", pNatDataHdle->pBfrToSend);
							SysMutex_Unlock(pNatDataHdle->pMutHdl);

							f3 = count + acqEnv;
						}
					}
					if (acqInfo > 0) {
						if (count%acqInfo == 0)
						{
							natPrmType = PRM_INFORMATION_SCPI;
							SysMutex_Lock(pNatDataHdle->pMutHdl);
							pNatDataHdle->buffer_Length = bufLen;
							retValNat = NatAgent_GetData(pThrdStrct->m_parameter1, &natPrmType, &natPrmSrc, (pNatDataHdle->pBfrToSend + (MaxBufLen - bufLen)), &pNatDataHdle->buffer_Length);
							if (retValNat == NATIVE_SUCCESS) {
								bufLen -= pNatDataHdle->buffer_Length;
							}
							//pNatDataHdle->pBfrToSend[pNatDataHdle->buffer_Length] = '\0';
						//	pNatDataHdle->check_Byte = pNatDataHdle->check_Byte | 8; //Info for 1000
						//	SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "Value of Information properties %s ", pNatDataHdle->pBfrToSend);
							SysMutex_Unlock(pNatDataHdle->pMutHdl);

							f4 = count + acqInfo;
						}
					}
					countPrev = count;
				//	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "Byte  %d", pNatDataHdle->check_Byte);
					////
					/*if ((f1 <= f2) && (f1 <= f3) && (f1 <= f4))
						count = f1;
					else if ((f2 <= f1) && (f2 <= f3) && (f2 <= f4))
						count = f2;
					else if ((f3 <= f2) && (f3 <= f1) && (f3 <= f4))
						count = f3;
					else
						count = f4;*/

					//New logic
					num[0] = f1;
					num[1] = f2;
					num[2] = f3;
					num[3] = f4;

					for (i = 0; i < 4; ++i)
					{
						for (j = i + 1; j < 4; ++j)
						{
							if (num[i] > num[j])
							{
								temp = num[i];
								num[i] = num[j];
								num[j] = temp;
							}
						}
					}

					i = 0;
					if (num[i] > 0)
						count = num[i];
					else {
						while (num[i] <= 0)
							i++;
						count = num[i];
					}

					sleeptime = (Sys_Ulong)(count - countPrev);
					SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: Count = %lu", function, countPrev);
					if (countPrev == least_multiple)
					{
						count = reset;
						f1 = acqHealth;
						f2 = acqUtil;
						f3 = acqEnv;
						f4 = acqInfo;
					}
				}
				//pNatDataHdle->pBfrToSend[gConf->Max_Message_Siz] = '\0';
				pNatDataHdle->buffer_Length = gConf->Max_Message_Size - bufLen;
//				pNatDataHdle->pBfrToSend[pNatDataHdle->buffer_Length] = '\0';
				SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "Final value %s ", pNatDataHdle->pBfrToSend);
				//Signal the Post thread
				SysSignalThread(pPostThrdStrct);
			}//End of else of First Iteration

			if (retValNat != NATIVE_SUCCESS) {
				SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: NatAgent_GetData() Health returned- %s", \
					function, NativeAgent_TranslateError(retValNat));
			}


			//calculate the total time within the processing loop.
			now = SysGetSystemTime(TRUE);
			loopTime = (Sys_Ulong)(now - wakeupTime);

			//update the wait time before the next scan.
			pThrdStrct->m_waitMilliSec = CalcDelay(sleeptime, loopTime);
			SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: nextThreadTimer=%d ms, ProcessingTime= %i ms, SleepTime= %i ms", function, sleeptime, loopTime, pThrdStrct->m_waitMilliSec);

			SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s:  m_EmsStatus : %d", function, gConf->m_EmsStatus);

			waitReturnCondition = SysThreadWaitForRunCycle(pThrdStrct);
			if (!pThrdStrct->m_bRunning) {
				SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s:  Exiting thread as pThrdStrct->m_bRunning= ",
					function, pThrdStrct->m_bRunning);
				break;
			}

			if (waitReturnCondition == WAIT_OBJECT_0) {
				SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s:  Signal received. at thread 1", function);
			}
			else {
				SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s:  Thread wakup due to timeout", function);
			}
		}
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited.", function);

	return 0;
}

#ifdef WIN32
DWORD WINAPI PostThreadFunction(void* pVoid)
#else
void* PostThreadFunction(void* pVoid)
#endif
{
	Sys_Ulong waitReturnCondition = WAIT_OBJECT_0;
	Sys_Int twRetCode = TW_OK;
	//commented as part of warning fix
	//void *assets = NULL;
	twPrimitive *pJsonHealthValue = NULL;
	SysThreadStruct* pThrdStrct = NULL;
	Sys_Char *function = "PostThreadFunction";
	//commented as part of warning fix
	//cJSON *pJsonHealth = NULL; //ToDo-Soumya-test code for CJON object
	//Sys_Bool bSendOn = SYS_FALSE;
	twPrimitive *twPayloadValue = NULL;

	
//	size_t strLength = 0;
//	size_t tmpLen = 0;
	//"Akshata: JSON merge for future use" and commit the code.
	//cJSON *pJsonENV = NULL; //ToDo-Akshata-test code for CJON object
	//cJSON *pJsonRoot = NULL;
	//pNatDataHdle->pStrToSend = NULL;

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: entered.", function);

	// The pVoid input parameter is always the thread struct pointer
	pThrdStrct = (SysThreadStruct*)pVoid;
	if (!pThrdStrct) {
		// Log error & exit
		SysAppLog(SYS_FORCE, MODULE_EMS_AGENT, "%s:  Thread struct is NULL. Exiting thread!", function);
		return -1;
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s:  Thread started.  Thread id = %lu", function, pThrdStrct->m_threadId);

	// continue processing data forever or at post rate while bRunning
	while (pThrdStrct->m_bRunning)
	{
		waitReturnCondition = SysThreadWaitForRunCycle(pThrdStrct);
		if (!pThrdStrct->m_bRunning) {
			SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s:  Exiting thread as pThrdStrct->m_bRunning= ",
				function, pThrdStrct->m_bRunning);
			break;
		}

		SysMutex_Lock(pNatDataHdle->pMutHdl);
		SysMutex_Lock(gConf->mutexHdl);

		//if (!pNatDataHdle->pStrToSend) {
		//	pNatDataHdle->pStrToSend = (char *)Sys_Malloc(gConf->Max_Message_Size + 1);
		//	if (pNatDataHdle->pStrToSend == NULL)
		//		SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: Insufficient Memory. Exiting thread!", function);
		//}

	//	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "Byte : %d ",pNatDataHdle->check_Byte);
		//bSendOn = SYS_TRUE;

		//while (bSendOn) {
			
			//if (pNatDataHdle->check_Byte & 1){//Health
			//	tmpLen = strlen(pNatDataHdle->pHPrm);
			//	if ((strLength + tmpLen) < gConf->Max_Message_Size) {
			//	Sys_Memcpy(&pNatDataHdle->pStrToSend[strLength], pNatDataHdle->pHPrm, tmpLen);
			//	strLength += tmpLen;
			//	pNatDataHdle->check_Byte &= 14;
			//	}
			//}

			//
			//if (pNatDataHdle->check_Byte & 2) {//Utilization
			//	tmpLen = strlen(pNatDataHdle->pUPrmS);
			//	if ((strLength + tmpLen) < gConf->Max_Message_Size) {
			//		Sys_Memcpy(&pNatDataHdle->pStrToSend[strLength], pNatDataHdle->pUPrmS, tmpLen);
			//		strLength += tmpLen;
			//		pNatDataHdle->check_Byte &= 13;
			//	}
			//}

			//
			//if (pNatDataHdle->check_Byte & 8) {//Information
			//	tmpLen = strlen(pNatDataHdle->pIPrmO);
			//	if ((strLength + tmpLen) < gConf->Max_Message_Size) {
			//		Sys_Memcpy(&pNatDataHdle->pStrToSend[strLength], pNatDataHdle->pIPrmO, tmpLen);
			//		strLength += tmpLen;
			//		pNatDataHdle->check_Byte &= 7;
			//	}
			//}

			//
			//if (pNatDataHdle->check_Byte & 4) {//Enviornment
			//	tmpLen = strlen(pNatDataHdle->pEPrm);
			//	if ((strLength + tmpLen) < gConf->Max_Message_Size) {
			//		Sys_Memcpy(&pNatDataHdle->pStrToSend[strLength], pNatDataHdle->pEPrm, tmpLen);
			//		strLength += tmpLen;
			//		pNatDataHdle->check_Byte &= 11;
			//	}
			//}

			//pNatDataHdle->pStrToSend[strLength] = '\0';
		//twPayloadValue = twPrimitive_CreateFromString(pNatDataHdle->pBfrToSend, TRUE);
		//Calling the ITC's Customized API.
		twPayloadValue = twPrimitive_CreateFromCustomString(pNatDataHdle->pBfrToSend, TRUE ,pNatDataHdle->buffer_Length);
		twRetCode = twApi_WriteProperty(TW_THING, gConf->m_ThingName, "Health",
				twPayloadValue, -1, 0);
		if (twRetCode != TW_OK) {
				SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, \
					"%s:  Error in writing property '%s'.  TW error code: %i", function, \
					"Health", twRetCode);
			}

		//Reverting the changes of Revision 461
		/*
		if (twRetCode == TW_INTERNAL_SERVER_ERROR) { //Wrong Thing Name
			SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s:Unable to Write Property. INVALID THINGNAME. Error Code : %d", function, twRetCode);
			validThing = FALSE;
		} */
			
			//	if (pNatDataHdle->check_Byte == 0)
			//bSendOn = SYS_FALSE;

		//	strLength = 0;
			if (twPayloadValue) { //Added after Valgrind mem check
				Sys_Free(twPayloadValue);
				twPayloadValue = NULL;
			}
		//}
//		tmpLen = 0;
//		strLength = 0;

		//Akshata: JSON merge for future use".
		/*
		//assets = pNatDataHdle->pHPrm;
		FormJsonOBJFromStruct(assets, &pJsonENV, PRM_ENVIRONMENT_SCPI);
		pJsonRoot = cJSON_CreateObject();
		cJSON_AddItemToObject(pJsonRoot, STR_HEALTH_PARAMS, pJsonHealth);
		cJSON_AddItemToObject(pJsonRoot, STR_ENV_PARAMS, pJsonENV);

		SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: JSON Obj: %s", \
			function, cJSON_Print(pJsonRoot));

		pJsonHealthValue = twPrimitive_CreateFromJson(pJsonRoot, NULL, TW_JSON);
		*/

		//Write the values to TWX Platform (Without clubbing the json object )
		/*SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: JSON Obj: %s", \
			function, cJSON_Print(pJsonHealth));
		pJsonHealthValue = twPrimitive_CreateFromJson(pJsonHealth, NULL, TW_JSON);
		
		cJSON *pJsonHealthReturn = NULL;
		pJsonHealthReturn=twPrimitive_ToJson("healthReturn", pJsonHealthValue, NULL);*/

		/*twRetCode = twApi_WriteProperty(TW_THING, gConf->m_ThingName, "Health",
			pJsonHealthValue, -1, 0);
		if (twRetCode != TW_OK) {
			SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, \
				"%s:  Error in writing property '%s'.  TW error code: %i",function,\
				"Health", twRetCode);
		}
		

		if (pJsonHealthValue) {
			twPrimitive_Delete(pJsonHealthValue);//Deleting the twPrimitive
			pJsonHealthValue = NULL;
		}

		if (pJsonHealth) {
			cJSON_Delete(pJsonHealth); //deleting the JSON object created
			pJsonHealth = NULL;
		}*/

		//Akshata: JSON merge for future use".
		//if (pJsonRoot) {
		//	cJSON_Delete(pJsonRoot); //deleting the JSON object created
		//	pJsonRoot = NULL;
		//}
		SysMutex_Unlock(gConf->mutexHdl);
		SysMutex_Unlock(pNatDataHdle->pMutHdl);
		if (waitReturnCondition == WAIT_OBJECT_0) {
			SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s:  Signal received. at Post thread", function);
		}
		else {
			SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s:  Thread wakup due to timeout", function);
		}
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited.", function);

	return 0;
}

//*****************************************************************************
// calculate the delay for the acquisition loop.  The goal is to maintain a 
// constant/consistent aquisition loop timing w/o jitter.
//
// input: 
//   - calculatedDelay: can either be a calculated delay or the configured delay
//   - actualLoopTime: the time spent in the  last acquisition loop.
// return:  the delay for the next acquisition loop.
//           
Sys_Ulong CalcDelay(Sys_Ulong calculatedDelay, Sys_Ulong actualLoopTime)
{
	Sys_Char *function = "CalcDelay";
	Sys_Ulong delay = 10000;

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: entered.", function);
	// The last acquisition loop took 'loopTime' milliseconds.
	// Adjust the next delay by the time it took to loop.
	// This keeps a consistent data rate.
	if (actualLoopTime > calculatedDelay)
	{
		delay = 0;
	}
	else
	{
		delay = calculatedDelay - actualLoopTime;
	}
	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited.", function);
	return delay;
}
