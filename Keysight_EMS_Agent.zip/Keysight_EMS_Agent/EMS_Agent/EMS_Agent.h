/*****************************************************************************
//  Copyright � 2016 ITC .  All rights reserved.
//
******************************************************************************
//
//  Filename   : ThreadMgr.h
//
//  Subsystem  : KeySight
//
//  Author     : Soumya Ranjan Bej
//
//  Description: Thread related functions are handled here.
//
******************************************************************************/
#ifndef __EMS_AGENT_H__
#define __EMS_AGENT_H__

#include "SysThread.h"

typedef enum EMSAgent_ThreadType_T {
	EMSAGNT_ACQUISTION_THRD, /**< Acquistion Thread .*/
	EMSAGNT_POST_THRD, /**< Posting Thread */
	EMSAGNT_IDLE
}EMSAgent_ThreadType;

typedef enum EMSAgent_Error_Codes_T {
	EMSAGENT_SUCCESS = 0, /**< No error */
	EMSAGENT_ERROR_ALLOCATING_MEMORY = -1, /**< Memory allocation failed */
	EMSAGENT_WRONG_IP_PARAMS = -2, /**< Wrong input/invalid parameters passed */
	EMSAGENT_SYSTEM_ERROR = -3, /**< Some issue with system/platform */
	EMSAGENT_TWX_ERROR = -4, /**< Thingworx api/c-sdk related errors */
	EMSAGENT_NAT_ERROR = -5 /**< Native Agent Error */
}EMSAgentErrCodes;

/********************************************** Interface APIs **********************************************/

EMSAgentErrCodes EMSAgent_Init(
	void **ppHdl /**< Opaque handle to be registered */
	);

EMSAgentErrCodes EMSAgent_Uninit(
	void *pHdl /**< Opaque Handle */
	);

EMSAgentErrCodes EMSAgent_Start(
	void *pHdl, /**< Opaque handle */
	EMSAgent_ThreadType typ
	);

EMSAgentErrCodes EMSAgent_Stop(
	void *pHdl,
	EMSAgent_ThreadType typ
	);

EMSAgentErrCodes EMSAgent_SetConfigData(
	configparam *pConfig
	);

//Reverting the changes of Revision 461
//Sys_Bool ThingnameValidation(); /**< Returns boolean value depending on the Validity of Thingname */
#endif // __EMS_AGENT_H__
