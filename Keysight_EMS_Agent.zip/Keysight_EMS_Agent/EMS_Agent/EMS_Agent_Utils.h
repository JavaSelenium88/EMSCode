/*****************************************************************************
//  Copyright � 2016 ITC .  All rights reserved.
//
******************************************************************************
//
//  Filename   : ThreadMgr_Utils.h
//
//  Subsystem  : KeySight
//
//  Author     : Soumya Ranjan Bej
//
//  Description: Thread related functions are handled here.
//
******************************************************************************/
#ifndef __EMS_AGENT_UTILS_H__
#define __EMS_AGENT_UTILS_H__

/********************************************** Interface Datatypes **********************************************/
typedef void *pEMSAgntHdl; 

configparam *gConf;

typedef struct NatData_T{
	//Sys_Char *pHPrm;
	//Sys_Char *pUPrmS; //TODO: remove S suffix???
	//Sys_Char *pEPrm;
	/*pParam_Health pHPrm;
	pParam_Environment pEPrm;
	pParam_Utilization_SCPI pUPrmS; */
	//Sys_Char *pIPrmO; //TODO: remove O suffix???
	Sys_Ulong buffer_Length;
	//Sys_Byte check_Byte; 
	//Sys_Char *pStrToSend;
	Sys_Char *pBfrToSend;
	SYS_MUTEX pMutHdl;
}NatData, *pNatData;

pNatData pNatDataHdle;

typedef struct emsAgtThrdHdl_T {
	pSysThreadStruct pThrdStrct; /**< Thread structure per handle */
	void *pEMSHdl; /**< Handle for storing any information. Ex.Native agent handle */
	EMSAgent_ThreadType thrTyp; /**< Type/Name of the thread */
}emsAgtThrdHdl, *pemsAgtThrdHdl;

typedef struct emsAgentHdle_T {
	pemsAgtThrdHdl pAcqHdl; /**< handle for Acquisition */
	pemsAgtThrdHdl pPostHdl; /**< handle for Posting */
}emsAgentHdle, *pemsAgentHdle;

EMSAgentErrCodes InitNatData();
EMSAgentErrCodes UninitNatData();

Sys_Char* NativeAgent_TranslateError(NativeErrCodes errCode);

void count_LCM_generator(Sys_Ullong *count, Sys_Ullong *least_multiple);
// function prototypes
#ifdef WIN32
DWORD WINAPI AcquisitionThreadFunction(void* pVoid);

DWORD WINAPI PostThreadFunction(void* pVoid);
#else
void* AcquisitionThreadFunction(void* pVoid);

void* PostThreadFunction(void* pVoid);

#endif

// calculate the delay for the acquisition loop.  The goal is to maintain a 
// constant/consistent aquisition loop timing w/o jitter.
//
// input: 
//   - calculatedDelay: can either be a calculated delay or the configured delay
//   - actualLoopTime: the time spent in the  last acquisition loop.
// return:  the delay for the next acquisition loop.
Sys_Ulong CalcDelay(Sys_Ulong calculatedDelay, Sys_Ulong actualLoopTime);

//void SignalThread1();

void InitializeThread2();

Sys_Int Thread2_Start();

void Thread2_Shutdown();

//void SignalThread2();

#endif // __EMS_AGENT_UTILS_H__
