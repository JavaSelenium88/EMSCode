/*****************************************************************************
//  Copyright © 2016 ITC .  All rights reserved.
//
******************************************************************************
//
//  Filename   : Thread1Mgr.c
//
//  Subsystem  : KeySight
//
//  Author     : Soumya Ranjan Bej
//
//  Description: Thread realated functions are handled here.
//
******************************************************************************/

#include "SysLog.h"
#include "Sysapi.h"
#include "SysEvent.h"
#include "EMS_Config.h"
#include "JsonObjectCreator.h"
#include "EMS_Agent.h"
#include "EMS_Agent_Utils.h"


EMSAgentErrCodes EMSAgent_Init(
	void **ppHdl
	)
{
	EMSAgentErrCodes retVal = EMSAGENT_SUCCESS;
	NativeErrCodes retValNat = NATIVE_SUCCESS;
	pemsAgentHdle pEAHdl = NULL;
	Sys_Char *function = "EMS_Agent_Init";
	pEMSAgntHdl pNatHdl = NULL;

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: entered.", function);

	if (*ppHdl == NULL) {
		pEAHdl = (pemsAgentHdle) Sys_Malloc(sizeof(emsAgentHdle));
		if (pEAHdl == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: Insufficient Memory!", function);
			goto failCall;
		}

		/** Initilizing post thread */
		pEAHdl->pPostHdl = (pemsAgtThrdHdl)Sys_Malloc(sizeof(emsAgtThrdHdl));
		if (pEAHdl->pPostHdl == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: pPostHdl-Insufficient Memory!", function);
			goto failCall;
		}

		pEAHdl->pPostHdl->pThrdStrct = NULL;
		pEAHdl->pPostHdl->pThrdStrct = SysCreateThreadStruct();
		if (pEAHdl->pPostHdl->pThrdStrct == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: pPostHdl->pThrdStrct-Insufficient Memory!", function);
			goto failCall;
		}
		pEAHdl->pPostHdl->pThrdStrct->m_waitMilliSec = INFINITE;
		pEAHdl->pPostHdl->thrTyp = EMSAGNT_POST_THRD;
		pEAHdl->pPostHdl->pEMSHdl = NULL;

		/** Initilizing acquisition thread */
		pEAHdl->pAcqHdl = (pemsAgtThrdHdl)Sys_Malloc(sizeof(emsAgtThrdHdl));
		if (pEAHdl->pAcqHdl == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: pAcqHdl-Insufficient Memory!", function);
			goto failCall;
		}

		pEAHdl->pAcqHdl->pThrdStrct = NULL;
		pEAHdl->pAcqHdl->pThrdStrct = SysCreateThreadStruct();
		if (pEAHdl->pAcqHdl->pThrdStrct == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: pAcqHdl->pThrdStrct-Insufficient Memory!", function);
			goto failCall;
		}
		pEAHdl->pAcqHdl->pThrdStrct->m_waitMilliSec = INFINITE;
		pEAHdl->pAcqHdl->thrTyp = EMSAGNT_ACQUISTION_THRD;
		pEAHdl->pAcqHdl->pEMSHdl = NULL;

		/** Intialize Native agent */
		retValNat = NatAgent_Init(&pNatHdl);
		if (retValNat != NATIVE_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: NatAgent_Init() returned- %s", \
				function, NativeAgent_TranslateError(retValNat));
			retVal = EMSAGENT_NAT_ERROR;
			goto failCall;
		}
		pEAHdl->pAcqHdl->pEMSHdl = pNatHdl; /**< Native handle stored in thread handle */
		pEAHdl->pAcqHdl->pThrdStrct->m_parameter1 = pNatHdl; /**< Native handle stored in thread structure to be used in thread function. */
		pEAHdl->pAcqHdl->pThrdStrct->m_parameter2 = pEAHdl->pPostHdl->pThrdStrct; /**< Post thread hdle for signalling the thread */

		/** Global native agent data structure initialization */
		retVal = InitNatData();
		if (retVal != EMSAGENT_SUCCESS) {
			SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: InitNatData() failed!", function);
			goto failCall;
		}
	}
	else {
		retVal = EMSAGENT_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: Wrong IP pHdl passed!", function);
		goto failCall;
	}

	*ppHdl = pEAHdl;

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited!", function);
	return retVal;

failCall:
	if (pEAHdl) {
		if (pEAHdl->pAcqHdl) {
			if (pEAHdl->pAcqHdl->pThrdStrct) {
				SysDestroyThreadStruct(pEAHdl->pAcqHdl->pThrdStrct);
				pEAHdl->pAcqHdl->pThrdStrct = NULL;
			}

			if (pEAHdl->pAcqHdl->pEMSHdl) {
				NatAgent_Uninit(pEAHdl->pAcqHdl->pEMSHdl);
				pEAHdl->pAcqHdl->pEMSHdl = NULL;
			}

			pEAHdl->pAcqHdl->thrTyp = EMSAGNT_IDLE;

			Sys_Free(pEAHdl->pAcqHdl);
			pEAHdl->pAcqHdl = NULL;
		}

		if (pEAHdl->pPostHdl) {
			if (pEAHdl->pPostHdl->pThrdStrct) {
				SysDestroyThreadStruct(pEAHdl->pPostHdl->pThrdStrct);
				pEAHdl->pPostHdl->pThrdStrct = NULL;
			}

			pEAHdl->pPostHdl->thrTyp = EMSAGNT_IDLE;

			Sys_Free(pEAHdl->pPostHdl);
			pEAHdl->pPostHdl = NULL;
		}

		Sys_Free(pEAHdl);
		pEAHdl = NULL;
	}

	retVal = UninitNatData();
	if (retVal != EMSAGENT_SUCCESS){
		SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: UninitNatData() failed", function);
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited with error!", function);
	return retVal;
}

//*****************************************************************************
EMSAgentErrCodes EMSAgent_Uninit(
	void *pHdl 
	)
{
	/* NativeErrCodes retValNat = NATIVE_SUCCESS; */
	EMSAgentErrCodes retVal = EMSAGENT_SUCCESS;
	Sys_Char *function = "EMSAgent_Uninit";
	pemsAgentHdle pEAHdl = (pemsAgentHdle) pHdl;

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: entered.", function);

	if (pEAHdl != NULL) {
		if (pEAHdl->pAcqHdl) {
			if (pEAHdl->pAcqHdl->pThrdStrct) {
				SysDestroyThreadStruct(pEAHdl->pAcqHdl->pThrdStrct);
				pEAHdl->pAcqHdl->pThrdStrct = NULL;
			}

			if (pEAHdl->pAcqHdl->pEMSHdl) {
				NatAgent_Uninit(pEAHdl->pAcqHdl->pEMSHdl);
				pEAHdl->pAcqHdl->pEMSHdl = NULL;
			}

			pEAHdl->pAcqHdl->thrTyp = EMSAGNT_IDLE;

			Sys_Free(pEAHdl->pAcqHdl);
			pEAHdl->pAcqHdl = NULL;
		}

		if (pEAHdl->pPostHdl) {
			if (pEAHdl->pPostHdl->pThrdStrct) {
				SysDestroyThreadStruct(pEAHdl->pPostHdl->pThrdStrct);
				pEAHdl->pPostHdl->pThrdStrct = NULL;
			}

			pEAHdl->pPostHdl->thrTyp = EMSAGNT_IDLE;

			Sys_Free(pEAHdl->pPostHdl);
			pEAHdl->pPostHdl = NULL;
		}

		Sys_Free(pEAHdl);
		pEAHdl = NULL;
	}
	else {
		retVal = EMSAGENT_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: wrong params passed!", function);
	}
	
	retVal = UninitNatData();
	if (retVal != EMSAGENT_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: UninitNatData() failed!", function);
	}
	
	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited.", function);
	return retVal;
}

/*void InitializeThread1()
{
	NativeErrCodes retValNat = NATIVE_SUCCESS;

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "Inside :InitializeThread1");

	g_pDataProcessingThreadStruct = SysCreateThreadStruct();
	g_pDataProcessingThreadStruct->m_waitMilliSec = INFINITE;

	//Intialize Native agent
	gNatDataAcq.pHdle = NULL;
	retValNat = NatAgent_Init(&gNatDataAcq.pHdle);
	if (retValNat != NATIVE_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "NatAgent_Init() returned- %s", \
			NativeAgent_TranslateError(retValNat));
	}
}*/

//*****************************************************************************
EMSAgentErrCodes EMSAgent_Start(
	void *pHdl,
	EMSAgent_ThreadType typ
	)
{
	EMSAgentErrCodes retVal = EMSAGENT_SUCCESS;
	Sys_Char *function = "EMS_Agent_Start";
	pemsAgentHdle pEAHdl = (pemsAgentHdle)pHdl;
	
	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: entered.", function);

	if (pEAHdl != NULL) {
		// start the thread
		switch (typ) {
		case EMSAGNT_ACQUISTION_THRD:
			if (pEAHdl->pAcqHdl->pThrdStrct == NULL){
				retVal = EMSAGENT_WRONG_IP_PARAMS;
				SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: EMSAGNT_ACQUISTION_THRD - Insufficient Memory!",function);
				}
			else
			{
				SysStartThread(pEAHdl->pAcqHdl->pThrdStrct, AcquisitionThreadFunction); //TODO: Vishal: Retrun value??
			}
			break;

		case EMSAGNT_POST_THRD:
			if (pEAHdl->pPostHdl->pThrdStrct == NULL){
				retVal = EMSAGENT_WRONG_IP_PARAMS;
				SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: EMSAGNT_POST_THRD - Insufficient Memory!",function);
				}
			else{
				SysStartThread(pEAHdl->pPostHdl->pThrdStrct, PostThreadFunction); //TODO: Vishal: Retrun value??
				}
			break;
		case EMSAGNT_IDLE:
		default:
			SysAppLog(SYS_INFO, MODULE_EMS_AGENT, "%s: TBD ", function);
			break;
		}
	}
	else {
		retVal = EMSAGENT_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: wrong params passed!", function);
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited.", function);

	return retVal;
}

//*****************************************************************************
EMSAgentErrCodes EMSAgent_Stop(
	void *pHdl,
	EMSAgent_ThreadType typ
	)
{
	EMSAgentErrCodes retVal = EMSAGENT_SUCCESS;
	Sys_Char *function = "EMSAgent_Stop";
	pemsAgentHdle pEAHdle = (pemsAgentHdle)pHdl;
	pemsAgtThrdHdl pThHdl = NULL;

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: entered.", function);
	if (pEAHdle != NULL) {
		pThHdl = (typ == EMSAGNT_ACQUISTION_THRD) ? pEAHdle->pAcqHdl : pEAHdle->pPostHdl;
		// stop data processing 
		if (pThHdl->pThrdStrct != NULL){
			SysStopThread(pThHdl->pThrdStrct);

			gConf->m_EmsStatus = SYS_FALSE;   //Added for the feature of EMS_Status to start, stop EMS Agent dynamically
		}
	}
	else {
		retVal = EMSAGENT_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: wrong params passed!", function);
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited.", function);
	return retVal;
}

EMSAgentErrCodes EMSAgent_SetConfigData(
	configparam *pConfig
	)
{
	EMSAgentErrCodes retVal = EMSAGENT_SUCCESS;
	Sys_Char *function = "EMSAgent_SetConfigData";

	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s: entered!", function);
	
	if (pConfig == NULL) {
		retVal = EMSAGENT_WRONG_IP_PARAMS;
		SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: Wrong Input params!", function);
		goto failCall;
	}

	if (gConf != NULL) {
		SysMutex_Lock(pConfig->mutexHdl);
		SysMutex_Lock(gConf->mutexHdl);

		if (gConf->m_Asset.pId) {
			Sys_Free(gConf->m_Asset.pId);
			gConf->m_Asset.pId = NULL;
		}
		gConf->m_Asset.pId = Sys_StrDup(pConfig->m_Asset.pId);
		if (gConf->m_Asset.pId == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_Asset.pId - Insufficient Memory!", function);
			goto failCall;
		}

		//Added Sept_19
		// Asset Connection Config
		if (gConf->m_Asset.comType) {
			Sys_Free(gConf->m_Asset.comType);
			gConf->m_Asset.comType = NULL;
		}
		gConf->m_Asset.comType = Sys_StrDup(pConfig->m_Asset.comType);
		if (gConf->m_Asset.comType == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_Asset.comType - Insufficient Memory!", function);
			goto failCall;
		}

		if (gConf->m_Asset.comAddr) {
			Sys_Free(gConf->m_Asset.comAddr);
			gConf->m_Asset.comAddr = NULL;
		}
		gConf->m_Asset.comAddr = Sys_StrDup(pConfig->m_Asset.comAddr);
		if (gConf->m_Asset.comAddr == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_Asset.comAddr - Insufficient Memory!", function);
			goto failCall;
		}

		if (gConf->m_Asset.comPort) {
			Sys_Free(gConf->m_Asset.comPort);
			gConf->m_Asset.comPort = NULL;
		}
		gConf->m_Asset.comPort = Sys_StrDup(pConfig->m_Asset.comPort);
		if (gConf->m_Asset.comPort == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_Asset.comPort - Insufficient Memory!", function);
			goto failCall;
		}
		//End Sept_19

		// For App Utilization
		if (gConf->m_Asset.appName) {
			Sys_Free(gConf->m_Asset.appName);
			gConf->m_Asset.appName = NULL;
		}
		gConf->m_Asset.appName = Sys_StrDup(pConfig->m_Asset.appName);
		if (gConf->m_Asset.appName == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_Asset.appName - Insufficient Memory!", function);
			goto failCall;
		}

		// For Plum reference voltage
		gConf->m_Asset.refVolt = pConfig->m_Asset.refVolt;

		if (gConf->m_Asset.misc) {
			Sys_Free(gConf->m_Asset.misc);
			gConf->m_Asset.misc = NULL;
		}
		if (pConfig->m_Asset.misc) {
			gConf->m_Asset.misc = Sys_StrDup(pConfig->m_Asset.misc);
		//	if (gConf->m_Asset.misc == NULL) {
				// skip error since this is an option parameter
				/*retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
				SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_Asset.misc - Insufficient Memory!", function);
				goto failCall;*/
			//}
		}
		
		//SCM - 11/9/2017 Config Version changes-------------------------------
		if (gConf->m_ConfigVersion) {
			Sys_Free(gConf->m_ConfigVersion);
			gConf->m_ConfigVersion = NULL;
		}
		gConf->m_ConfigVersion = Sys_StrDup(pConfig->m_ConfigVersion);
		if (gConf->m_ConfigVersion == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_Config_Version - Insufficient Memory!", function);
			goto failCall;
		}
		//----------------------------------------------------------------------

		if (gConf->m_ThingName) {
			Sys_Free(gConf->m_ThingName);
			gConf->m_ThingName = NULL;
		}
		gConf->m_ThingName = Sys_StrDup(pConfig->m_ThingName);
		if (gConf->m_ThingName == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_ThingName - Insufficient Memory!", function);
			goto failCall;
		}

		if (gConf->m_HostName) {
			Sys_Free(gConf->m_HostName);
			gConf->m_HostName = NULL;
		}
		gConf->m_HostName = Sys_StrDup(pConfig->m_HostName);
		if (gConf->m_HostName == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_HostName - Insufficient Memory!", function);
			goto failCall;
		}

		if (gConf->m_AppKey) {
			Sys_Free(gConf->m_AppKey);
			gConf->m_AppKey = NULL;
		}
		gConf->m_AppKey = Sys_StrDup(pConfig->m_AppKey);
		if (gConf->m_AppKey == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_AppKey - Insufficient Memory!", function);
			goto failCall;
		}

		if (gConf->m_ProxyHostName) {
			Sys_Free(gConf->m_ProxyHostName);
			gConf->m_ProxyHostName = NULL;
		}
		gConf->m_ProxyHostName = Sys_StrDup(pConfig->m_ProxyHostName);
		if (gConf->m_ProxyHostName == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_ProxyHostName - Insufficient Memory!", function);
			goto failCall;
		}

		if (gConf->m_ProxyPort) {
			Sys_Free(gConf->m_ProxyPort);
			gConf->m_ProxyPort = NULL;
		}
		gConf->m_ProxyPort = Sys_StrDup(pConfig->m_ProxyPort);
		if (gConf->m_ProxyPort == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_ProxyPort - Insufficient Memory!", function);
			goto failCall;
		}

		if (gConf->m_Encryption) {
			Sys_Free(gConf->m_Encryption);
			gConf->m_Encryption = NULL;
		}
		gConf->m_Encryption = Sys_StrDup(pConfig->m_Encryption);
		if (gConf->m_Encryption == NULL) {
			retVal = EMSAGENT_ERROR_ALLOCATING_MEMORY;
			SysAppLog(SYS_ERROR, MODULE_EMS_CONFIG, "%s: gConf->m_Encryption - Insufficient Memory!", function);
			goto failCall;
		}

		gConf->Max_Message_Size = pConfig->Max_Message_Size; 
		gConf->m_Asset.Type = pConfig->m_Asset.Type;
		gConf->m_EmsStatus = pConfig->m_EmsStatus;
		gConf->m_Port = pConfig->m_Port;
		gConf->acquisition.unit = pConfig->acquisition.unit;
		gConf->acquisition.health = pConfig->acquisition.health;
		gConf->acquisition.environment = pConfig->acquisition.environment;
		gConf->acquisition.utilization = pConfig->acquisition.utilization;
		gConf->acquisition.information = pConfig->acquisition.information;
		//Posting rate is removed from the config.json
	/*	gConf->posting.unit = pConfig->posting.unit;
		gConf->posting.health = pConfig->posting.health;
		gConf->posting.environment = pConfig->posting.environment;
		gConf->posting.utilization = pConfig->posting.utilization;*/

		SysMutex_Unlock(gConf->mutexHdl);
		SysMutex_Unlock(pConfig->mutexHdl);
	}
	else {
		SysAppLog(SYS_ERROR, MODULE_EMS_AGENT, "%s: gConf not initiliazed!", function);
	}

	SysAppLog(SYS_DEBUG, MODULE_EMS_AGENT, "%s: exited.", function);

failCall:
	SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "%s:exited with failure!", function);

	return retVal;
}
