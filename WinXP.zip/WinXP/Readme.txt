Win XP based Keysight_EMS_Agent.exe and setup creation:-
==============================================================================

- Win Xp based separate projects have been created to create compatible exe and setups for Win XP due to following reasons.
  The existing Windows projects are SCPI enabled and use "GetTickCount64()" [Self_Monitor.cpp:319] function which is unavailable in kernal32.dll of WinXP.
  
- Visual Studio 2013 has been used to create XP based exe and setups.
- The corresponding solution (x86/x64) are available at WinXP folder at the root folder.


