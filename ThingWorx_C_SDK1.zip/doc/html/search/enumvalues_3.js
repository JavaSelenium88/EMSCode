var searchData=
[
  ['going_5fto_5fsleep',['GOING_TO_SLEEP',['../tw_websocket_8h.html#a16c0d744619c0e4c04084ca3e8ab89d9ad5521196a33187b88d9c8ac96c703ca9',1,'twWebsocket.h']]]
];
