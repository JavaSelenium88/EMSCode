var searchData=
[
  ['file_5fxfer_5fblock_5fsize',['FILE_XFER_BLOCK_SIZE',['../tw_default_settings_8h.html#a87b5f869512525019d44f764ff8ebb92',1,'twDefaultSettings.h']]],
  ['file_5fxfer_5fmax_5ffile_5fsize',['FILE_XFER_MAX_FILE_SIZE',['../tw_default_settings_8h.html#aa78aefcca3a6fecba047361bcb389d32',1,'twDefaultSettings.h']]],
  ['file_5fxfer_5fmd5_5fblock_5fsize',['FILE_XFER_MD5_BLOCK_SIZE',['../tw_default_settings_8h.html#ae4b35c3e8cd40e9f787af8010258c9d0',1,'twDefaultSettings.h']]],
  ['file_5fxfer_5fstaging_5fdir',['FILE_XFER_STAGING_DIR',['../tw_default_settings_8h.html#af1c4bf9bb94f5bbb77746c1dd7aa3784',1,'twDefaultSettings.h']]],
  ['file_5fxfer_5ftimeout',['FILE_XFER_TIMEOUT',['../tw_default_settings_8h.html#a6939a5d2f1135f8679349cfe79d92422',1,'twDefaultSettings.h']]],
  ['frame_5fread_5ftimeout',['FRAME_READ_TIMEOUT',['../tw_default_settings_8h.html#a3e11a43b737b2703a7e27c33cca98f1b',1,'twDefaultSettings.h']]]
];
