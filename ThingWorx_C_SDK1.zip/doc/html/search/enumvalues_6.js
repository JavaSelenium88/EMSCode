var searchData=
[
  ['policy_5fviolation',['POLICY_VIOLATION',['../tw_websocket_8h.html#a16c0d744619c0e4c04084ca3e8ab89d9afeb3c0311030d432878851bd63ec5102',1,'twWebsocket.h']]],
  ['protocol_5ferror',['PROTOCOL_ERROR',['../tw_websocket_8h.html#a16c0d744619c0e4c04084ca3e8ab89d9a8cb937247ec21f791706f4f426496a8c',1,'twWebsocket.h']]]
];
