var searchData=
[
  ['constants_20for_20propertydefinition',['Constants for PropertyDefinition',['../group___aspects.html',1,'']]]
];
