var searchData=
[
  ['connect_5fretries',['CONNECT_RETRIES',['../tw_default_settings_8h.html#a5edb2fdb88125c1c6adfd14ea1cde312',1,'twDefaultSettings.h']]],
  ['connect_5fretry_5finterval',['CONNECT_RETRY_INTERVAL',['../tw_default_settings_8h.html#ab2106828de539188aed925f592751c12',1,'twDefaultSettings.h']]],
  ['connect_5ftimeout',['CONNECT_TIMEOUT',['../tw_default_settings_8h.html#a252b2cb72531cb00ecd4d4db37a5a473',1,'twDefaultSettings.h']]]
];
