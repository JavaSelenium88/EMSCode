var searchData=
[
  ['dataavailable',['DataAvailable',['../class_dot_z_lib_1_1_codec_base.html#a985cf58f6ed5cfeeb9fd8c34a7c052d4',1,'DotZLib.CodecBase.DataAvailable()'],['../interface_dot_z_lib_1_1_codec.html#a54b5cd5685e1256fcb0cb6ead5c3e5b5',1,'DotZLib.Codec.DataAvailable()']]]
];
