var searchData=
[
  ['inflater',['Inflater',['../class_dot_z_lib_1_1_inflater.html#acb40e9664a78756a3def8ed66aa35ca1',1,'DotZLib::Inflater']]],
  ['info',['Info',['../class_dot_z_lib_1_1_info.html#a48b690fe56ca7cc8e8a40a740476696b',1,'DotZLib::Info']]],
  ['is_5fopen',['is_open',['../classgzfilebuf.html#a93ffc20f346d08dc295b799c92becffc',1,'gzfilebuf::is_open()'],['../classgzifstream.html#a8e9de13b311b698ef0ccc276b71c7941',1,'gzifstream::is_open()'],['../classgzofstream.html#acb1c9c6dccaf41bc5e44c2263ea48de3',1,'gzofstream::is_open()']]]
];
