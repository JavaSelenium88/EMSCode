var searchData=
[
  ['unexpected_5fcondition',['UNEXPECTED_CONDITION',['../tw_websocket_8h.html#a16c0d744619c0e4c04084ca3e8ab89d9a71a65559547a128c5dd07ec3acd6191a',1,'twWebsocket.h']]],
  ['unsupported_5fdata_5ftype',['UNSUPPORTED_DATA_TYPE',['../tw_websocket_8h.html#a16c0d744619c0e4c04084ca3e8ab89d9ada28ec60f25b2a24a61805e4796d10c9',1,'twWebsocket.h']]]
];
