var searchData=
[
  ['datashape_20macros',['DataShape Macros',['../group___data_shape.html',1,'']]],
  ['declaration_20macros_20for_20things_2c_20shapes_20and_20templates',['Declaration Macros for Things, Shapes and Templates',['../group___declaration_utilities.html',1,'']]]
];
