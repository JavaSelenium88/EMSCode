var searchData=
[
  ['msgcodeenum',['msgCodeEnum',['../tw_definitions_8h.html#ad3bcb663734c00d8b9e7f16801cfd0c0',1,'twDefinitions.h']]],
  ['msgtype',['msgType',['../tw_definitions_8h.html#a2f8f709ab25bdeef171ca2d415682e0b',1,'twDefinitions.h']]]
];
