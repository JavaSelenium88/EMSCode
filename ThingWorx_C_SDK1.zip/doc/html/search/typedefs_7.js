var searchData=
[
  ['service_5fcb',['service_cb',['../tw_api_8h.html#a649f10ba3121dadc7b3b5ecb17e68616',1,'twApi.h']]],
  ['synchronizeevent_5fcb',['synchronizeEvent_cb',['../tw_api_8h.html#a74c171698cf9315e439f8e1c84a70c5c',1,'twApi.h']]]
];
