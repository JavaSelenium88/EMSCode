var searchData=
[
  ['rdbuf',['rdbuf',['../classgzifstream.html#a9e5750d2c643025b2bd8725871585860',1,'gzifstream::rdbuf()'],['../classgzofstream.html#abe4562c3d07138dc31694580bf897c7c',1,'gzofstream::rdbuf()']]],
  ['read',['Read',['../class_dot_z_lib_1_1_g_zip_stream.html#a7f08839f681ed2eec9e3a87a0f1b0b0b',1,'DotZLib::GZipStream']]],
  ['readbyte',['ReadByte',['../class_dot_z_lib_1_1_g_zip_stream.html#aedb91212e360ab574bca4745e2189201',1,'DotZLib::GZipStream']]],
  ['reset',['Reset',['../class_dot_z_lib_1_1_checksum_generator_base.html#a78ec9de09223c6f9f81e4a32d8d00b70',1,'DotZLib.ChecksumGeneratorBase.Reset()'],['../interface_dot_z_lib_1_1_checksum_generator.html#ad01fdc9c4b4e5512dec8bc5072d97ffb',1,'DotZLib.ChecksumGenerator.Reset()']]],
  ['resetoutput',['resetOutput',['../class_dot_z_lib_1_1_codec_base.html#a801b625073b21aeaab52ebf9e96dd9c9',1,'DotZLib::CodecBase']]]
];
