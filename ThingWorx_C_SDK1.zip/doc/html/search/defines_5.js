var searchData=
[
  ['offline_5fmsg_5fqueue_5fsize',['OFFLINE_MSG_QUEUE_SIZE',['../tw_default_settings_8h.html#aeaf345c5dbd918e7cd1859b8e3fbddd4',1,'twDefaultSettings.h']]],
  ['offline_5fmsg_5fstore_5fdir',['OFFLINE_MSG_STORE_DIR',['../tw_default_settings_8h.html#a1d60c527031540b91f7cc3da75c8fcf9',1,'twDefaultSettings.h']]]
];
