var searchData=
[
  ['invalid_5fdata',['INVALID_DATA',['../tw_websocket_8h.html#a16c0d744619c0e4c04084ca3e8ab89d9a1cf2f29eaea742a6926f1efd4b9c16e8',1,'twWebsocket.h']]]
];
