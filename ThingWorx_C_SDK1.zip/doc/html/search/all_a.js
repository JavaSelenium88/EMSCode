var searchData=
[
  ['kbuffersize',['kBufferSize',['../class_dot_z_lib_1_1_codec_base.html#a6cf60968f7eaa921e5a8108e0ebcb880',1,'DotZLib::CodecBase']]],
  ['keypasswd',['keypasswd',['../structtw_tls_client.html#a7487206410ea66c8656c1c0baaf3f9a0',1,'twTlsClient']]]
];
