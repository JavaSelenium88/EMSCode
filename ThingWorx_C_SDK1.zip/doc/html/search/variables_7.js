var searchData=
[
  ['gatewayname',['gatewayName',['../structtw_ws.html#aab497631e806f64961a4cbf0d2109ea8',1,'twWs']]],
  ['gatewaytype',['gatewayType',['../structtw_ws.html#a1084cb93fa81f1b79f114ea1b665a335',1,'twWs']]]
];
