var searchData=
[
  ['value',['Value',['../class_dot_z_lib_1_1_checksum_generator_base.html#a06e5207da2126570dc70c6f7d43553e6',1,'DotZLib.ChecksumGeneratorBase.Value()'],['../interface_dot_z_lib_1_1_checksum_generator.html#a1e919ad45b3074b52deb14f3fc72cf20',1,'DotZLib.ChecksumGenerator.Value()']]],
  ['version',['Version',['../class_dot_z_lib_1_1_info.html#a0b74ff8a7c918ea7d8c76f5ddc834179',1,'DotZLib::Info']]]
];
