var searchData=
[
  ['characteristicenum',['characteristicEnum',['../tw_definitions_8h.html#a3e8812f07d4ec0ec35363fa3d9889e4e',1,'twDefinitions.h']]],
  ['close_5fstatus',['close_status',['../tw_websocket_8h.html#a16c0d744619c0e4c04084ca3e8ab89d9',1,'twWebsocket.h']]],
  ['compresslevel',['CompressLevel',['../namespace_dot_z_lib.html#a034f7a1ef9856d8834e6f6b1c53d8a4c',1,'DotZLib']]]
];
