var searchData=
[
  ['gzifstream',['gzifstream',['../classgzifstream.html#a90f6e0eea83b7ce3c64f755b51b5b011',1,'gzifstream::gzifstream(const char *name, std::ios_base::openmode mode=std::ios_base::in)'],['../classgzifstream.html#aa5ab9dcc3ab35bffe781f4c49239826e',1,'gzifstream::gzifstream(int fd, std::ios_base::openmode mode=std::ios_base::in)']]],
  ['gzipstream',['GZipStream',['../class_dot_z_lib_1_1_g_zip_stream.html#a12d73ef46491a5023b1fd620efb13f1a',1,'DotZLib.GZipStream.GZipStream(string fileName, CompressLevel level)'],['../class_dot_z_lib_1_1_g_zip_stream.html#aea152a18b8cab1ee3d614fc3799c7e08',1,'DotZLib.GZipStream.GZipStream(string fileName)']]],
  ['gzofstream',['gzofstream',['../classgzofstream.html#a4334d31aab99f8c9c2277b672a55c78f',1,'gzofstream::gzofstream(const char *name, std::ios_base::openmode mode=std::ios_base::out)'],['../classgzofstream.html#aa94d0c8414119a52f2a7f42aa0440941',1,'gzofstream::gzofstream(int fd, std::ios_base::openmode mode=std::ios_base::out)']]]
];
