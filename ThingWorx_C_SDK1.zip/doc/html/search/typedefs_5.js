var searchData=
[
  ['log_5ffunction',['log_function',['../tw_logger_8h.html#a65b004db98171d3ee691ee12ca362568',1,'twLogger.h']]]
];
