var searchData=
[
  ['quality',['quality',['../structtw_property.html#a30b1366b85f0f3e3c4fe618e9482432b',1,'twProperty']]]
];
