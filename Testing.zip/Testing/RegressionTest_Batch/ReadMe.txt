=============================================================================================================================
	This document will guide thorugh the essentials to be followed while running the LoadTest_EMS.bat file.
=============================================================================================================================

1. For running the LoadTest_EMS.bat file, Keysight_EMS_Agent folder should be present in the same folder as of the .bat file.
2. A data.csv file must be present in the same folder as of the .bat file.

NOTE: After exporting the data.csv file from the platform, DO NOT EDIT AND SAVE or DO NOT OPEN AND SAVE the data.csv file.

Following steps should be followed while using the .bat file-
	A. For installing and starting Multiple EMS Agents - Option: 1. Create Multiple EMS Folders.
																 2. Install Services.
																 3. Start Services.

	B. For updating the Config file(s) created inside the EMS Agents folder from data.csv file - Option: 7. Update Config.json from provided CSV file
																											(Should be used after the EMS Agent Folders are created).

	C. For stopping the EMS Agents - Option: 4. Stop Services.

	D. For removing EMS Agents - Option: 5. Uninstall Services.
										 6. Delete Multiple EMS Folders.

=============================================================================================================================
															THE END
=============================================================================================================================