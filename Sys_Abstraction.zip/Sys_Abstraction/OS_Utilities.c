
#ifdef WIN32
#include "SysWindows-openssl.h"
#else
#include "SysLinux-openssl.h"
#endif /*Contains macro for TW_MALLOC,TW_FREE*/

//#include "twApi.h"
#include "OS_Utilities.h"
#include "SysLog.h"
#include "Sysapi.h"

#ifdef WINCE
#include "time_ce.h"
#endif /**WINCE**/

//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************


//*****************************************************************************
// ReadFileContent
//  - input:  Filename of file to be read.
//  - return:  pointer to memory holding the content of the entire file.
// caller is responsible to free the memory returned by GetCWD****************/
// ****************************************************************************
Sys_Char *ReadFileContent(Sys_Char *fileName)
{
	Sys_Char *function = "ReadFileContent";
   Sys_Char *data = NULL;
   Sys_Long len = 0;
   FILE *fd = Sys_Fopen(fileName, "rb");

   SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

   if (!fd)
   {
	  SysAppLog(SYS_ERROR, MODULE_SYS_ABSTRACTION, "%s:Error opening the file: '%s'.",function,fileName);
      return data;
   }
   Sys_Fseek(fd, 0, SEEK_END);
   len = (Sys_Long)Sys_Ftell(fd);
   Sys_Fseek(fd, 0, SEEK_SET);
   data = (Sys_Char*) Sys_Malloc(len + 1);
   Sys_Fread(data, 1, len, fd);
   data[len] = '\0';
   Sys_Fclose(fd);
   SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
   return data;
}

//*****************************************************************************
//
// GetLocalTime()	
//					It returns the system's local time based on seconds.
//
//*****************************************************************************
SYS_BOOL SYS_GetLocalTime( struct tm* pLocal)
{
	Sys_Char *function = "SYS_GetLocalTime";
    time_t seconds = SYS_GetSecondsSince1970();
	
	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pLocal)
	{
		struct tm* ptm = localtime(&seconds);
		if(ptm)
		{
			*pLocal = *ptm;
			return SYS_TRUE;
		}
	}
	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
	return SYS_FALSE;
}

//*****************************************************************************
//
// SYS_GetSecondsSince1970()	
//	returns a time_t in Epoch time. 
//
//*****************************************************************************
time_t SYS_GetSecondsSince1970()
{   
	Sys_Char *function = "SYS_GetSecondsSince1970";
	SYS_DATETIME dateTime = SysGetSystemTime(1);

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
    return (time_t)(dateTime / 1000);
}

//*****************************************************************************
Sys_Int SYS_GetYear()
{
	Sys_Char *function = "SYS_GetYear";
	struct tm localTime;
	
	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

    SYS_GetLocalTime(&localTime);
	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
    return localTime.tm_year + 1900;
}

/*****************************************************************************
Return the absoulte path of a configuration file in the current working
directory.
input:  configuration file name.
return:  pointer to absolute file path.
*** The caller is responsible to free the memory of the returned pointer
*****************************************************************************/

Sys_Char* GetFilePathByName(Sys_Char* folderName, Sys_Char* fileName)
{
	Sys_Char *function = "GetFilePathByName";	
	Sys_Char* pszAbsoluteFilePath = (Sys_Char*)Sys_Malloc(PATH_MAX + 1);
	Sys_Char *pszCWD = GetCWD();

	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s: entered", function);

	
	strcpy(pszAbsoluteFilePath, pszCWD);
#ifndef WINCE
	strcat(pszAbsoluteFilePath, SYS_FILE_DELIM_STR);
#endif /**WINCE**/
	strcat(pszAbsoluteFilePath, folderName);
	strcat(pszAbsoluteFilePath, SYS_FILE_DELIM_STR);
	strcat(pszAbsoluteFilePath, fileName);
	Sys_Free(pszCWD);

	SysAppLog(SYS_DEBUG, MODULE_UTILITIES, " %s: exited", function);
	return pszAbsoluteFilePath;
}

/*****************************************************************************
Wraper around get_mtime System API
*****************************************************************************/
Sys_time_t SYS_Get_Mtime(const Sys_Char *path) {
	return get_mtime(path);
}


/*****************************************************************************
Return the last modified time of the file
input:  pointer to file path whose last modified time is needed.
return:  msec count since 1970.
*****************************************************************************/
Sys_time_t get_mtime(const char *path)
{
	struct stat statbuf;
	if (stat(path, &statbuf) == -1) {
		perror(path);
		return SYS_OK;
	}
	return statbuf.st_mtime;
}


//*****************************************************************************
//   *********************   Support  Functions   *****************************
//*****************************************************************************

