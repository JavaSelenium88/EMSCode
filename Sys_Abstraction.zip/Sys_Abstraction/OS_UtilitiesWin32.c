
//#include "twApi.h"
//#include "Utilities.h"
#include "OS_Utilities.h"
#include "Sysapi.h"
#include "SysLog.h"
#ifdef WINCE
 #include "winbase.h"
#endif /**WINCE**/
//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************


/*****************************************************************************
// GetCWD()
//  - returns Char* to the current working directory.
// caller is responsible to free the memory returned by GetCWD****************/
Sys_Char* GetCWD()
{
#ifdef WINCE
	TCHAR szEXEPath[MAX_PATH]= {NULL};
	Sys_Char actualpath[MAX_PATH];
	Sys_Char* pszCWD = NULL;
	Sys_Char *ExeName ="Keysight_EMS_Agent.exe";
	Sys_Int j,i , actualLen,folderLen;
	
	GetModuleFileName ( NULL, szEXEPath, 2048 );
	for(j=0; szEXEPath[j]!=0; j++)
	{
		actualpath[j]=szEXEPath[j];
	}
	actualpath[j] ='\0';
	actualLen = strlen(actualpath);
	folderLen= actualLen- strlen(ExeName);
	actualpath[folderLen] ='\0';
	pszCWD = (Sys_Char*) Sys_Malloc(strlen(actualpath) + 1);
	strcpy(pszCWD, actualpath);
	printf("GetCWD is *********** %s \n", pszCWD);
	return pszCWD;
#else /**WINCE**/
// Get current working directory, copy into allocated string.
    Sys_Char* pszCWD = NULL;
    Sys_Int len = MAX_PATH+1;
    Sys_Char szBuffer[MAX_PATH+1];
	
    memset(szBuffer, 0, len);
    GetCurrentDirectoryA(len, szBuffer);
    pszCWD = (Sys_Char*) Sys_Malloc(strlen(szBuffer) + 1);
    strcpy(pszCWD, szBuffer);
	return pszCWD;
#endif /**WINCE**/
}

//*****************************************************************************
// GetUUID()
//  - input/output Sys_Char* memory to hold the gernated GUID. 
// ****************************************************************************
void GetUUID(/* output */ Sys_Char* pszUUID)
{
	static Sys_Int ID = 1000;
    ID++;
    sprintf(pszUUID, "%i", ID);  // simple GUID OK for Windows testing.

}

//*****************************************************************************
// Wait for the shutdown signal on Windows
/*void	WaitForShutdownSignal() //ToDo-Soumya -Not in use
{
	// define delay variable for testing purposes
	Sys_Ulong delay = INFINITE;
	//WaitForShutdownEvent(delay); //Todo:Soumya Shutdown even can be called from thread or events

}*/

//*****************************************************************************
Sys_Ulong	SysExecuteProgram(Sys_Char* szFile, Sys_Int iWait)
{
    STARTUPINFOA si;
	PROCESS_INFORMATION pi;
	BOOL bOK;

	memset(&si,0,sizeof(si));
    memset(&pi,0,sizeof(pi));
    si.cb = sizeof(si);
    si.dwFlags = 0;
#ifdef WINCE
    bOK = CreateProcess(NULL, szFile, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
#else /**WINCE**/
    bOK = CreateProcessA(NULL, szFile, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
#endif /**WINCE**/
	if(bOK)
	{
		// wait for finish
		if(iWait)
			WaitForSingleObject(pi.hProcess, 5000);	// for now. more work is needed for wait time and hanging process
		return SYS_OK;
	}

	return GetLastError();
}

//*****************************************************************************
Sys_Char* ReadLineFromFile(Sys_Char* buffer, Sys_Int size, FILE* hFile)
{
	return fgets(buffer, size, hFile);
}

//*****************************************************************************
// Convert path delimiter (slash vs. back-slash).
Sys_Char* SysConvertPath(Sys_Char* pPath)
{
#ifndef WINCE
	// convert slash to back-slash and a drive letter
	Sys_Char	exeName[MAX_PATH];
	Sys_Int		i = 0;
	Sys_Int		iLen = strlen(pPath);

	Sys_Char*	pReturn = Sys_Malloc(iLen + 8);

	if(pReturn)
	{
		memset(pReturn, 0, iLen + 8);
		if(pPath[0] == '/' || pPath[0] == '\\')
		{
			// add drive letter
			if(GetModuleFileNameA(NULL, exeName, MAX_PATH) > 0)
				pReturn[0] = exeName[0];
			else
				pReturn[0] = 'C';
			pReturn[1] = ':';
		}
		strcat(pReturn, pPath);

		iLen = strlen(pReturn);
		for(i = 0; i < iLen; i ++)
		{
			if(pReturn[i] == '/')
				pReturn[i] = '\\';
		}
	}

	return pReturn;
#else /**WINCE**/
      // convert slash to back-slash and a drive letter
	TCHAR exeName[MAX_PATH]= {NULL};
    Sys_Int           i = 0, j=0;
    Sys_Int           iLen = strlen(pPath);
    
	Sys_Char *pReturn = Sys_Malloc(iLen + 8);

	if(pReturn)
	{
		memset(pReturn, 0, iLen + 8);
		if(pPath[0] == '/' || pPath[0] == '\\')
		{
			  // add drive letter
			if(GetModuleFileName(NULL, exeName, MAX_PATH) > 0)
			  {
				pReturn[0] =  '\\';;
				pReturn[1] =  '\\';;
			  }
			else
			{ //ToDo:Soumya WinCE- adding braces so as to avaoid adding ':' in the path
				pReturn[0] = 'C';
				pReturn[1] = ':';
			}
		}
      
	for(i =1 , j=2; pPath[i]!= '\0'; i++, j++)
	{
		  if (pPath[i] == '\\' && i !=0   )
		  {
				pReturn[j++] = '\\';
				//pReturn[j] = '\\';
		  }
		  else
		  {
				pReturn[j] = pPath[i];                               
		  }
	      
	}
            //strcat(pReturn, pPath);

    iLen = strlen(pReturn);
            
	/*for(i = 0, j=0; i < iLen; i++ ,j++)
	{ 
		  if(pReturn[i] == '/')
				pReturn[i] = '\\';
		  /*if(pReturn[i] == '\\')
		  {
				pReturn[j++] = '\\';
				pReturn[j] = '\\';
				}
	            
	}*/
	}
    return pReturn;

#endif /**WINCE**/
}

//*****************************************************************************
// pPath is File. delimiter has been converted per platform
SYS_BOOL SysCreateFolderForFile(Sys_Char* pFile)
{
	// strip off the file name
	SYS_BOOL b = FALSE;
	Sys_Int i;
	Sys_Char save;
	Sys_Int iLen = strlen(pFile);

	for(i = iLen - 1;  i > 0; i --)
	{
		if(pFile[i] == '\\')
		{
			save = pFile[i + 1];
			pFile[i + 1] = 0;	// keep the back slash
			b = SysCreateFolderRecursive(pFile);
			pFile[i + 1] = save;
			break;
		}
	}
	return b;
}

//*****************************************************************************
// pPath is folder. delimiter has been converted per platform
SYS_BOOL SysCreateFolderRecursive(Sys_Char* pPath)
{
    // directories have to be created one by one.
    // Caller should make sure that pPath ends with '\\'
	Sys_Int i;
	Sys_Int res = 0;
	SYS_BOOL b = FALSE;
	DWORD attr;
#ifdef WINCE
	LPCWSTR w_pPath = NULL;
	size_t w_pPathLen = 0;
#endif /**WINCE**/
	Sys_Int iLen = strlen(pPath);
	
	
	for(i = 0; i < iLen; i ++)
	{
		if(pPath[i] == '\\')
		{
			pPath[i] = 0;    
#ifdef WINCE
			w_pPathLen =  MultiByteToWideChar( CP_ACP , 0 , pPath, -1, NULL , 0 );
			w_pPath = (LPCWSTR)malloc(sizeof(LPCWSTR)* w_pPathLen);
			MultiByteToWideChar( CP_ACP,0, pPath, -1, w_pPath, w_pPathLen);
			b= CreateDirectory(w_pPath, NULL);  //CreateDirectory(pPath, NULL);
			//TW_FREE(w_pPath);
#else /**WINCE**/
			
			b = CreateDirectoryA(pPath, NULL);
			
#endif /**WINCE**/
			pPath[i] = '\\';
		}
	}
	
	if (b == FALSE && GetLastError() != ERROR_ALREADY_EXISTS)
	{
		res = GetLastError();
		printf("Last error is %d", res);
		return  0;
	}
#ifdef WINCE
    w_pPathLen =  MultiByteToWideChar( CP_ACP , 0 , pPath, -1, NULL , 0 );
	w_pPath = (LPCWSTR)malloc(sizeof(LPCWSTR)* w_pPathLen);
	MultiByteToWideChar( CP_ACP,0, pPath, -1, w_pPath, w_pPathLen);
	attr = GetFileAttributes(w_pPath);//attr = GetFileAttributes(pPath);
	//TW_FREE(w_pPath);
#else /**WINCE**/
	attr = GetFileAttributesA(pPath);
#endif /**WINCE**/

	return attr != (DWORD)-1;
}

//*****************************************************************************
SYS_BOOL SysDeleteFile(Sys_Char* pFile)
{
	Sys_Char *function = "SysDeleteFile";
	
#ifdef WINCE
	SYS_BOOL status = FALSE;
	LPCWSTR w_pFile =NULL;
	size_t w_pFileLen = 0;
#endif /**WINCE**/

#ifdef WINCE
   //return DeleteFile(pFile);
	w_pFileLen =  MultiByteToWideChar( CP_ACP , 0 , pFile, -1, NULL , 0 );
	w_pFile = (LPCWSTR)malloc(sizeof(LPCWSTR)* w_pFileLen);
	MultiByteToWideChar( CP_ACP,0, pFile, -1, w_pFile, w_pFileLen);
	
	if (DeleteFile(w_pFile) == FALSE) {
	status = FALSE;
	}
	else {
	status = TRUE;
	}
	SYS_FREE(w_pFile);
	return status;
	
#else /**WINCE**/
	return DeleteFileA(pFile);
#endif /**WINCE**/
}

//*****************************************************************************
SYS_BOOL SysRenameFile(Sys_Char* pSourceFile, Sys_Char* pTargetFile)
{
	Sys_Char *function = "SysRenameFile";
#ifdef WINCE
	SYS_BOOL status = FALSE;
	LPCWSTR w_pSourceFile = NULL ;
	size_t w_pSourceFileLen = 0;
	LPCWSTR w_pTargetFile = NULL ;
	size_t w_pTargetFileLen = 0;
#endif /**WINCE**/
    
#ifdef WINCE
    //return MoveFile(pSourceFile, pTargetFile);
	w_pSourceFileLen =  MultiByteToWideChar( CP_ACP , 0 , pSourceFile, -1, NULL , 0 );
	w_pSourceFile = (LPCWSTR)malloc(sizeof(LPCWSTR)* w_pSourceFileLen);
	MultiByteToWideChar( CP_ACP,0, pSourceFile, -1, w_pSourceFile, w_pSourceFileLen);
	w_pTargetFileLen =  MultiByteToWideChar( CP_ACP , 0 , pTargetFile, -1, NULL , 0 );
	w_pTargetFile = (LPCWSTR)malloc(sizeof(LPCWSTR)* w_pTargetFileLen);
	MultiByteToWideChar( CP_ACP,0, pTargetFile, -1, w_pTargetFile, w_pTargetFileLen);
	
	if (MoveFile(w_pSourceFile,w_pTargetFile) == FALSE) {
	status = FALSE;
	}
	else {
	status = TRUE;
	}
	SYS_FREE(w_pSourceFile);
	SYS_FREE(w_pTargetFile);
	return status;
	
#else /**WINCE**/
	return MoveFileA(pSourceFile, pTargetFile);
#endif /**WINCE**/
}


//*****************************************************************************
// convert ascii string to an long long
uint64_t AsciiToLongLong(Sys_Char* pszString)
{
	Sys_Char *function = "AsciiToLongLong";

	return _atoi64(pszString);
}

//*****************************************************************************
//   *********************   Support  Functions   *****************************
//*****************************************************************************

