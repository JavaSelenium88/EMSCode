//**************************************************************************
//
//  Copyright � 2016 ITC .  All rights reserved.
//
//**************************************************************************
//
//  Filename   :  SysThread.h
//  
//  Subsystem  :  KeySight
//
//  Author     :  Soumya Ranjan Bej
//
//  Description:  C style struct to manage threads
//
//
//**************************************************************************

#ifndef __SYS_THREAD_H__
#define __SYS_THREAD_H__

#include "SysEvent.h" //ToDo:Soumya Event related changes needs to be moved/reused?
#include "Sysapi.h"
#include "SysOSPort.h"
//
// Below are SysThread definitions
//
#ifdef WIN32
// Win32 Thread function prototype
typedef DWORD WINAPI SysThreadProc(void*);
#else
// Linux Thread function prototype
typedef void* SysThreadProc(void*);
#endif

// thread struct
typedef struct  SysThreadStruct
{
	Sys_Byte		m_bRunning;		// thread is running or not
	Sys_Byte		m_bSuspend;		// non zero for suspend mode
	void*			m_parameter1;	// 1st optional caller parameter to pass down to the thread function
	SYS_MUTEX		m_dataMutex;	// global data protection
	Sys_Ulong		m_waitMilliSec;	// execution frequency
#ifdef WIN32
	Sys_Ulong		m_threadId;		// the thread id
    HANDLE			m_threadHandle;	// the thread handle
#else
    pthread_t		m_threadId;		// the thread id
#endif
	SysEventStruct *m_pSysEventStruct;	// The Event
	void*			m_parameter2;	// 2nd optional caller parameter to pass down to the thread function
} SysThreadStruct, *pSysThreadStruct;


// thread functions
SysThreadStruct*	SysCreateThreadStruct();
void			SysDestroyThreadStruct(SysThreadStruct*);

// Starts the thread running
Sys_Int				SysStartThread(SysThreadStruct*, SysThreadProc pThreadFun);

// Signal the thread to wake up. 
void			SysSignalThread(SysThreadStruct* pSysThreadStructTemp);

// stops the thread. It returns after thread is exited
void			SysStopThread(SysThreadStruct*);	

// SysChangeThreadStatus() suspend or resume the thread
void	SysChangeThreadStatus(SysThreadStruct*, Sys_Byte uSuspend);

// this is called inside the Thread function to throttles the thread execution cycle. do not use sleep()
Sys_Ulong SysThreadWaitForRunCycle(SysThreadStruct*);

// calculate the delay for the acquisition loop.  The goal is to maintain a 
// constant/consistent aquisition loop timing w/o jitter.
//
// input: 
//   - calculatedDelay: can either be a calculated delay or the configured delay
//   - actualLoopTime: the time spent in the  last acquisition loop.
// return:  the delay for the next acquisition loop.
Sys_Ulong CalculateDelay(SysThreadStruct* pStruct, Sys_Ulong calculatedDelay, Sys_Ulong actualLoopTime);

#endif // __SYS_THREAD_H__
