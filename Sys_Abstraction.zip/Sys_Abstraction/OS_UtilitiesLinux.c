//*****************************************************************************
//
//  Copyright © ITC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  OS_UtilitiesLinux.c
//  
//  Subsystem  :  EMS_GetConnected
//
//  Description:  OS abstraction layer for various support (utility) functions.
//                Linux implementation
//
//*****************************************************************************

//#include "twApi.h"
#include "OS_Utilities.h"
#include <stdlib.h>

//
// signal handlers for unix.
//
#include "Sysapi.h"
#include "SysLog.h"
#include <string.h>
#include <sys/stat.h>
#include <signal.h>
#include <pthread.h>
#include <errno.h>
#include <linux/limits.h>
#include <unistd.h>
//#include <uuid/uuid.h>
#include <sys/wait.h>

//ToDo:Soumya - added temporarily to fix build issue. Move to global declare file
#define INFINITE            0xFFFFFFFF  // Infinite timeout


//*****************************************************************************
//   **********************   Global  Functions   *****************************
//*****************************************************************************


//*****************************************************************************
// GetCWD()
//  - returns char* to the current working directory.
// caller is responsible to free the memory returned by GetCWD
//*****************************************************************************

char* GetCWD()
{
     char szBuffer[PATH_MAX + 1] = "";
     //char *CWD = getcwd(szBuffer, PATH_MAX + 1);
     int lenCWD = Sys_StringLength(getcwd(szBuffer, PATH_MAX + 1));
     char* pszCWD=  (char*) SYS_MALLOC(lenCWD+1);
     strcpy(pszCWD, getcwd(szBuffer, PATH_MAX + 1));
     return pszCWD;
}


//*****************************************************************************
// GetUUID()
//  - input/output char* memory to hold the gernated GUID. 
// ****************************************************************************
void GetUUID(/* output */ char* pszUUID)
{
	/*uuid_t			uuid_out;
	unsigned char	val;
	unsigned char	nibble;
	int				i;

	// the returned uuid is 16 bytes
	uuid_generate(uuid_out);

    // convert one byte at a time into 2 nibbles of hex code.  Upper nibble then lower nibble.
	for(i = 0; i < 16; i ++)
    {
		val = uuid_out[i];

        nibble = (val >> 4) & 0xf;
        if(nibble < 10)
            nibble += '0';
        else
            nibble += ('a' - 10);
		pszUUID[i * 2] = nibble;

        nibble = val & 0xf;
        if(nibble < 10)
            nibble += '0';
        else
            nibble += ('a' - 10);
		pszUUID[i * 2 + 1] = nibble;*/
    }


/*void	WaitForShutdownSignal() //ToDo-Soumya -Not in use
{
	// wait for shutdown event
	WaitForShutdownEvent(INFINITE);
}*/

// Execute a bat file (Windows) or shell scripts (Linux)
unsigned long	SysExecuteProgram(char* szFile, int iWait)
{
	char*	argv[2];
    int		status;
	pid_t	childPid;

	argv[0] = szFile;
	argv[1] = NULL;

    childPid = fork();

	// error
    if (childPid < 0)
		return errno;

    // child process
    if (childPid == 0)
    {
        // execute script
        execvp(szFile, argv);
        _exit(errno);
    }

    // parent process, wait
    else
    {
		pid_t rc;
		int timeout = 5;	// wait 5 seconds max. configurable ?
		if(iWait == 0)
			return SYS_OK;
 
        while (timeout > 0)
        {
			timeout --;
            rc = waitpid(childPid, &status, WNOHANG);
			if(rc < 0)
				return errno;
            if (rc == childPid)
                return SYS_OK;
			sleep(1);
		}
		return -1;
    }
}

char* ReadLineFromFile(char* buffer, int size, FILE* hFile)
{
	return fgets(buffer, size, hFile);
}

// Convert path delimiter (slash vs. back-slash)
char* SysConvertPath(char* pPath)
{
	// convert back-slash to slash
	int		i = 0;
	int		iLen = strlen(pPath);
	char*	pReturn = SYS_MALLOC(iLen + 8);
	if(pReturn)
	{
		if((pPath[0] >= 'a' && pPath[0] <= 'z') || (pPath[0] >= 'A' && pPath[0] <= 'Z'))
		{
			if(pPath[1] == ':')
			{
				if(pPath[2] == '/' || pPath[2] == '\\')
					i = 2;
			}
		}
		strcpy(pReturn, pPath + i);

		iLen = strlen(pReturn);
		for(i = 0; i < iLen; i ++)
		{
			if(pReturn[i] == '\\')
				pReturn[i] = '/';
		}
	}

	return pReturn;
}

// pPath is File. delimiter has been converted per platform
SYS_BOOL SysCreateFolderForFile(char* pFile)
{
	// strip off the file name
   SYS_BOOL b = SYS_FALSE;
	int i;
	char save;
	int iLen = strlen(pFile);

	for(i = iLen - 1;  i > 0; i --)
	{
		if(pFile[i] == '/')
		{
			save = pFile[i + 1];
			pFile[i + 1] = 0;	// keep the slash
			b = SysCreateFolderRecursive(pFile);
			pFile[i + 1] = save;
			break;
		}
	}

	return b;
}

// pPath is folder. delimiter has been converted per platform
SYS_BOOL SysCreateFolderRecursive(char* pPath)
{
    // directories have to be created one by one.
    // Caller should make sure that pPath ends with '/'
    struct stat sbuf;
	int iLen = strlen(pPath);
	int i;
	for(i = 0; i < iLen; i ++)
	{
		if(pPath[i] == '/')
		{
			pPath[i] = 0;    
			mkdir(pPath, 0777);
			pPath[i] = '/';
		}
	}
	return (stat(pPath, &sbuf) == 0);
}

// pFile is file name
SYS_BOOL SysDeleteFile(char* pFile)
{
	return (unlink(pFile) == 0);
}

// pSourceFile is old file name. pTargetFile is new file name
SYS_BOOL SysRenameFile(char* pSourceFile, char* pTargetFile)
{
	return (rename(pSourceFile, pTargetFile) == 0);
}

//*****************************************************************************
// convert ascii string to an long long
uint64_t AsciiToLongLong(char* pszString)
{
	return atoll(pszString);
}

//*****************************************************************************
//   *********************   Support  Functions   *****************************
//*****************************************************************************

