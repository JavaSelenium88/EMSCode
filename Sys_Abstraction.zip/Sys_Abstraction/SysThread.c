
//#include "twApi.h"
#include "SysOSPort.h"
#include "SysThread.h"
#include "Sysapi.h"
#include "SysLog.h"
//
// suspend or resume the thread: uSuspend == 0 means resume. uSuspend == 1 means suspend
//
void	SysChangeThreadStatus(SysThreadStruct* pSysThreadStructTemp, Sys_Byte uSuspend)
{

	//SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);
	if(pSysThreadStructTemp)
	{
		pSysThreadStructTemp->m_bSuspend = uSuspend;

		// wake up the thread in both cases. 
		// The thread will run its cycle once upon wake up, then go to sleep or go alive accordingly
		SysSignalThread(pSysThreadStructTemp);
	}
	//SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
}

//*****************************************************************************
// wait for the next execution cycle.
Sys_Ulong SysThreadWaitForRunCycle(SysThreadStruct* pSysThreadStructTemp)
{
	Sys_Ulong i = WAIT_FAILED;

	//SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);
    if(!pSysThreadStructTemp)
        return i;
SuspendThread:
	i = (Sys_Ulong)SysWaitForEvent(pSysThreadStructTemp->m_pSysEventStruct, pSysThreadStructTemp->m_waitMilliSec);
    if (pSysThreadStructTemp->m_bSuspend)
    {
        // centralize suspension of all threads.
        pSysThreadStructTemp->m_waitMilliSec = INFINITE;
        goto SuspendThread;
    }

	//SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
	return i;
}

//*****************************************************************************
// calculate the delay for the acquisition loop.  The goal is to maintain a 
// constant/consistent aquisition loop timing w/o jitter.
//
// input: 
//   - calculatedDelay: can either be a calculated delay or the configured delay
//   - actualLoopTime: the time spent in the  last acquisition loop.
// return:  the delay for the next acquisition loop.
//           
Sys_Ulong CalculateDelay(SysThreadStruct* pStruct, Sys_Ulong calculatedDelay, Sys_Ulong actualLoopTime)
{
	Sys_Ulong delay;
    // The last acquisition loop took 'loopTime' milliseconds.
    // Adjust the next delay by the time it took to loop.
    // This keeps a consistent data rate.


	if(pStruct->m_bSuspend != 0)
		delay = INFINITE;
	else if(calculatedDelay == INFINITE)
		delay = INFINITE;
    else if (actualLoopTime > calculatedDelay)
        delay = 0;
    else
        delay = calculatedDelay - actualLoopTime;


    return delay;
}


