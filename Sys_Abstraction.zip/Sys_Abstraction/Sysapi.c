
#include <ctype.h>
#include <string.h>
#include <stdarg.h>
#include <stdio.h>
#include <time.h>
#ifdef WIN32
#else  /**Linux**/
#include <errno.h>  //Added as part of the warning fix
#include <sys/statvfs.h> //Added to get the free disk space in linux
#endif  /**WIN32**/

#include "SysLog.h"
#include "Systypes.h"
#include "Sysapi.h"


#ifndef WINCE
#ifdef WIN32 /* Windows */
#include "sys/timeb.h"

#else /* Linux */
#include <sys/timeb.h>
#include <stdint.h>

//typedef uint64_t SYS_DATETIME;
#endif

#else /* WINCE */
#include "timeb_ce.h"
#include "stat_ce.h"
#include "time_ce.h"
#endif

//static Sys_Char *STR_DELIM_COLON = ":";
//static Sys_Char *STR_DELIM_HYPEN = "-";
//static Sys_Char *STR_NULL = "\0";
//static Sys_Char *STR_WHT_SPC = " ";

Sys_Ret_t Sys_StringCpy //TODO: Vishal: It's crashing, if source and dest length are same. Ideally it should truncate a char and put \0. Test it.
	(
	Sys_Char * Dest,
	const Sys_Char * Src,
	Sys_Size_t DestSize
	)
{
	return Sys_StringnCpy(Dest, Src, DestSize, DestSize);
}

Sys_Ret_t Sys_StringnCpy
	(
	Sys_Char * Dest,
	const Sys_Char * Src,
	Sys_Size_t NumChars,
	Sys_Size_t DestSize
	)
{
	if (DestSize > 0)
	{
		Dest[DestSize-1] = 0;
#ifdef WIN32
		strncpy_s(Dest, DestSize, Src, SYS_MIN(NumChars, DestSize));
#else
		strncpy(Dest, Src, DestSize); //ToDO-Soumya -test this code
#endif   /**WIN32**/
		if (Dest[DestSize-1] == 0)
		{
			return SYS_RET_OK;
		}

		Dest[DestSize-1] = 0;
	}

	return SYS_EINVAL;
}

Sys_Int Sys_StringCaseCmp(const Sys_Char* Str1, const Sys_Char* Str2)
{
	while (toupper(*Str1) == toupper(*Str2) && *Str2 != 0)
	{
		Str1++; Str2++;
	}

	return *Str1 - *Str2;
}

Sys_Int Sys_StringnCaseCmp(const Sys_Char* Str1, const Sys_Char* Str2,
	Sys_Int Count)
{
	while (Count > 0 && toupper(*Str1) == toupper(*Str2) && *Str2 != 0)
	{
		Str1++; Str2++; Count--;
	}

	return *Str1 - *Str2;
}

Sys_Ret_t Sys_StringCat(Sys_Char * Dest, const Sys_Char * Src, Sys_Size_t Size)
{
	Sys_Size_t Length = strlen(Dest);
	//Size -= SYS_MIN(Length, Size); //TODO: Vishal: Check why was this required???

	return Sys_StringCpy(&Dest[Length], Src, Size);
}

//Sys_Ret_t Sys_StringDup(Sys_Char *pszDest, Sys_Char *pszSource)
//{
//    pszDest = NULL;
//	
//    if (pszSource != NULL)
//    {
//		pszDest = (char*) Sys_Malloc(Sys_StringLength(pszSource) + 1);
//        Sys_StringCpy(pszDest, pszSource, Sys_StringLength(pszDest));
//    }
//
//    return SYS_RET_OK;
//}

//Example to Call the function :Sys_GetTimeStamp(Sys_Char *SYS_TIME)

/*Sys_Char *pTmpArr = (Sys_Char *)Sys_Calloc(21, 1);

	Sys_StringnCpy(pTmpArr, "yyyy-mm-dd hh-mm-ss  ", 20, 21);
	Sys_GetTimeStamp(pTmpArr);
	SysAppLog(SYS_ERROR, MODULE_KEYSIGHT_EMS_AGENT, "%s: SysTime- %s", function, pTmpArr);*/


/** Function to return timestamp in  < yyyy-mm-dd hh-mm-ss > format
*  SYS_TIME lenght should be equal to or greater than TIMESTAMP_LENGTH */
Sys_Ret_t  Sys_GetTimeStamp(Sys_Char * s, const Sys_Char * format, Sys_Int length, Sys_Char msec, Sys_Char utc) {
	SysLogErrCodes retVal = SYSLOG_SUCCESS;
#ifndef WINCE
#ifdef WIN32 /* Windows */
	SYS_DATETIME time;
	struct _timeb timebuffer;
	_ftime_s( &timebuffer ); /* C4996 */
	time = (SYS_DATETIME)(timebuffer.time * 1000 + timebuffer.millitm);

	struct tm timeinfo;
	time_t seconds;
	uint32_t mseconds;
	char millisec[8];
	TIME_ZONE_INFORMATION tz;
	mseconds = time % 1000;
	seconds = time / 1000;
	/* Convert this to a tm struct */
	if (utc)
		_localtime64_s(&timeinfo, &seconds);
	else {
		_gmtime64_s(&timeinfo, &seconds);
		GetTimeZoneInformation(&tz);
		if (tz.DaylightBias == -60) {
			timeinfo.tm_isdst = 0;
		}
		else timeinfo.tm_isdst = 1;
	}
	if (msec) {
		strftime(s, length - 4, format, &timeinfo);
		/* append the milliseconds */
		memset(millisec, 0, 8);
		_itoa_s(mseconds, millisec, 4, 10);
		strcat_s(s, length, ",");
		strcat_s(s, length, millisec);
	}
	else strftime(s, length, format, &timeinfo);

#else /* Linux */
	SYS_DATETIME time;
	struct timeb timebuffer;
	ftime(&timebuffer);
	time = ((SYS_DATETIME)timebuffer.time * 1000 + timebuffer.millitm);

	struct tm timeinfo;
	time_t seconds;
	uint32_t mseconds;
	char millisec[8];
	mseconds = time % 1000;
	seconds = time / 1000;
	/* Convert this to a tm struct */
	if (utc) {
		localtime_r(&seconds, &timeinfo);
	}
	else {
		gmtime_r(&seconds, &timeinfo);
	}
	if (msec) {
		strftime(s, length - 4, format, &timeinfo);
		/* append the milliseconds */
		memset(millisec, 0, 8);
		sprintf(millisec, "%u", mseconds);
		if (strlen(s) < length - 9) {
			strncat(s, ",", 1);
			strncat(s, millisec, 8);
		}
	}
	else strftime(s, length, format, &timeinfo);
#endif

#else /* WINCE */
	SYS_DATETIME time;
	struct _timeb timebuffer;
	struct tm *timeinfo;
	time_t seconds;
	uint32_t mseconds;
	char millisec[8];
	TIME_ZONE_INFORMATION tz;

	_ftime(&timebuffer); /* C4996 */
	time = (SYS_DATETIME)(timebuffer.time * 1000 + timebuffer.millitm);
	mseconds = time % 1000;
	seconds = time / 1000;
	/* Convert this to a tm struct */
	if (utc)
		timeinfo = localtime(&seconds);
	else {
		timeinfo = gmtime(&seconds);
		GetTimeZoneInformation(&tz);
		if (tz.DaylightBias == -60) {
			timeinfo->tm_isdst = 0;
		}
		else timeinfo->tm_isdst = 1;
	}
	if (msec) {
		strftime(s, length - 4, format, timeinfo);
		/* append the milliseconds */
		memset(millisec, 0, 8);
		_itoa_s(mseconds, millisec, 4, 10);
		strcat_s(s, length, ",");
		strcat_s(s, length, millisec);
	}
	else strftime(s, length, format, timeinfo);
#endif

	return retVal;
}


/** Function to return timestamp in  < yyyy-mm-dd hh-mm-ss > format
*  SYS_TIME leght should be equal to or more than TIMESTMAMP_LENGTH */
//Sys_Ret_t  Sys_GetTimeStamp(Sys_Char *SYS_TIME)
//{
//	time_t tTime = time(NULL);
//	Sys_Char *pGetTime = NULL;
//	Sys_Char *pTemp = NULL;
//	Sys_Char *pmonth = NULL;
//	Sys_Char *pdate = NULL;
//	Sys_Char *phh_hm_ss = NULL;
//	Sys_Char *pyear = NULL;
//	Sys_Int index = 0;
//
//	Sys_Int len = Sys_StringLength(SYS_TIME);
//
//	if (len < (TIMESTMAMP_LENGTH - 1))
//	{
//		return SYS_EINVAL;
//	}
//
//	pGetTime = asctime(localtime(&tTime));
//
//	pTemp = Sys_StrDup(pGetTime);
//
//	strtok(pTemp, STR_WHT_SPC);
//	pmonth = Sys_StringTok(NULL, STR_WHT_SPC);
//	pdate = Sys_StringTok(NULL, STR_WHT_SPC);
//	phh_hm_ss = Sys_StringTok(NULL, STR_WHT_SPC);
//	pyear = Sys_StringTok(NULL, STR_WHT_SPC);
//	pyear[strlen(pyear) - 1] = *STR_NULL;
//
//	if (!(Sys_StringCmp(pmonth, "Jan"))){ pmonth = "01"; }
//	else if (!(Sys_StringCmp(pmonth, "Feb"))){ pmonth = "02"; }
//	else if (!(Sys_StringCmp(pmonth, "Mar"))){ pmonth = "03"; }
//	else if (!(Sys_StringCmp(pmonth, "Apr"))){ pmonth = "04"; }
//	else if (!(Sys_StringCmp(pmonth, "May"))){ pmonth = "05"; }
//	else if (!(Sys_StringCmp(pmonth, "Jun"))){ pmonth = "06"; }
//	else if (!(Sys_StringCmp(pmonth, "Jul"))){ pmonth = "07"; }
//	else if (!(Sys_StringCmp(pmonth, "Aug"))){ pmonth = "08"; }
//	else if (!(Sys_StringCmp(pmonth, "Sep"))){ pmonth = "09"; }
//	else if (!(Sys_StringCmp(pmonth, "Oct"))){ pmonth = "10"; }
//	else if (!(Sys_StringCmp(pmonth, "Nov"))){ pmonth = "11"; }
//	else if (!(Sys_StringCmp(pmonth, "Dec"))){ pmonth = "12"; }
//	else pmonth = "NA";
//
//	/* Runs till the end of string */
//	while (phh_hm_ss[index] != *STR_NULL) {
//		/* If an occurrence of character is found */
//		if (phh_hm_ss[index] == *STR_DELIM_COLON) {
//			phh_hm_ss[index] = *STR_DELIM_HYPEN;
//		}
//		index++;
//	}
//	
//	Sys_StringCpy(SYS_TIME, pyear, len);
//	len -= Sys_StringLength(pyear);
//
//	Sys_StringCat(SYS_TIME, STR_DELIM_HYPEN, len);
//	len -= 1;
//
//	Sys_StringCat(SYS_TIME, pmonth, len);
//	len -= Sys_StringLength(pmonth);
//
//	Sys_StringCat(SYS_TIME, STR_DELIM_HYPEN, len);
//	len -= 1;
//
//	Sys_StringCat(SYS_TIME, pdate, len);
//	len -= Sys_StringLength(pdate);
//
//	Sys_StringCat(SYS_TIME, STR_WHT_SPC, len);
//	len -= 1;
//
//	Sys_StringCat(SYS_TIME, phh_hm_ss, len);
//
//
//	if (pTemp) {
//		Sys_Free(pTemp);
//		pTemp = NULL;
//	}
//
//	return SYS_RET_OK;
//}

/** Function to return free disk space
 */

Sys_Ret_t Sys_GetFreeDiskSpace(Sys_Char * diskPath, Sys_Ullong *freeSpace)
{

#ifndef WINCE
#ifdef WIN32
	GetDiskFreeSpaceEx(NULL, (PULARGE_INTEGER)freeSpace, NULL, NULL);

#else  /**Linux**/

	//commented by richa to supress the warnings
	Sys_Ullong blksize = 0;
	//Sys_Ullong blocks = 0;
	Sys_Ullong freeblks = 0;
	//Sys_Ullong disk_size = 0;
	//Sys_Ullong used = 0;
	char cwd[1024];

	struct statvfs buf;
	if (getcwd(cwd, sizeof(cwd)) != NULL)
		SysAppLog(SYS_DEBUG, MODULE_EMS_CONFIG, "Current working dir: %s\n", cwd);
	if (!statvfs(cwd, &buf)) {
		blksize = buf.f_bsize;
		//blocks = buf.f_blocks;
		freeblks = buf.f_bfree;

		//disk_size = blocks*blksize;
		*freeSpace = freeblks*blksize;
	}
#endif /**WIN32**/

#else /**WINCE**/    
	/*
	* To extract root folder for Log directory and convert to multibyte for use in WinCE platform
	*This feature should work for all WinCE platform but still need to check
	**/
	size_t w_filePathLength = 0;
	LPCWSTR w_filePathName = NULL;
	w_filePathLength = MultiByteToWideChar(CP_ACP, 0, diskPath, -1, NULL, 0);
	w_filePathName = (LPCWSTR)malloc(sizeof(LPCWSTR)* w_filePathLength);

	MultiByteToWideChar(CP_ACP, 0, diskPath, -1, w_filePathName, w_filePathLength);

	GetDiskFreeSpaceEx(w_filePathName, (PULARGE_INTEGER)freeSpace, NULL, NULL);
	Sys_Free(w_filePathName);   //Tobe check
#endif /**WINCE**/

	if (*freeSpace)
		return  SYS_RET_OK;
	else
		return SYS_ENOTAVAIL;


}




