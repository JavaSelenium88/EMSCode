
#include "SysOSPort.h"
#include "SysThread.h"
#include "Systypes.h"
#include "SysLog.h"


//*****************************************************************************
// creates the event struct
SysEventStruct* SysCreateEventStruct()
{
	Sys_Char *function = "SysCreateEventStruct";
	SysEventStruct* pSysEventStruct = (SysEventStruct*) Sys_Malloc(sizeof(SysEventStruct));
	
	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pSysEventStruct)
	{
		pSysEventStruct->m_waitEvent	= CreateEvent(0, FALSE, FALSE, NULL); 
		if(pSysEventStruct->m_waitEvent)
			return pSysEventStruct;
	}

	SysDestroyEventStruct(pSysEventStruct);

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
	return 0;
}

//*****************************************************************************
// destroys the event struct
void SysDestroyEventStruct(SysEventStruct* pSysEventStruct)
{
	Sys_Char *function = "SysDestroyEventStruct";
	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pSysEventStruct)
	{
		if(pSysEventStruct->m_waitEvent)
			CloseHandle(pSysEventStruct->m_waitEvent);

		Sys_Free(pSysEventStruct);
	}
	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
}

//*****************************************************************************
// wait for the Event.
Sys_Ulong SysWaitForEvent(SysEventStruct* pSysEventStruct, Sys_Ulong milliSeconds)
{
	Sys_Ulong i = WAIT_FAILED;
    Sys_Char *function = "SysWaitForEvent";

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);
	
	if(pSysEventStruct)
		i = WaitForSingleObject(pSysEventStruct->m_waitEvent, milliSeconds);

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
	return i;
}

void	SysSignalEvent(SysEventStruct* pSysEventStruct)
{
	Sys_Char *function = "SysSignalEvent";
	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pSysEventStruct)
		SetEvent(pSysEventStruct->m_waitEvent);

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
}


//*****************************************************************************
// creates the thread struct
SysThreadStruct* SysCreateThreadStruct()
{
	Sys_Char *function = "SysCreateThreadStruct";
	SysThreadStruct* pSysThreadStructTemp = (SysThreadStruct*) Sys_Malloc(sizeof(SysThreadStruct));

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pSysThreadStructTemp)
	{
		pSysThreadStructTemp->m_bRunning		= 0;
		pSysThreadStructTemp->m_bSuspend		= 0;
		pSysThreadStructTemp->m_parameter1	= 0;
		pSysThreadStructTemp->m_parameter2 = 0;
		pSysThreadStructTemp->m_dataMutex = SysMutex_Create();
		pSysThreadStructTemp->m_waitMilliSec	= 500;	// caller can override this value
		pSysThreadStructTemp->m_threadId		= 0;
		pSysThreadStructTemp->m_threadHandle	= 0;
		pSysThreadStructTemp->m_pSysEventStruct = SysCreateEventStruct();
		if(pSysThreadStructTemp->m_dataMutex && pSysThreadStructTemp->m_pSysEventStruct){
		   SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
		   return pSysThreadStructTemp;
		}
	}

	SysDestroyThreadStruct(pSysThreadStructTemp);

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited with failure !!", function);
	return 0;
}

//*****************************************************************************
// destroys the thread struct
void SysDestroyThreadStruct(SysThreadStruct* pSysThreadStructTemp)
{
	Sys_Char *function = "SysDestroyThreadStruct";

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pSysThreadStructTemp)
	{
		if (pSysThreadStructTemp->m_threadHandle)
			CloseHandle(pSysThreadStructTemp->m_threadHandle);
		if(pSysThreadStructTemp->m_dataMutex)
			SysMutex_Delete(pSysThreadStructTemp->m_dataMutex);
		if(pSysThreadStructTemp->m_pSysEventStruct)
			SysDestroyEventStruct(pSysThreadStructTemp->m_pSysEventStruct);

		Sys_Free(pSysThreadStructTemp);
	}

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
}

//*****************************************************************************
// start the thread running
Sys_Int SysStartThread(SysThreadStruct* pSysThreadStructTemp, SysThreadProc pFunction)
{
	Sys_Int i = 0;
	Sys_Char *function = "SysStartThread";

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pSysThreadStructTemp)
	{
		pSysThreadStructTemp->m_bRunning = 1;
		pSysThreadStructTemp->m_threadHandle = CreateThread(0, 0, pFunction, pSysThreadStructTemp, 0, &pSysThreadStructTemp->m_threadId);
		i = (Sys_Int)pSysThreadStructTemp->m_threadHandle;
	}

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);

	return i;
}

//*****************************************************************************
// Signal the thread to wake up. 
void SysSignalThread(SysThreadStruct* pSysThreadStructTemp)
{
	Sys_Char *function = "SysSignalThread";
	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pSysThreadStructTemp)
	{
		// set event
		SetEvent(pSysThreadStructTemp->m_pSysEventStruct->m_waitEvent);
	}

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
}

//*****************************************************************************
// stop the running thread
void SysStopThread(SysThreadStruct* pSysThreadStructTemp)
{
	Sys_Char *function = "SysStopThread";

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pSysThreadStructTemp)
	{
		// stop
		pSysThreadStructTemp->m_bRunning = 0;

		// set event
		SetEvent(pSysThreadStructTemp->m_pSysEventStruct->m_waitEvent);

		// wait for exit
		if (pSysThreadStructTemp->m_threadHandle)
			WaitForSingleObject(pSysThreadStructTemp->m_threadHandle, INFINITE);
		//pSysThreadStructTemp->m_threadHandle = 0; //Freed at a later stage.
	}

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
}



