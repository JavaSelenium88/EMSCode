
#ifndef __SYSLOG_H__
#define __SYSLOG_H__

#include "SysList.h"
#include "Sysapi.h"
#include "SysOSPort.h"
// currently, we support these module names:
#define MODULE_TW_SDK				"TW_SDK"
#define MODULE_EMS_CONFIG			"EMSConfig"
#define MODULE_EMS_AGENT			"EMSAgent"
#define MODULE_SYS_ABSTRACTION		"SysAbstraction"
#define MODULE_NATIVE_AGENT			"NativeAgent"
#define MODULE_KEYSIGHT_EMS_AGENT	"KeysightEMSAgent"
#define MODULE_UTILITIES			"Utilities"

//Use these two macros only for KeysightEMS_Helper 
#define MODULE_SOCKET		"HelperSocket"
#define MODULE_KEYHOOKS		"HelperKeyhooks"
#define HELPER_FILE_SIZE	0x32dcd2  //(Individual file size:3256 KB, total file size:19536 KB)

#define SYS_LOGGER_BUF_SIZE 0x4000   /* 16KB */
#define SYS_LOG_FILE_SIZE_PERCENT 5
#define MAX_LOG_FILE_NUMBER 5

static  Sys_Char *STR_LOG_FILE_NAME = "Keysightlogs.log";
static  Sys_Char *LOGGER_FOLDER_NAME = "Logs";

typedef enum SysLog_Error_Codes_T {
	SYSLOG_SUCCESS = 0, /**< No error */
	SYSLOG_ERROR_ALLOCATING_MEMORY = -1, /**< Memory allocation failed */
	SYSLOG_WRONG_IP_PARAMS = -2, /**< Wrong input/invalid parameters passed */
	SYSLOG_SYSTEM_ERROR = -3, /**< Some issue with system/platform */
	SYSLOG_TWX_ERROR = -4 /**< Thingworx api/c-sdk related errors */
	
}SysLogErrCodes;

// SysLogLevel is enum. Exactly same as ThingWorx for now
enum SysLogLevel 
{
	SYS_TRACE,  /**< Application execution tracing. **/
	SYS_DEBUG,	/**< Debug messages for development. **/
	SYS_INFO,	/**< General information messages. **/
	SYS_WARN,	/**< Warning messages. **/
	SYS_ERROR,	/**< Error messages. **/
	SYS_FORCE,	/**< TBD **/
	SYS_AUDIT	/**< TBD **/
};

// Logging target is bit or-ed
#define LOG_TARGET_CONSOLE				0x01				// to console
#define LOG_TARGET_FILE					0x02				// to file
#define LOG_TARGET_SYSLOG				0x04				// to syslog

// A global struct to hold global options
typedef struct SysLogOptions
{
	Sys_Int			m_gLevel;									// global logging level
	Sys_Int 		m_Target;									// target: file, console, etc.
	Sys_Char*		m_TargetFile;								// file name
	Sys_Ullong		m_MaxFileSize;								// max size file can grow
	Sys_Int			m_MaxFileNumber;							// max number of files
	SYS_MUTEX	    m_LoggingMutex;								// the mutex for logging
	SysList*			m_ModuleList;								// list of modules -> moduleOptions
}SysLogOptions;

// A moldule struct to hold per module options
#define SYS_LOGGING_MODULE_SIZE			64
typedef struct moduleOptions
{
	Sys_Int 		m_mLevel;									// Logging level.
	Sys_Char		m_ModuleName[SYS_LOGGING_MODULE_SIZE];		// module name
} moduleOptions;

// Initialize and destroy the logging
SysLogErrCodes			SysLog_Init(Sys_Char *pszLoggerFilePath);	// return TW_OK or errors
SysLogErrCodes			SysLog_Uninit();

// Override ThingsWorx log function (with the same signature)
void SysTwLog(enum SysLogLevel level, const Sys_Char * timestamp, const Sys_Char * message);

// Sys log function (with more options: moduleID - log source, target - to file, console, etc.)
SysLogErrCodes SysAppLog(enum SysLogLevel level, Sys_Char* module, const Sys_Char * format, ...);

#endif // __SYSLOG_H__
