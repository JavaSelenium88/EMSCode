
#ifndef WINCE
#ifdef WIN32
#include <stdint.h> //Todo:Soumya Added for "size_t" usage in cJSON.c/.h
#else
#include <stdlib.h>
#endif /**WIN32**/
#else /**WINCE**/
#include <stdint_ce.h>
#endif  /**WINCE**/

//#include "cJSON.h"
//#include "stringUtils.h"
#include "Systypes.h"
#include "Sysapi.h"
#include "SysLog.h"
#include "OS_Utilities.h"
#include "SysOSPort.h"


#ifndef WIN32
#include <stdarg.h>
#endif

/*Register file params */
//ToDo:Soumya - general string defines
static Sys_Char* STR_MODULE_SDK = MODULE_TW_SDK;
static Sys_Char* STR_MODULE_EMS_CONFIG = MODULE_EMS_CONFIG;
static Sys_Char* STR_MODULE_EMS_AGENT = MODULE_EMS_AGENT;
static Sys_Char* STR_MODULE_NATIVE_AGENT = MODULE_NATIVE_AGENT;
static Sys_Char* STR_MODULE_KEYSIGHT_EMS_AGENT = MODULE_KEYSIGHT_EMS_AGENT;
static Sys_Char *STR_MODULE_SYS_ABSTRACTION = MODULE_SYS_ABSTRACTION;
static Sys_Char *STR_MODULE_UTILITIES = MODULE_UTILITIES;
#ifdef KEYHOOK_PROC
static Sys_Char *STR_MODULE_SOCKET = MODULE_SOCKET;
static Sys_Char *STR_MODULE_KEYHOOKS = MODULE_KEYHOOKS;
#endif //KEYHOOK_PROC
// The only one logging option struct
static SysLogOptions* g_pSysLogOptions = NULL;
static SYS_BOOL g_bLogInitialzied = SYS_FALSE;

// work horse function for logging
//static void DoLogging(Sys_Int level, Sys_Char* module, const Sys_Char* timestamp, const Sys_Char* message);
static SysLogErrCodes DoLogging(Sys_Int level, Sys_Char* module, const Sys_Char* timestamp, const Sys_Char* message);

// helpers
static Sys_Int				InitializeModuleOptions();
static moduleOptions*	LookupModule(Sys_Char* module);
static void				OutputMessage(Sys_Int target, Sys_File_Handle hFile, const Sys_Char* message);
//static void				ReadLoggerObject(cJSON* pLogger);
static Sys_Int				CreateDefaultModules();
static Sys_File_Handle	OpenLoggingFile(Sys_Int iTargets);
static void				MoveLoggingFiles();

/*
* Returns the integer values for the each log levels
* */
enum SysLogLevel LevelVal(Sys_Char *level)
{
	if (strcmp(level, "TRACE") == 0)
		return SYS_TRACE;
	else if (strcmp(level, "DEBUG") == 0)
		return SYS_DEBUG;
	else if (strcmp(level, "INFO") == 0)
		return SYS_INFO;
	else if (strcmp(level, "WARN") == 0)
		return SYS_WARN;
	else if (strcmp(level, "ERROR") == 0)
		return SYS_ERROR;
	else if (strcmp(level, "FORCE") == 0)
		return SYS_FORCE;
	else if (strcmp(level, "AUDIT") == 0)
		return SYS_AUDIT;
	else
		return SYS_ERROR; /* setting default log level as ERROR .*/
}

// Initialize logging
SysLogErrCodes SysLog_Init(Sys_Char *pszLoggerFilePath)
{
	Sys_Ullong freeSpace;
	Sys_Int err = SYS_OK;
	SysLogErrCodes retVal = SYSLOG_SUCCESS;

#ifdef WINCE
	Sys_Char tempLogDir[MAX_PATH];
	Sys_Char logRootDir[MAX_PATH];
	sprintf(tempLogDir, "%s", pszLoggerFilePath + 1);
	sprintf(logRootDir, "%s%s", "\\", strtok(tempLogDir, "\\"));
	err = Sys_GetFreeDiskSpace(logRootDir, &freeSpace);
#else
    err = Sys_GetFreeDiskSpace(NULL, &freeSpace);
#endif

	if (err != 0)
		return SYSLOG_SYSTEM_ERROR;

	if(g_pSysLogOptions)
		return SYSLOG_SUCCESS;

	g_pSysLogOptions =  (SysLogOptions*) Sys_Malloc(sizeof(SysLogOptions));
	if(g_pSysLogOptions == 0)
		return SYSLOG_ERROR_ALLOCATING_MEMORY;

	// set some defaults. Will be in config file
	g_pSysLogOptions->m_gLevel = SYS_INFO;
	g_pSysLogOptions->m_Target = LOG_TARGET_CONSOLE | LOG_TARGET_FILE;
#ifdef KEYHOOK_PROC
	g_pSysLogOptions->m_MaxFileSize = HELPER_FILE_SIZE;
	g_pSysLogOptions->m_MaxFileNumber = MAX_LOG_FILE_NUMBER;
#else
	g_pSysLogOptions->m_MaxFileSize = (freeSpace * SYS_LOG_FILE_SIZE_PERCENT) / (100 * MAX_LOG_FILE_NUMBER);//Depends on free disk space
	g_pSysLogOptions->m_MaxFileNumber = MAX_LOG_FILE_NUMBER;			// allow 5 file only
#endif  //KEYHOOK_PROC

#ifdef WINCE

	//ToDo:Soumya - pszLoggerFilePath pointer to be freed once used for Wince case 
	g_pSysLogOptions->m_TargetFile = pszLoggerFilePath;
#else /**WINCE**/
    g_pSysLogOptions->m_TargetFile = SysConvertPath(pszLoggerFilePath);
#endif /**WINCE**/
	g_pSysLogOptions->m_LoggingMutex = SysMutex_Create();
	g_pSysLogOptions->m_ModuleList = SysList_Create(0);
	if(!g_pSysLogOptions->m_LoggingMutex || !g_pSysLogOptions->m_ModuleList)
	{
		SysLog_Uninit();
		return SYSLOG_ERROR_ALLOCATING_MEMORY;
	}

#ifndef WINCE
	if (pszLoggerFilePath) { //Added after Valgrind mem check
		Sys_Free(pszLoggerFilePath);
		pszLoggerFilePath = NULL;
	}
#endif

	err = CreateDefaultModules();
	if (err)
	{
		retVal = SYSLOG_TWX_ERROR;
		SysLog_Uninit();
		return retVal;
	}

	// initialize per module options from some file or something
    //iReturn =  InitializeModuleOptions(); :Todo:Soumya

	// create log directory.
	err=SysCreateFolderForFile(g_pSysLogOptions->m_TargetFile);
	//Exits the exe if the Log folder is not created
	if (err== 0)
	{
		printf("Unable to create the log folder\n");
		retVal = SYSLOG_TWX_ERROR;
		SysLog_Uninit();
		return retVal;
	}

	// set Sys logging function
	//twLogger_SetFunction(SysTwLog);
	
	// Since logging of errors fire events, the Event Manager MUST be initialzied.
	//ErrorEventMgr_Initialize();

    g_bLogInitialzied = SYS_TRUE;

	return retVal;
}

SysLogErrCodes SysLog_Uninit()
{
    // Make sure no logging occurs during shutdown.
    g_bLogInitialzied = SYS_FALSE;

	if(g_pSysLogOptions)
	{
		if(g_pSysLogOptions->m_LoggingMutex)
			SysMutex_Delete(g_pSysLogOptions->m_LoggingMutex);
		if(g_pSysLogOptions->m_ModuleList)
			SysList_Delete(g_pSysLogOptions->m_ModuleList);
		if(g_pSysLogOptions->m_TargetFile)
			Sys_Free(g_pSysLogOptions->m_TargetFile);

		Sys_Free(g_pSysLogOptions);
	}
	g_pSysLogOptions = NULL;
	return SYSLOG_SUCCESS;
}

//int 	InitializeModuleOptions()
//{
//	// read the Json file	
//	Sys_Char* pszConfigFilePath = GetFilePathByName(CONFIG_FOLDER_NAME, STR_JSON_FILE_LOGGING);
//	Sys_Char* pszBufLogging = ReadFileContent(pszConfigFilePath);
//	cJSON* pJsonLogging = NULL;
//	Sys_BOOL	bJSONValid = FALSE;
//
//	Sys_Free(pszConfigFilePath);
//	if(pszBufLogging)
//	{
//		pJsonLogging = cJSON_Parse(pszBufLogging);
//		if(pJsonLogging)
//		{
//			cJSON* pVersion = cJSON_GetObjectItem(pJsonLogging, STR_VERSION);
//			if (pVersion && pVersion->valueint == CURRENT_CONFIG_FILE_VERSION)
//				bJSONValid = TRUE;
//		}
//	}
//
//	// post error if json not valid
//	if(bJSONValid == FALSE)
//	{
//		SysAppLog(SYS_ERROR, MODULE_SYS_ABSTRACTION, "Missing or invalid json file: %s", STR_JSON_FILE_LOGGING);
//		SysAppLog(SYS_ERROR, MODULE_SYS_ABSTRACTION, "Please populate valid json file, and restart ems_agent");
//	}
//
//	else
//	{
//		// find the logger object
//		cJSON* pLogger = cJSON_GetObjectItem(pJsonLogging, "logger");
//		if(pLogger)
//			ReadLoggerObject(pLogger);
//	}
//
//	cJSON_Delete(pJsonLogging);
//	Sys_Free(pszBufLogging);
//
//	// continue to run even if the json file is invalid
//	return TW_OK;
//}

SysLogErrCodes CreateDefaultModules()
{
	moduleOptions* pModule;

	// TW_SDK
	pModule = (moduleOptions*) Sys_Malloc(sizeof(moduleOptions));
	if(pModule == NULL)
		return SYSLOG_ERROR_ALLOCATING_MEMORY;
	SysList_Add(g_pSysLogOptions->m_ModuleList, pModule);

	Sys_StringCpy(pModule->m_ModuleName, STR_MODULE_SDK, (Sys_StringLength(STR_MODULE_SDK) + 1));
	pModule->m_mLevel = SYS_TRACE;
	//twLogger_SetLevel((enum LogLevel) pModule->m_mLevel);

	// EMS Config
	pModule = (moduleOptions*)Sys_Malloc(sizeof(moduleOptions));
	if(pModule == NULL)
		return SYSLOG_ERROR_ALLOCATING_MEMORY;
	SysList_Add(g_pSysLogOptions->m_ModuleList, pModule);

	Sys_StringCpy(pModule->m_ModuleName, STR_MODULE_EMS_CONFIG, (Sys_StringLength(STR_MODULE_EMS_CONFIG) + 1));
	pModule->m_mLevel = SYS_TRACE;

	// EMS Agent
	pModule = (moduleOptions*)Sys_Malloc(sizeof(moduleOptions));
	if(pModule == NULL)
		return SYSLOG_ERROR_ALLOCATING_MEMORY;
	SysList_Add(g_pSysLogOptions->m_ModuleList, pModule);

	Sys_StringCpy(pModule->m_ModuleName, STR_MODULE_EMS_AGENT, (Sys_StringLength(STR_MODULE_EMS_AGENT) + 1));
	pModule->m_mLevel = SYS_TRACE;

	// Native Agent
	pModule = (moduleOptions*)Sys_Malloc(sizeof(moduleOptions));
	if(pModule == NULL)
		return SYSLOG_ERROR_ALLOCATING_MEMORY;
	SysList_Add(g_pSysLogOptions->m_ModuleList, pModule);

	Sys_StringCpy(pModule->m_ModuleName, STR_MODULE_NATIVE_AGENT, (Sys_StringLength(STR_MODULE_NATIVE_AGENT) + 1));
	pModule->m_mLevel = SYS_TRACE;

	// Keysight EMS Agent or Main().
	pModule = (moduleOptions*)Sys_Malloc(sizeof(moduleOptions));
	if(pModule == NULL)
		return SYSLOG_ERROR_ALLOCATING_MEMORY;
	SysList_Add(g_pSysLogOptions->m_ModuleList, pModule);

	Sys_StringCpy(pModule->m_ModuleName, STR_MODULE_KEYSIGHT_EMS_AGENT, (Sys_StringLength(STR_MODULE_KEYSIGHT_EMS_AGENT) + 1));
	pModule->m_mLevel = SYS_TRACE;

	// Sys Abstraction
	pModule = (moduleOptions*)Sys_Malloc(sizeof(moduleOptions));
	if (pModule == NULL)
		return SYS_ERROR_ALLOCATING_MEMORY;
	SysList_Add(g_pSysLogOptions->m_ModuleList, pModule);

	Sys_StringCpy(pModule->m_ModuleName, STR_MODULE_SYS_ABSTRACTION, (Sys_StringLength(STR_MODULE_SYS_ABSTRACTION) + 1));
	pModule->m_mLevel = SYS_TRACE;

	// Utilities
	pModule = (moduleOptions*)Sys_Malloc(sizeof(moduleOptions));
	if (pModule == NULL)
		return SYS_ERROR_ALLOCATING_MEMORY;
	SysList_Add(g_pSysLogOptions->m_ModuleList, pModule);

	Sys_StringCpy(pModule->m_ModuleName, STR_MODULE_UTILITIES, (Sys_StringLength(STR_MODULE_UTILITIES) + 1));
	pModule->m_mLevel = SYS_TRACE;

#ifdef KEYHOOK_PROC
	//Helper Socket
	pModule = (moduleOptions*)Sys_Malloc(sizeof(moduleOptions));
	if (pModule == NULL)
		return SYS_ERROR_ALLOCATING_MEMORY;
	SysList_Add(g_pSysLogOptions->m_ModuleList, pModule);

	Sys_StringCpy(pModule->m_ModuleName, STR_MODULE_SOCKET, (Sys_StringLength(STR_MODULE_SOCKET) + 1));
	pModule->m_mLevel = SYS_TRACE;

	//Helper Keyhooks
	pModule = (moduleOptions*)Sys_Malloc(sizeof(moduleOptions));
	if (pModule == NULL)
		return SYS_ERROR_ALLOCATING_MEMORY;
	SysList_Add(g_pSysLogOptions->m_ModuleList, pModule);

	Sys_StringCpy(pModule->m_ModuleName, STR_MODULE_KEYHOOKS, (Sys_StringLength(STR_MODULE_KEYHOOKS) + 1));
	pModule->m_mLevel = SYS_TRACE;
#endif   //KEYHOOK_PROC

	return SYS_OK;
}

/*void	ReadLoggerObject(cJSON* pLogger)
{
	// default_level
	cJSON *pFile = NULL;
	cJSON *pTargets = NULL;
	cJSON *pModules = NULL;
	cJSON *pTemp = NULL;

	// default_level
	pTemp = cJSON_GetObjectItem(pLogger, "default_level");
	if(pTemp)
	{
		Sys_Char* pLevel = pTemp->valuestring;
		if(pLevel)
			g_pSysLogOptions->m_gLevel = LevelVal(pLevel);
	}

	// target list
	pTargets = cJSON_GetObjectItem(pLogger, "target");
	if(pTargets)
	{
		Sys_Int i;
		Sys_Int iTargets = cJSON_GetArraySize(pTargets);
		for(i = 0; i < iTargets; i ++)
		{
			cJSON *pTarget = cJSON_GetArrayItem(pTargets, i);
			if(pTarget && pTarget->valuestring)
			{
				// convert string to int
				if(strcmp(pTarget->valuestring, "console") == 0)
					g_pSysLogOptions->m_Target |= LOG_TARGET_CONSOLE;
				else if(strcmp(pTarget->valuestring, "file") == 0)
					g_pSysLogOptions->m_Target |= LOG_TARGET_FILE;
			}
		}
	}

	// file
	pFile = cJSON_GetObjectItem(pLogger, "file");
	if(pFile)
	{
		pTemp = cJSON_GetObjectItem(pFile, "path");
		if (pTemp && pTemp->valuestring)
		{
			if(g_pSysLogOptions->m_TargetFile)
				Sys_Free(g_pSysLogOptions->m_TargetFile);
			g_pSysLogOptions->m_TargetFile = SysConvertPath(pTemp->valuestring);
		}
		pTemp = cJSON_GetObjectItem(pFile, "max_file_size");
		if(pTemp)
			g_pSysLogOptions->m_MaxFileSize = pTemp->valueint;
		pTemp = cJSON_GetObjectItem(pFile, "max_files");
		if(pTemp)
			g_pSysLogOptions->m_MaxFileNumber = pTemp->valueint;
	}

	// moldules
	pModules = cJSON_GetObjectItem(pLogger, "modules");
	if(pModules)
	{
		Sys_Int i;
		Sys_Int iModules = cJSON_GetArraySize(pModules);
		for(i = 0; i < iModules; i ++)
		{
			// got one module
			cJSON* pModuleName;
			cJSON *pModule = cJSON_GetArrayItem(pModules, i);
			if(pModule)
			{
				moduleOptions*	pCurModule = NULL;
				Sys_Char* szTemp;

				// check if module exists already
				pModuleName = cJSON_GetObjectItem(pModule, "name");
				if(pModuleName)
				{
					szTemp = pModuleName->valuestring;
					if(szTemp)
						pCurModule = LookupModule(szTemp);
				}

				// If module is new
				if(pCurModule == NULL)
				{
					pCurModule = (moduleOptions*) Sys_Malloc(sizeof(moduleOptions));
					SysList_Add(g_pSysLogOptions->m_ModuleList, pCurModule);
				}

				// at this point, pCurModule must be good
				if(pCurModule)
				{
					if(szTemp)
						Sys_StringCpy(pCurModule->m_ModuleName, szTemp, (Sys_StringLength(szTemp) + 1));

					pTemp = cJSON_GetObjectItem(pModule, "level");
					if(pTemp)
					{
						szTemp = pTemp->valuestring;
						if(szTemp)
						{
							pCurModule->m_mLevel = LevelVal(szTemp);
							if (strcmp(pCurModule->m_ModuleName, STR_MODULE_SDK) == 0)
							{
								twLogger_SetLevel((enum LogLevel) pCurModule->m_mLevel);
							}

						}
					}
				}
			}
		}
	}
}*/

moduleOptions*	LookupModule(Sys_Char* moduleName)
{
	if(g_pSysLogOptions && g_pSysLogOptions->m_ModuleList)
	{
		SysList* moduleList = g_pSysLogOptions->m_ModuleList;
		SysListEntry* le = SysList_Next(moduleList, NULL);
		while(le && le->value) 
		{
			moduleOptions* pModule = (moduleOptions*)le->value;
			if(strcmp(pModule->m_ModuleName, moduleName) == 0)
				return pModule;
			le = SysList_Next(moduleList, le);
		}
	}

	return NULL;
}

// Override ThingsWorx log function (with the same signature)
void SysTwLog(enum SysLogLevel level, const Sys_Char * timestamp, const Sys_Char * message)
{
	DoLogging(level, MODULE_TW_SDK, timestamp, message);
}


// Sys log function (with more options: moduleID - log source, target - to file, console, etc.)
SysLogErrCodes SysAppLog(enum SysLogLevel level, Sys_Char* module, const Sys_Char * format, ...)
{
	Sys_Char	buffer[SYS_LOGGER_BUF_SIZE];
	Sys_Char	timeStr[80];
	SysLogErrCodes sysLogRetVal = SYSLOG_SUCCESS; 

	va_list va;
	va_start(va, format);
#ifdef WINCE
	_vsnprintf(buffer, SYS_LOGGER_BUF_SIZE - 1, format, va);
#else /**WINCE**/
    vsnprintf(buffer, SYS_LOGGER_BUF_SIZE - 1, format, va);
#endif /**WINCE**/
	va_end(va);

	sysLogRetVal = Sys_GetTimeStamp(timeStr, "%Y-%m-%d %H:%M:%S", 80, 1, 1);
	if (sysLogRetVal != SYS_RET_OK) {
		sysLogRetVal = SYSLOG_WRONG_IP_PARAMS;
		return sysLogRetVal;
	}
	//twGetSystemTimeString(timeStr, "%Y-%m-%d %H:%M:%S", 80, 1, 1);
	sysLogRetVal = DoLogging(level, module, timeStr, buffer);
	return sysLogRetVal;
}

//
// work horse logging function
//
SysLogErrCodes DoLogging(Sys_Int level, Sys_Char* module, const Sys_Char* timeStr, const Sys_Char* message)
{
	Sys_Int				iTargets = LOG_TARGET_CONSOLE;
	Sys_Int				iconfigLevel = SYS_INFO;			// default INFO
	SysLogErrCodes retVal = SYSLOG_SUCCESS;
	Sys_File_Handle	hFile = NULL;
	moduleOptions*	pmodule;

    if (g_bLogInitialzied == SYS_FALSE)
		return 0;         // safety check.

	if(!g_pSysLogOptions)
	{
		OutputMessage(iTargets, hFile, "Logging has not been initialized yet.\n");
		return 0;
	}
	iTargets = g_pSysLogOptions->m_Target;
	iconfigLevel = g_pSysLogOptions->m_gLevel;		// get from global

	SysMutex_Lock(g_pSysLogOptions->m_LoggingMutex);
	hFile = OpenLoggingFile(iTargets);
	if (hFile == NULL)
	{
		retVal = SYSLOG_SYSTEM_ERROR;
		return retVal;
	}
	// hunt for the source module
	pmodule = LookupModule(module);
	if(pmodule)
		iconfigLevel = pmodule->m_mLevel;		// over ride from per module

	// check log level. if module not found, treat it as error (always log)
	if(!pmodule || !(iconfigLevel > level))
	{
		// time stamp
		OutputMessage(iTargets, hFile, timeStr);
		OutputMessage(iTargets, hFile, " ");

		// module name
		if(pmodule)
			OutputMessage(iTargets, hFile, pmodule->m_ModuleName);
		else
			OutputMessage(iTargets, hFile, "Unknown");
			OutputMessage(iTargets, hFile, "--");

		// debug level
		if(level == SYS_TRACE)
			OutputMessage(iTargets, hFile, "TRACE ");
		else if(level == SYS_DEBUG)
			OutputMessage(iTargets, hFile, "DEBUG ");
		else if(level == SYS_INFO)
			OutputMessage(iTargets, hFile, "INFO ");
		else if(level == SYS_WARN)
			OutputMessage(iTargets, hFile, "WARN ");
		else if(level == SYS_ERROR)
			OutputMessage(iTargets, hFile, "ERROR ");
		else if(level == SYS_FORCE)
			OutputMessage(iTargets, hFile, "FORCE ");
		else if(level == SYS_AUDIT)
			OutputMessage(iTargets, hFile, "AUDIT ");
		else
			OutputMessage(iTargets, hFile, "INFO ");

		// the debug message itself
		OutputMessage(iTargets, hFile, message);

		// end the line
		OutputMessage(iTargets, hFile, "\n");
	}

	if(hFile)
		Sys_Fclose(hFile);

	SysMutex_Unlock(g_pSysLogOptions->m_LoggingMutex);
	return retVal;
    // If an error is logged, notify the ThingWorx Server via an event.
    //ErrorEventMgr_FireEvent(level, pmodule->m_ModuleName, message);
}

void	OutputMessage(Sys_Int iTargets, Sys_File_Handle handle, const Sys_Char* message)
{

	// to console
	if(iTargets & LOG_TARGET_CONSOLE)
		printf("%s",message);

	// to file
	if(handle)
		Sys_Fwrite(message, 1, strlen(message), handle);
	// to other venues
}

Sys_File_Handle OpenLoggingFile(Sys_Int iTargets)
{
	Sys_File_Handle hFile = NULL;
    Sys_Long			iSize;
	
	if(iTargets & LOG_TARGET_FILE)
	{
		hFile = Sys_Fopen(g_pSysLogOptions->m_TargetFile, "a+");
		if (hFile)
		{
			Sys_Fseek(hFile, 0, SEEK_END);
			iSize = (Sys_Long)Sys_Ftell(hFile);

			if(iSize >= g_pSysLogOptions->m_MaxFileSize)
			{
				Sys_Fclose(hFile);

				// move files
				MoveLoggingFiles();

				hFile = Sys_Fopen(g_pSysLogOptions->m_TargetFile, "w+");	// this creates an empty file
				//Todo:Akshata terminate the application if not able to create the logging file (1 to 5)
				/*if (hFile == NULL)
				{
					return hFile;
				}*/
			}
		}
		//Return the error if not able to create the 1st loggin file
		else
		{
			return hFile;
		}
	}

	return hFile;
}

//
// MoveLoggingFiles() recycle logging files when size is maxed
//
void	MoveLoggingFiles()
{
	Sys_Char*	pConfigFile = g_pSysLogOptions->m_TargetFile;
	Sys_Int		iNumber = g_pSysLogOptions->m_MaxFileNumber;

	Sys_Char	fileNameLast[512];
	Sys_Char	fileNamePrev[512];
	Sys_Int		iSuffix = -1;
	Sys_Int		iLen;
	Sys_Int		i;
	
	// find the suffix
	iLen = strlen(pConfigFile);
	for(i = iLen - 1; i > 0; i --)
	{
		if(pConfigFile[i] == '\\' || pConfigFile[i] == '/')
			break;
		if(pConfigFile[i] == '.')
		{
			iSuffix = i;
			break;
		}
	}

	for(i = iNumber; i > 0; i --)
	{
		// construct the file name with number
		if(iSuffix == -1)
		{
			sprintf(fileNameLast, "%s%d", pConfigFile, i);
			if(i > 1)
				sprintf(fileNamePrev, "%s%d", pConfigFile, i - 1);
			else
				sprintf(fileNamePrev, "%s", pConfigFile);
		}
		else
		{
			pConfigFile[iSuffix] = 0;
			sprintf(fileNameLast, "%s%d", pConfigFile, i);
			pConfigFile[iSuffix] = '.';
			strcat(fileNameLast, pConfigFile + iSuffix);

			if(i > 1)
			{
				pConfigFile[iSuffix] = 0;
				sprintf(fileNamePrev, "%s%d", pConfigFile, i - 1);
				pConfigFile[iSuffix] = '.';
				strcat(fileNamePrev, pConfigFile + iSuffix);
			}
			else
				sprintf(fileNamePrev, "%s", pConfigFile);
		}

		// delete the highest numbered file
		if(i == iNumber)
			SysDeleteFile(fileNameLast);

		// elevate the Prev to Last
		SysRenameFile(fileNamePrev, fileNameLast);
	}
}
