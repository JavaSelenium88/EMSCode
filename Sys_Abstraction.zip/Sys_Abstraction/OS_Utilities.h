//*****************************************************************************
//
//  Copyright © 2016 ITC .  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  OS_Utilities.h
//  
//  Subsystem  :  KeySight
//
//  Description:  OS abstraction layer for various support (utility) functions.
//
//*****************************************************************************

#ifndef __OS_UTILITIES_H__
#define __OS_UTILITIES_H__

#include <sys/stat.h>
#include <time.h>
#include "Sysapi.h"
#ifdef WIN32
#ifndef PATH_MAX
#define PATH_MAX MAX_PATH
#else
#include <unistd.h>   //  Added for the getcwd()
#endif
#endif

// Global Service standard defines
typedef Sys_Char SYS_BOOL;
#define SYS_OK           0
#define SYS_GENERAL_ERR  1


//*****************************************************************************
// GetCWD()
//  - returns char* to the current working directory.
// caller is responsible to free the memory returned by GetCWD
// ****************************************************************************
Sys_Char* GetCWD();

//*****************************************************************************
// GetUUID()
//  - input/output char* memory to hold the gernated GUID. 
// ****************************************************************************
void GetUUID(/* output */ Sys_Char* pszUUID);


//*****************************************************************************
// ReadFileContent
//  - input:  Filename of file to be read.
//  - return:  pointer to memory holding the content of the entire file.
// caller is responsible to free the memory returned by GetCWD****************/
// ****************************************************************************
Sys_Char *ReadFileContent(Sys_Char *fileName);


//*****************************************************************************
//
// ReadLineFromFile()	
// Read a line from the open file. Read will stop either (size - 1) characters are read, or newline is encountered.
// Return NULL if file end is reached and no content is read.
//
//*****************************************************************************
Sys_Char* ReadLineFromFile(Sys_Char* buffer, Sys_Int size, FILE* hFile);

//*****************************************************************************
//
// SYS_GetSecondsSince1970()	
//	returns a time_t in Epoch time. 
//
//*****************************************************************************
time_t SYS_GetSecondsSince1970();

//*****************************************************************************
//
// GetLocalTime()	
//					It returns the system's local time based on seconds.
//
//*****************************************************************************
SYS_BOOL SYS_GetLocalTime(struct tm* pLocal);

Sys_Int SYS_GetYear();

// Wait for the shutdown signal.
//void	WaitForShutdownSignal(); //ToDo-Soumya -Not in use


// Execute a program, or batch file (Windows) or shell script (Linux)
Sys_Ulong	SysExecuteProgram(Sys_Char* szFile, Sys_Int iWait);

// Convert path (slash vs. back-slash). Caller owns the return memory
Sys_Char* SysConvertPath(Sys_Char* pPath);

// pPath is folder
SYS_BOOL SysCreateFolderRecursive(Sys_Char* pPath);

// pFile is file name
SYS_BOOL SysCreateFolderForFile(Sys_Char* pFile);

// pFile is file name
SYS_BOOL SysDeleteFile(Sys_Char* pFile);

// pSourceFile is old file name. pTargetFile is new file name
SYS_BOOL SysRenameFile(Sys_Char* pSourceFile, Sys_Char* pTargetFile);

/*****************************************************************************
Return the absoulte path of a configuration file in the current working
directory.
input:  configuration file name.
return:  pointer to absolute file path.
*** The caller is responsible to free the memory of the returned pointer
*****************************************************************************/
Sys_Char* GetFilePathByName(Sys_Char* folderName, Sys_Char* fileName);

/*****************************************************************************
Wraper around get_mtime System API
*****************************************************************************/
Sys_time_t SYS_Get_Mtime(const Sys_Char *path);

/*****************************************************************************
Return the last modified time of the file
input:  pointer to file path whose last modified time is needed.
return:  msec count since 1970.
*****************************************************************************/
Sys_time_t get_mtime(const char *path);
#endif  // __OS_UTILITIES_H__
