//**************************************************************************
//
//  Copyright � 2016 ITC .  All rights reserved.
//
//**************************************************************************
//
//  Filename   :  SysEvent.h
//  
//  Subsystem  :  KeySight
//
//  Author     :  Soumya Ranjan Bej
//
//  Description:  C style struct to manage wait Event
//
//
//**************************************************************************

#ifndef __SYS_EVENT_H__
#define __SYS_EVENT_H__

// Linux includes and defines
#ifndef WIN32
#include "SysLinux-openssl.h"
#include <sys/time.h>
#include <pthread.h>
#define INFINITE 0xFFFFFFFF
#define WAIT_OBJECT_0	0x00000000L
#define WAIT_TIMEOUT	0x00000102L
#define WAIT_FAILED		0xFFFFFFFF
#endif
#include "Sysapi.h"
// Event struct
typedef struct  SysEventStruct
{
#ifdef WIN32
    HANDLE				m_waitEvent;	// Event handle
#else
	SYS_MUTEX			m_waitEvent;	// the Event
    pthread_cond_t*		m_pCondition;	// condition used with m_waitEvent
#endif
} SysEventStruct;


// event struct management functions
SysEventStruct*			SysCreateEventStruct();
void					SysDestroyEventStruct(SysEventStruct*);

// wait function
Sys_Ulong			SysWaitForEvent(SysEventStruct*, Sys_Ulong milliSeconds);
void					SysSignalEvent(SysEventStruct*);

#endif // __SYS_EVENT_H__
