//*****************************************************************************
//
//  Copyright © 2016 ITC Corporation.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  SysThreadLinux.c
//
//  Description:  C style struct to manage threads, Linux platform
//
//
//*****************************************************************************


#include "stdio.h"
#include "stdlib.h"

// To include ETIMEDOUT
#include <errno.h>

//#include "twOSPort.h"	// for TW_MUTEX

#include "SysThread.h"
#include "Systypes.h"
#include "SysLog.h"

//*****************************************************************************
// creates the event struct
SysEventStruct* SysCreateEventStruct()
{
    Sys_Char *function = "SysCreateEventStruct";
    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

    SysEventStruct* pSysEventStruct = Sys_Malloc(sizeof(SysEventStruct));
    if(pSysEventStruct)
    {
        pSysEventStruct->m_waitEvent = SysMutex_Create();
        pSysEventStruct->m_pCondition = Sys_Malloc(sizeof(pthread_cond_t));
        if(pSysEventStruct->m_waitEvent && pSysEventStruct->m_pCondition)
        {
            if(pthread_cond_init(pSysEventStruct->m_pCondition, 0) == 0)
                return pSysEventStruct;
        }
    }

    SysDestroyEventStruct(pSysEventStruct);

    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
    return 0;
}

//*****************************************************************************
// destroys the event struct
void SysDestroyEventStruct(SysEventStruct* pSysEventStruct)
{
    Sys_Char *function = "SysDestroyEventStruct";
    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

    if(pSysEventStruct)
    {
        if(pSysEventStruct->m_waitEvent)
            SysMutex_Delete(pSysEventStruct->m_waitEvent);
        if(pSysEventStruct->m_pCondition)
        {
            pthread_cond_destroy(pSysEventStruct->m_pCondition);
            SYS_FREE(pSysEventStruct->m_pCondition);
            pSysEventStruct->m_pCondition = 0;
        }

        SYS_FREE(pSysEventStruct);
    }
    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
}


//*****************************************************************************
// wait for the event.
unsigned long SysWaitForEvent(SysEventStruct* pSysEventStruct, unsigned long milliSeconds)
{
    unsigned long ret = WAIT_FAILED;
    Sys_Char *function = "SysWaitForEvent";
    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

    struct timeval now;
    struct timespec timeout;

    if(pSysEventStruct == 0)
        return ret;

    SysMutex_Lock(pSysEventStruct->m_waitEvent);

    if(milliSeconds != INFINITE)
    {
        gettimeofday(&now, NULL);

        timeout.tv_sec = now.tv_sec;
        timeout.tv_nsec = (now.tv_usec*1000);

        timeout.tv_sec  += (milliSeconds/1000);
        timeout.tv_nsec += ((milliSeconds%1000) * 1000000);

        if( timeout.tv_nsec > 1000000000 )
        {
            timeout.tv_sec  += (timeout.tv_nsec/1000000000);
            timeout.tv_nsec = (timeout.tv_nsec%1000000000);
        }
        ret = pthread_cond_timedwait(pSysEventStruct->m_pCondition, pSysEventStruct->m_waitEvent, &timeout);
    }
    else
    {
        ret = pthread_cond_wait(pSysEventStruct->m_pCondition, pSysEventStruct->m_waitEvent);
    }

    // change return code to reflect the Windows defintions.
    if (ret == 0)
        ret = WAIT_OBJECT_0;
    else if (ret == ETIMEDOUT)
        ret = WAIT_TIMEOUT;
    else
        ret = WAIT_FAILED;

    SysMutex_Unlock(pSysEventStruct->m_waitEvent);

    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
    return ret;
}


void    SysSignalEvent(SysEventStruct* pSysEventStruct)
{
    Sys_Char *function = "SysSignalEvent";
    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

    if(pSysEventStruct)
        pthread_cond_broadcast(pSysEventStruct->m_pCondition);

    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
}


//*****************************************************************************
// creates the thread struct
SysThreadStruct *SysCreateThreadStruct()
{
    Sys_Char *function = "SysCreateThreadStruct";
    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

    SysThreadStruct* pSysThreadStructTemp = (SysThreadStruct*) Sys_Malloc(sizeof(SysThreadStruct));
    if(pSysThreadStructTemp)
    {
       pSysThreadStructTemp->m_bRunning		= 0;
       pSysThreadStructTemp->m_bSuspend     = 0;
       pSysThreadStructTemp->m_parameter1	= 0;
       pSysThreadStructTemp->m_parameter2 = 0;
       pSysThreadStructTemp->m_dataMutex	= SysMutex_Create();
       pSysThreadStructTemp->m_waitMilliSec		= 500;
       pSysThreadStructTemp->m_threadId		= 0;
       pSysThreadStructTemp->m_pSysEventStruct = SysCreateEventStruct();

       if(pSysThreadStructTemp->m_dataMutex && pSysThreadStructTemp->m_pSysEventStruct){
          SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
          return pSysThreadStructTemp;
       }
    }

    SysDestroyThreadStruct(pSysThreadStructTemp);
    pSysThreadStructTemp = 0;

    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited with failure !!", function);
    return 0;
}

//*****************************************************************************
// destroys the thread struct
void SysDestroyThreadStruct(SysThreadStruct* pSysThreadStructTemp)
{
    Sys_Char *function = "SysDestroyThreadStruct";
    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pSysThreadStructTemp)
	{
		if(pSysThreadStructTemp->m_dataMutex)
			SysMutex_Delete(pSysThreadStructTemp->m_dataMutex);
        if(pSysThreadStructTemp->m_pSysEventStruct)
            SysDestroyEventStruct(pSysThreadStructTemp->m_pSysEventStruct);

        Sys_Free(pSysThreadStructTemp);
	}
	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
}

//*****************************************************************************
// start the thread running
int SysStartThread(SysThreadStruct* pSysThreadStruct, SysThreadProc pFun)
{
	int i = 0;
    Sys_Char *function = "SysStartThread";
    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pSysThreadStruct)
	{
		pSysThreadStruct->m_bRunning = 1;
		pthread_create(&pSysThreadStruct->m_threadId, NULL, pFun, pSysThreadStruct);
		i = (Sys_Int)pSysThreadStruct->m_threadId;
	}
	return i;
}

//*****************************************************************************
// Signal the thread to wake up.
void SysSignalThread(SysThreadStruct* pSysThreadStruct)
{
    Sys_Char *function = "SysSignalThread";
    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pSysThreadStruct)
	{
		// wake up the waiting object
		pthread_cond_broadcast(pSysThreadStruct->m_pSysEventStruct->m_pCondition);
	}

	SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: exited.", function);
}

//*****************************************************************************
// stop the running thread
void SysStopThread(SysThreadStruct* pSysThreadStruct)
{
    Sys_Char *function = "SysStopThread";
    SysAppLog(SYS_DEBUG, MODULE_SYS_ABSTRACTION, "%s: entered.", function);

	if(pSysThreadStruct)
	{
		// stop
		pSysThreadStruct->m_bRunning = 0;

		// wake up the waiting object
		pthread_cond_broadcast(pSysThreadStruct->m_pSysEventStruct->m_pCondition);

		// wait for exit
		if (pSysThreadStruct->m_threadId)
			pthread_join(pSysThreadStruct->m_threadId, NULL);
		//pSysThreadStruct->m_threadId = 0; //Freed at a later stage.
	}
}

/******************************************************************************/
/* called inside the SysThread to wait for the next execution cycle.*/
/*int SysThreadWaitForRunCycle(SysThreadStruct* pSysThreadStruct)
{
    int ret = 0;
    struct timeval now;
    struct timespec timeout;

	if(pSysThreadStruct == 0)
		return ret;

	twMutex_Lock(pSysThreadStruct->m_waitEvent);

    if(pSysThreadStruct->m_waitMilliSec != INFINITE)
	{
        gettimeofday(&now, NULL);

        timeout.tv_sec = now.tv_sec;
        timeout.tv_nsec = (now.tv_usec*1000);

        timeout.tv_sec  += (pSysThreadStruct->m_waitMilliSec/1000);
        timeout.tv_nsec += ((pSysThreadStruct->m_waitMilliSec%1000) * 1000000);

        if( timeout.tv_nsec > 1000000000 )
        {
            timeout.tv_sec  += (timeout.tv_nsec/1000000000);
            timeout.tv_nsec = (timeout.tv_nsec%1000000000);
        }
        ret = pthread_cond_timedwait(pSysThreadStruct->m_pSysEventStruct->m_pCondition, pSysThreadStruct->m_waitEvent, &timeout);
    }
    else
    {
        ret = pthread_cond_wait(pSysThreadStruct->m_pSysEventStruct->m_pCondition, pSysThreadStruct->m_waitEvent);
    }

    // change return code to reflect the Windows defintions.
    if (ret == 0)
    {
        ret = WAIT_OBJECT_0;
    }
    else if (ret == ETIMEDOUT)
    {
        ret = WAIT_TIMEOUT;
    }
    else
        ret = WAIT_FAILED;

	twMutex_Unlock(pSysThreadStruct->m_waitEvent);

    return ret;
}*/


