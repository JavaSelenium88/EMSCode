/***************************************
 *  Copyright 2016, PTC, Inc.
 ***************************************/

/**
 * \file twLinux-openssl.h
 * \brief Wrappers for Linux-specific functionality using OpenSSL
*/

#ifndef SYS_LINUX_H
#define SYS_LINUX_H

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <dirent.h>
#include <stdio.h>

/**
 * \name TLS Library
*/
/**
 * \brief Define which pluggable TLS library is used.
 *
 * \note The NO_TLS option turns off encryption altogether which may be useful
 * for debugging but is also <b>not recommended for production environments</b>
 * as it may introduce serious security risks.
*/
#define SYS_TLS_INCLUDE "twOpenSSL.h" 

/**
 * \name Logging
*/
#ifndef TW_LEAN_AND_MEAN
/**
 * \brief The maximum size of the log buffer.
*/
#define SYS_LOG_BUF_SIZE 4096
#define SYS_LOG(level, fmt, ...)  twLog(level, fmt, ##__VA_ARGS__)
#define SYS_LOG_HEX(msg, preamble, length)   twLogHexString(msg, preamble, length)
#define SYS_LOG_MSG(msg, preamble)   twLogMessage(msg, preamble)

/**
 * \name Proxies
*/
#ifndef ENABLE_HTTP_PROXY_SUPPORT
#define ENABLE_HTTP_PROXY_SUPPORT
#endif
#ifndef USE_NTLM_PROXY
#define USE_NTLM_PROXY
#endif

#else /* LEAN AND MEAN */
/**
 * \name Lean and Mean Options
 * \brief  Disables logging.  Can also use this to override other resource/code
 * size impacting functions such as file transfer, offline message store, and
 * tunneling.
*/
#define SYS_LOGGER_BUF_SIZE 1
#define SYS_LOG(level, fmt, ...)
#define SYS_LOG_HEX(msg, preamble, length)
#define SYS_LOG_MSG(msg, preamble) 

#undef OFFLINE_MSG_STORE
#define OFFLINE_MSG_STORE 0
#undef  ENABLE_HTTP_PROXY_SUPPORT
#undef USE_NTLM_PROXY
#undef ENABLE_FILE_XFER
#undef ENABLE_TUNNELING
#endif

/**
 * \brief Date/time type definition.
*/
typedef uint64_t SYS_DATETIME;

/**
 * \brief For Linux builds a #TW_MUTEX is a pthread_mutex_t.
*/
#define SYS_MUTEX pthread_mutex_t *

/**
 * \name Sockets
*/
#define IPV4 AF_INET
#define IPV6 AF_INET6
#define SYS_SOCKET_TYPE int
#define SYS_ADDR_INFO struct addrinfo
#ifndef SYS_HINTS
#define SYS_HINTS PF_UNSPEC
#endif

/**
 * \name Tasks
*/
#define TICKS_PER_MSEC 1

/**
 * \name Memory
*/
#define SYS_MALLOC(a) malloc(a) 
#define SYS_CALLOC(a, b) calloc(a,b)
#define SYS_REALLOC(a, b) realloc(a, b)
#define SYS_FREE(a) free(a)

/**
 * \name File Transfer
*/
#define SYS_FOPEN(a,b) fopen(a,b)
#define SYS_FCLOSE(a) fclose(a)
#define SYS_FREAD(a,b,c,d) fread(a,b,c,d)
#define SYS_FWRITE(a,b,c,d) fwrite(a,b,c,d)
#define SYS_FSEEK(a,b,c) fseeko(a,b,c)
#define SYS_FERROR(a) ferror(a)
#define SYS_FTELL(a) ftell(a)

#define SYS_FILE_HANDLE FILE*
#define SYS_FILE_DELIM '/'
#define SYS_FILE_DELIM_STR "/"
#define SYS_FILE_CASE_SENSITVE TRUE
#define SYS_DIR DIR *
#define ERROR_NO_MORE_FILES 0

/**
 * \name Threads
*/
#define SYS_THREAD_ID pthread_t    

/**
 * \name Misc
*/
#define INLINE 
#ifndef OS_IOS

char getch();

#endif

#endif
