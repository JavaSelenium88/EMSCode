/*
 *  Copyright 2016, PTC, Inc.
 *
 *  Wrappers for OS Specific Thread functionality
 */

#include "SysThreads.h"
#include "Systypes.h"
#ifndef WINCE
#include <process.h>
#else /**WINCE**/
#include <winbase.h>
#endif 

/********************************/
/* OS ThreadFunction Definition */
/********************************/
unsigned __stdcall OsThreadFunction( void * param ) {
	SysThread * t = (SysThread *)param;
	if (!t || !t->func) return -1;
	while (!t->shutdownRequested) {
		if (t->isRunning && !t->isPaused) {
			/* Call our thread function */
			t->func(SysGetSystemTime(TRUE), t->opaquePtr);
		}
		if (t->rate) {
			SysSleepMsec(t->rate);
		} else {
			/* Run once and done thread has a rate of 0 */
			t->shutdownRequested = TRUE;
		}
	}
	t->hasStopped = TRUE;
	t->isPaused = FALSE;
	t->isRunning = FALSE;
#ifdef WINCE
	ExitThread(0);
#else /**WIN32**/
    _endthreadex(0);
#endif 

	return 0;
}

/*******************************/
/*    twThread API Funtions    */
/*******************************/
SysThread * SysThread_Create(SysTaskFunction func, uint32_t rate, void * opaquePtr, char autoStart) {
	/* Internal variables */
	SysThread * t = NULL;
	/* Check required params */
	if (!func) return NULL;
	/* Allocate our structure */
	t = (SysThread *)SYS_CALLOC(sizeof(SysThread), 1);
	if (!t) return NULL;
	/* Set up the twThread. Don't start running yet unless autorun is set */
	t->func = func;
	t->rate = rate;
	t->opaquePtr = opaquePtr;
#ifdef WINCE
	t->id = (HANDLE)CreateThread(NULL, 0, OsThreadFunction, t, 0, NULL);
#else /**WIN32**/
    t->id = (HANDLE)_beginthreadex(NULL, 0, OsThreadFunction, t, 0, NULL);
#endif
  
	if (t->id == NULL) {
		SysThread_Delete(t);
		return NULL;
	}
	t->isRunning = autoStart;
	return t;
}

void SysThread_Delete(void * t) {
	SysThread * tmp = (SysThread *)t;
	if (!t) return;
	if (!tmp->hasStopped) SysThread_Stop(tmp, 10000);
	CloseHandle(tmp->id);
	SYS_FREE(t);
}

int SysThread_Start(SysThread * t) {
	if (!t) return SYS_INVALID_PARAM;
	t->isRunning = TRUE;
	return SYS_OK;
}

int SysThread_Stop(SysThread * t, int32_t waitTime) {
	uint64_t shutdownTime = SysGetSystemMillisecondCount() + waitTime;
	if (!t) return SYS_INVALID_PARAM;
	t->shutdownRequested = TRUE;
	while (!t->hasStopped && SysGetSystemMillisecondCount() < shutdownTime) {
		SysSleepMsec(5);
	}
	if (!t->hasStopped) TerminateThread(t->id, -1);
	return SYS_OK;
}

int SysThread_Pause(SysThread * t) {
	if (!t) return SYS_INVALID_PARAM;
	t->isPaused = TRUE;
	return SYS_OK;
}

int SysThread_Resume(SysThread * t) {
	if (!t) return SYS_INVALID_PARAM;
	t->isPaused = FALSE;
	return SYS_OK;
}

char SysThread_IsRunning(SysThread * t) {
	return t ? t->isRunning : FALSE;
}

char SysThread_IsPaused(SysThread * t) {
	return t ? t->isPaused : FALSE;
}

char SysThread_IsStopped(SysThread * t) {
	return t ? t->hasStopped : FALSE;
}

SYS_THREAD_ID SysThread_GetThreadId(SysThread * t) {
	if (!t) return 0;
	return t->id;
}
