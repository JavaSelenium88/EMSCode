/*
 *  Copyright 2016, PTC, Inc.
 *
 *  Wrappers for OS Specific functionality
 */

#include "SysOSPort.h"
//#include "twHttpProxy.h"
#include "Systypes.h"
#include "SysLog.h"
//#include "stringUtils.h"

#include <time.h>
#include <sys/timeb.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <errno.h>
#include <dirent.h>
#include <sys/stat.h>

#ifndef OS_IOS
#include <termios.h>
#endif

/* will be used to copy files during twDirectory_CopyFile and twDirectory_MoveFile */
#define SYS_COPY_BUF_SIZE 8192

/* Logging Function */
void SYS_LOGGING_FUNCTION( enum SysLogLevel level, const char * timestamp, const char * message ) {
	printf("[%-5s] %s: %s\n", SyslevelString(level), timestamp, message);
}

char * SyslevelString(enum SysLogLevel level) {
	switch (level) {
	case SYS_TRACE:
		return "TRACE";
	case SYS_DEBUG:
		return "DEBUG";
	case SYS_INFO:
		return "INFO";
	case SYS_WARN:
		return "WARN";
	case SYS_ERROR:
		return "ERROR";
	case SYS_FORCE:
		return "FORCE";
	case SYS_AUDIT:
		return "AUDIT";
	default:
		return "UNKNOWN";
	}
}

// Time Functions
char SysTimeGreaterThan(SYS_DATETIME t1, SYS_DATETIME t2) {
	return (t1 > t2);
}

char SysTimeLessThan(SYS_DATETIME t1, SYS_DATETIME t2) {
	return (t1 < t2);
}

SYS_DATETIME SysAddMilliseconds(SYS_DATETIME t1, int32_t msec) {
	return t1 + msec;
}

SYS_DATETIME SysGetSystemTime(char utc) {
	struct timeb timebuffer;
	ftime( &timebuffer ); 
	return ((SYS_DATETIME)timebuffer.time * 1000 + timebuffer.millitm);
}

uint64_t SysGetSystemMillisecondCount() {
	return (uint64_t)SysGetSystemTime(SYS_TRUE);
}

void SysGetTimeString(SYS_DATETIME time, char * s, const char * format, int length, char msec, char utc) {
	struct tm timeinfo;
	time_t seconds;
	uint32_t mseconds;
	char millisec[8];
	mseconds = time % 1000;
	seconds = time / 1000;
	/* Convert this to a tm struct */
	if (utc) {
		localtime_r(&seconds, &timeinfo);
	}
	else {
		gmtime_r(&seconds, &timeinfo);
	}
	if (msec) {
		strftime (s,length - 4,format, &timeinfo);
		/* append the milliseconds */
		memset(millisec, 0, 8);
		sprintf(millisec,"%u", mseconds);
		if (strlen(s) < length - 9) {
			strncat(s, ",", 1);
			strncat(s, millisec, 8);
		}
	} else strftime (s,length,format,&timeinfo);
}

void SysGetSystemTimeString(char * s, const char * format, int length, char msec, char utc) {
	SYS_DATETIME t;
	t = SysGetSystemTime(utc);
	SysGetTimeString(t, s, format, length, msec, utc);
}

void SysSleepMsec(int milliseconds) {
	usleep(milliseconds * 1000);
}

// Mutex Functions
SYS_MUTEX SysMutex_Create() {
	pthread_mutex_t * tmp = SYS_MALLOC(sizeof(pthread_mutex_t));
	if (!tmp) return 0;
	pthread_mutex_init(tmp,0);
	return tmp;
}

void SysMutex_Delete(SYS_MUTEX m) {
	pthread_mutex_t * tmp = m;
	if (!tmp) return;
	m = 0;
	pthread_mutex_destroy(tmp);
	free(tmp);
}

void SysMutex_Lock(SYS_MUTEX m) {
	if (m) pthread_mutex_lock(m);
}

void SysMutex_Unlock(SYS_MUTEX m) {
	if (m) pthread_mutex_unlock (m);
}

#ifdef SYS_SOCKET
// Socket Functions
int SysPosixSocket_Create(int domain, int socktype, int protocol) {
	int sock = socket(domain, socktype, protocol);
#ifdef OS_IOS
	int value = 1;
	if (sock != -1) { setsockopt(sock, SOL_SOCKET, SO_NOSIGPIPE, &value, sizeof(value)); }
#endif
	return sock;
}

SysSocket * SysSocket_Create(const char * host, int16_t port, uint32_t options) {

	struct addrinfo hints, *p;
	int rval;
	char foundServer = 1;
	SysSocket * res = NULL;
	char portStr[10];

	// Allocate our SysSocket
	res = (SysSocket *)malloc(sizeof(SysSocket));
	if (!res) return 0;
	memset(res, 0, sizeof(SysSocket));

	/* Set up our address structure and any proxy info */
	res->host = duplicateString(host);
	res->port = port;
	/* If we we have a host, try to resolve it */
	if ((host && strcmp(host,"")) && port) {
		memset(&hints, 0x00, sizeof(hints));
		hints.ai_family = TW_HINTS;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_protocol = IPPROTO_TCP;
		snprintf(portStr, 10, "%u", port);
		if ((rval = getaddrinfo(host, portStr, &hints, &p)) != 0) {
			free(res);
			return NULL;
		}

		// loop through all the results and connect to the first we can
		res->addrInfo = p;
		for(; p != NULL; p = p->ai_next) {
			if ((res->sock = SysPosixSocket_Create(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
				continue;
			} else {
				foundServer = 1;
				///// res->addr = p;
				memcpy(&res->addr, p, sizeof(struct addrinfo));
				break;
			}
		}
		if (!foundServer) {
			free(res);
			return NULL;
		}
	}
	res->state = CLOSED;
	return res;
}

int SysSocket_Connect(SysSocket * s) {
	int res;
	if (!s) return -1;

	if ((res = connect(s->sock, s->addr.ai_addr, s->addr.ai_addrlen)) == -1) {
		int err = 0;
		close(s->sock);
		s->sock = -1 ;
		err = SysSocket_GetLastError();
		return err ? err : -1;
	}
#ifdef ENABLE_HTTP_PROXY_SUPPORT
	if (s->proxyHost && s->proxyPort > 0) {
		res = connectToProxy(s, NULL);
		if (res) {
			return res;
		}
	}	
#endif
	s->state = OPEN;
	return res;
}

int SysSocket_Reconnect(SysSocket * s) {
	if (!s) return -1;
	SysSocket_Close(s);
	if ((s->sock = SysPosixSocket_Create(s->addr.ai_family, s->addr.ai_socktype, s->addr.ai_protocol)) == -1) {
		return -1;
	}
	return SysSocket_Connect(s);
}

int SysSocket_Close(SysSocket * s) {
	if (!s) return -1;
	close(s->sock);
	s->state = CLOSED;
	return 0;
}

int SysSocket_Read(SysSocket * s, char * buf, int len, int timeout) {
	int read = 0;
	int res = 0;
	fd_set readfds;
	struct timeval t;
	if (!s) return -1;
	/* Check for data so we don't block */
	FD_ZERO(&readfds);
	FD_SET(s->sock, &readfds);
	t.tv_sec = timeout / 1000;
	t.tv_usec = (timeout % 1000) * 1000;
	res = select(FD_SETSIZE, &readfds, 0, 0, (timeout < 0) ? 0 : &t);
	if (res < 0) {
		/*** printf("\n\n#################################### Error selecting on socket %d.  Error: %d\n\n", s->sock, twSocket_GetLastError()); ***/
		return res;
	}
	if (res == 0) {
		return 0;
	}
	/* Do our read */
	read = recv(s->sock, buf, len, 0);
	/*** TW_LOG_HEX(buf, "Rcvd Packet: ", read); ***/
	return read;
}

int SysSocket_WaitFor(SysSocket * s, int timeout) {
	fd_set readfds;
	struct timeval t;
	if (!s) return -1;
	/* Check for data so we don't block */
	FD_ZERO(&readfds);
	FD_SET(s->sock, &readfds);
	t.tv_sec = timeout / 1000;
	t.tv_usec = (timeout % 1000) * 1000;
	if (select(FD_SETSIZE, &readfds, 0, 0, (timeout < 0) ? 0 : &t) <= 0) return 0;
	return 1;
}

int SysSocket_Write(SysSocket * s, char * buf, int len, int timeout) {
	if (!s) return -1;
	/*** TW_LOG_HEX(buf, "Sent Packet: ", len);  ***/
	return send(s->sock, buf, len, MSG_NOSIGNAL);
}

int SysSocket_Delete(SysSocket * s) {
	if (!s) return -1;
	SysSocket_Close(s);
	freeaddrinfo(s->addrInfo);
	if (s->host) SYS_FREE(s->host);
	if (s->proxyHost) SYS_FREE(s->proxyHost);
	if (s->proxyPass) SYS_FREE(s->proxyPass);
	if (s->proxyUser) SYS_FREE(s->proxyUser);	
	free(s);
	return  0;
}

int SysSocket_ClearProxyInfo(SysSocket * s) {
	struct addrinfo hints, *p;
	int rval;
	char foundServer = 0;
	char portStr[10];
	foundServer = 1;

	if (!s) return TW_INVALID_PARAM;
	/* CLear out the proxy info */
	if (s->state != CLOSED) SysSocket_Close(s);
	if (s->proxyHost) SYS_FREE(s->proxyHost);
	if (s->proxyUser) SYS_FREE(s->proxyUser);
	if (s->proxyPass) SYS_FREE(s->proxyPass);
	s->proxyHost = NULL;
	s->proxyPort = 0;
	s->proxyUser = NULL;
	s->proxyPass = NULL;

	/* Create the new socket */
	if ((s->host && strcmp(s->host,"")) && s->port) {
		memset(&hints, 0x00, sizeof(hints));
		hints.ai_family = TW_HINTS;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_protocol = IPPROTO_TCP;
		snprintf(portStr, 10, "%u", s->port);
		if ((rval = getaddrinfo(s->host, portStr, &hints, &p)) != 0) {
			return TW_INVALID_PARAM;
		}
		// loop through all the results and connect to the first we can
		s->addrInfo = p;
		for(; p != NULL; p = p->ai_next) {
			if ((s->sock = SysPosixSocket_Create(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
				continue;
			} else {
				foundServer = 1;
				memcpy(&s->addr, p, sizeof(struct addrinfo));
				break;
			}
		}
		if (!foundServer) {
			return TW_INVALID_PARAM;
		}
	}
	s->state = CLOSED;
	return TW_OK;
}


int SysSocket_SetProxyInfo(SysSocket * s, char * proxyHost, uint16_t proxyPort, char * proxyUser, char * proxyPass) {

	struct addrinfo hints, *p;
	int rval;
	char * temp = 0;
	char portStr[10];

	if (!s || !proxyHost || proxyPort == 0) return TW_INVALID_PARAM;
	temp = duplicateString(proxyHost);
	if (!temp) {
		return TW_ERROR_ALLOCATING_MEMORY;
	}
	/* Check the proxy address */
	memset(&hints, 0x00, sizeof(hints));
	hints.ai_family = TW_HINTS;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	snprintf(portStr, 9, "%d", proxyPort);
	if ((rval = getaddrinfo(proxyHost, portStr, &hints, &p)) != 0) {
		return TW_INVALID_PARAM;
	}
	/* Clean up the old address info */
	SysSocket_Close(s);
	freeaddrinfo(s->addrInfo);

	/* loop through all the results and connect to the first we can */
	s->addrInfo = p;
	for(; p != NULL; p = p->ai_next) {
		if ((s->sock = SysPosixSocket_Create(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
			continue;
		} else {
			memcpy(&s->addr, p, sizeof(struct addrinfo));
			break;
		}
	}	
	s->proxyHost = temp;
	s->proxyPort = proxyPort;	
	if (proxyUser) {
		s->proxyUser = duplicateString(proxyUser);
		if (!s->proxyUser) {
			return TW_ERROR_ALLOCATING_MEMORY;
		}
	}
	if (proxyPass) {
		s->proxyPass = duplicateString(proxyPass);
		if (!s->proxyPass) {
			return TW_ERROR_ALLOCATING_MEMORY;
		}
	}
	return 0;
}

int SysSocket_GetLastError() {
	return errno;
}
#endif

/* Tasker Functions */
//pthread_t tickTimerThread = 0;
//char tickSignal = 0;
//int32_t tickRate = TICKS_PER_MSEC;
//unsigned int thread_id = 0;
//
//extern void tickTimerCallback (void * params); /* Defined in tasker.c */
//
//void * TimerThread(void * params) {	
//	while (!tickSignal) {
//		tickTimerCallback(0);
//		twSleepMsec(*(int *)params);
//	}
//	thread_id = 0;
//	return 0;
//}
//
//void SysTasker_Start() {
//	pthread_create(&tickTimerThread, NULL, TimerThread, (void *)&tickRate);
//}
//
//void SysTasker_Stop() {
//	void * status;
//	tickSignal = 1;
//	pthread_join(tickTimerThread, &status);
//}

#ifndef OS_IOS
/* getch */
static struct termios old, new;

/* Initialize new terminal i/o settings */
//void initTermios(int echo)
//{
//	tcgetattr(0, &old); /* grab old terminal i/o settings */
//	new = old; /* make new settings same as old settings */
//	new.c_lflag &= ~ICANON; /* disable buffered i/o */
//	new.c_lflag &= echo ? ECHO : ~ECHO; /* set echo mode */
//	tcsetattr(0, TCSANOW, &new); /* use these new terminal i/o settings now */
//}
//
/* Restore old terminal i/o settings */
//void resetTermios(void)
//{
//	tcsetattr(0, TCSANOW, &old);
//}
//
//char getch()
//{
//	char ch;
//	initTermios(0);
//	ch = getchar();
//	resetTermios();
//	return ch;
//}

int SysDirectory_GetFileInfo(char * filename, uint64_t * size, SYS_DATETIME * lastModified, char * isDirectory, char * isReadOnly) {
	struct stat64 s ;
	if (!filename || !size || !lastModified || !isDirectory || !isReadOnly) return SYS_INVALID_PARAM;
	if (!stat64(filename,&s))  {
		*size = s.st_size;
		*lastModified = ((SYS_DATETIME)s.st_mtime) * 1000;
		*isDirectory = S_ISDIR(s.st_mode );
		*isReadOnly = (s.st_mode & S_IWRITE) ? SYS_FALSE : SYS_TRUE;
		return 0;
	}
	return errno;
}

SYS_DIR SysDirectory_IterateEntries(char * dirName, SYS_DIR dir, char ** name, uint64_t * size, SYS_DATETIME * lastModified, char * isDirectory, char * isReadOnly) {
	/* Variable decalrations */
	struct dirent * entry = NULL;
	char * tmp = NULL;
	int len = 0;
	char * fullpath = NULL;
	int res = 0;
	/* Parameter check */
	if (!dirName || !name || !size || !lastModified || !isDirectory || !isReadOnly) return 0;
	/* Make sure the directory ends with '/' */
	len = strlen(dirName);
	if (len && dirName[len - 1] != '/') {
		tmp = (char *)SYS_CALLOC(len + 2, 1);
		if (!tmp) return 0;
		strcpy(tmp,dirName);
		tmp[len + 1] = '/';	
		dirName = tmp;
	}
	/* If dir is NULL this is the first pass through and we need to open the directory and get the first file */
	if (!dir) {
		/* Need to open the directory */
		dir = opendir(dirName);
		if (!dir) {
			if (tmp) SYS_FREE(tmp);
			return 0;
		}
	} 
	if ((entry = readdir(dir)) == NULL) {
		closedir(dir);
		if (tmp) SYS_FREE(tmp);
		return 0;
	}
	/* Fill in the file info details by creating the fullPath getting the file info */
	fullpath = (char *) SYS_CALLOC(strlen(dirName) + strlen(entry->d_name) + 2, 1);
	if (!fullpath) {
		closedir(dir);
		if (tmp) SYS_FREE(tmp);
		return 0;
	}
	strcpy(fullpath,dirName);
	strcat(fullpath,"/");
	strcat(fullpath,entry->d_name);
	SYS_FREE(tmp);
	res = SysDirectory_GetFileInfo(fullpath, size, lastModified, isDirectory, isReadOnly);
	SYS_FREE(fullpath);
	if (res) {
		closedir(dir);
		return 0;
	}
	*name = duplicateString(entry->d_name);
	return dir;
}

char SysDirectory_FileExists(char * name) {
	struct stat64 s ;
	if (!name) return SYS_FALSE;
	if (!stat64(name,&s)) {
		return SYS_TRUE;
	}
	return SYS_FALSE;
}

int SysDirectory_CreateFile(char * name) {
	FILE * res = NULL;
	if (!name) return SYS_INVALID_PARAM;
	res = fopen(name, "w+");
	if (res == 0) { 
		return errno;
	} 
	fclose(res);
	return 0;
}

int SysDirectory_CopyFile(char * fromName, char * toName) {
	int res = 0;
	
	/* create variable necessary to read and write the file */
	FILE* in_file = NULL;
	FILE* out_file = NULL;
	size_t result = 0;
	char buf[SYS_COPY_BUF_SIZE];

	if (!fromName || !toName) return SYS_INVALID_PARAM;
	
	/* start by deleting the destination file if necessary */
	SysDirectory_DeleteFile(toName);
	
	/* open the input and output files */
	if ( !(in_file = fopen(fromName, "r+")) ) {
		 res = errno;
	} else if ( !(out_file = fopen(toName, "w+")) ) {
		res = errno;
	} else {
		/* 
		read the file into the buffer, write the buffer out to the new file, 
		repeat until all bytes are written 
		*/
		while (0 < (result = fread(buf, 1, SYS_COPY_BUF_SIZE, in_file)) ) {
			if( 0 > (result = fwrite(buf, 1, result, out_file)) ) {
				res = errno;
				break;
			}			
		}	
	}

	/* cleanup buffer and files */
	if (in_file) fclose(in_file);
	if (out_file) fclose(out_file);
	return res;
}

int SysDirectory_MoveFile(char * fromName, char * toName) {
	int res = 0;
	if (!fromName || !toName) return SYS_INVALID_PARAM;
	SysDirectory_DeleteFile(toName);
	/* try to just rename first, because this is faster than a full copy */
	res = rename(fromName, toName);
	/* .if the rename fails, attempt to copy and delete before reporting an error */
	if (res) {
		res = SysDirectory_CopyFile(fromName, toName);
		/* not deleting the file, until we verify that the copy succeeds */
		if (!res) {
			res = SysDirectory_DeleteFile(fromName);
		}
	}
	return res ? errno : 0;
}

int SysDirectory_DeleteFile(char * name) {
	int res = 0;
	if (!name) return SYS_INVALID_PARAM;
	res = remove(name);
	return res ? errno : 0;
}

int SysDirectory_CreateDirectory(char * name) {
	char opath[PATH_MAX];
	char *p;
	size_t len;

	/* if name pointer is null return an error */
	if (!name) {
		return SYS_INVALID_PARAM;
	}

	/* If the directory already exists, nothing to do */
	if (SysDirectory_FileExists(name)) {
		return 0;
	}

	/* make a copy of name, so we can modify the memory later  */
	strncpy(opath, name, sizeof(opath));

	/* check that length is valid and wihtin the bounds of the OS */
	len = strlen(opath);
	if (len == 0 || len >= (PATH_MAX)) {
		return SYS_INVALID_PARAM;
	}

	/* Walk through the path and add all directories that do not exist*/
	for (p = opath; *p; p++) {
		if (*p == '/' || *p == '\\') {
			*p = '\0';
			if (*opath != '\0' && !SysDirectory_FileExists(opath)) {
				if (mkdir(opath, S_IRWXU | S_IRWXG | S_IRWXO)) {
					if (errno != EEXIST) {
						return errno;
					}
				}
			}
			*p = '/';
		} 
	}   

	/* if trailing delimiter is not present, then add last directory */
	if (*p == '\0' && (*(p-1) != '\\' && *(p-1) != '/')) {
		if (!SysDirectory_FileExists(opath)) {
			if (mkdir(opath, S_IRWXU | S_IRWXG | S_IRWXO)) {
				if (errno != EEXIST) {
					return errno;
				}
			}
		}
	}
			
	return 0;
}

int SysDirectory_DeleteDirectory(char * name) {
	int res = 0;
	if (!name) return SYS_INVALID_PARAM;
	res = rmdir(name);
	return res ? errno : 0;
}

int SysDirectory_GetLastError() {
	return errno;
}

#endif

