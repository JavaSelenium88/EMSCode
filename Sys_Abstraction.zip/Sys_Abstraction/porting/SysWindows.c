/*
 *  Copyright 2016, PTC, Inc.
 *
 *  Wrappers for OS Specific functionality
 */

#include "SysOSPort.h"
#include "Systypes.h"
#include "SysLog.h"
//#include "twDefaultSettings.h"
//#include "twHttpProxy.h"
//#include "stringUtils.h"
#ifndef WINCE
#include "process.h"
#endif 
#include "ws2tcpip.h"
#include "time.h"
#ifdef WINCE
#include "timeb_ce.h"
#include "stat_ce.h"
#else /**WIN32**/
#include "sys/timeb.h"
#endif 
#include "errno.h"

/* Logging Function */
void SYS_LOGGING_FUNCTION( enum SysLogLevel level, const char * timestamp, const char * message ) {
	printf("[%-5s] %s: %s\n", SyslevelString(level), timestamp, message);
}

char * SyslevelString(enum SysLogLevel level) {
	switch (level) {
	case SYS_TRACE:
		return "TRACE";
	case SYS_DEBUG:
		return "DEBUG";
	case SYS_INFO:
		return "INFO";
	case SYS_WARN:
		return "WARN";
	case SYS_ERROR:
		return "ERROR";
	case SYS_FORCE:
		return "FORCE";
	case SYS_AUDIT:
		return "AUDIT";
	default:
		return "UNKNOWN";
	}
}

/* Time Functions */
/* FILETIME of Jan 1 1970 00:00:00. */

char SysTimeGreaterThan(SYS_DATETIME t1, SYS_DATETIME t2) {
	return (t1 > t2);
}

char SysTimeLessThan(SYS_DATETIME t1, SYS_DATETIME t2) {
	return (t1 < t2);
}


SYS_DATETIME SysAddMilliseconds(SYS_DATETIME t1, int32_t msec) {
	return t1 + msec;
}

SYS_DATETIME SysGetSystemTime(char utc) {
#ifdef WINCE
	struct _timeb timebuffer;
	_ftime( &timebuffer ); /* C4996 */
	return (SYS_DATETIME)(timebuffer.time * 1000 + timebuffer.millitm);
#else /**WIN32**/
	struct _timeb timebuffer;
	_ftime_s( &timebuffer ); /* C4996 */
	return (SYS_DATETIME)(timebuffer.time * 1000 + timebuffer.millitm);
#endif 
}

uint64_t SysGetSystemMillisecondCount() {
	return (uint64_t)SysGetSystemTime(TRUE);
}

void SysGetTimeString(SYS_DATETIME time, char * s, const char * format, int length, char msec, char utc) {
#ifdef WINCE
	struct tm *timeinfo;
	time_t seconds;
	uint32_t mseconds;
	char millisec[8];
	TIME_ZONE_INFORMATION tz;
	mseconds = time % 1000;
	seconds = time / 1000;
	/* Convert this to a tm struct */
	if (utc)
		timeinfo = localtime(&seconds);
	else {
		timeinfo = gmtime(&seconds);
		GetTimeZoneInformation(&tz);
		if (tz.DaylightBias == -60) {
			timeinfo->tm_isdst = 0;
		} else timeinfo->tm_isdst = 1;
	}
	if (msec) {
		strftime (s,length - 4,format, timeinfo);
		/* append the milliseconds */
		memset(millisec, 0, 8);
		_itoa_s(mseconds, millisec, 4, 10);
		strcat_s(s, length, ",");
		strcat_s(s, length, millisec);
	} else strftime (s,length,format,timeinfo);
#else /**WIN32**/
	struct tm timeinfo;
	time_t seconds;
	uint32_t mseconds;
	char millisec[8];
	TIME_ZONE_INFORMATION tz;
	mseconds = time % 1000;
	seconds = time / 1000;
	/* Convert this to a tm struct */
	if (utc) 
		_localtime64_s(&timeinfo, &seconds);	
	else {
		_gmtime64_s(&timeinfo, &seconds);
		GetTimeZoneInformation(&tz);
		if (tz.DaylightBias == -60) {
			timeinfo.tm_isdst = 0;
		} else timeinfo.tm_isdst = 1;
	}
	if (msec) {
		strftime (s,length - 4,format, &timeinfo);
		/* append the milliseconds */
		memset(millisec, 0, 8);
		_itoa_s(mseconds, millisec, 4, 10);
		strcat_s(s, length, ",");
		strcat_s(s, length, millisec);
	} else strftime (s,length,format,&timeinfo);
#endif 	
}

void SysGetSystemTimeString(char * s, const char * format, int length, char msec, char utc) {
	SYS_DATETIME t;
	t = SysGetSystemTime(utc);
	SysGetTimeString(t, s, format, length, msec, utc);
}

void SysSleepMsec(int milliseconds) {
	  Sleep(milliseconds);
}

/* Mutex Functions */
SYS_MUTEX SysMutex_Create() {
	LPHANDLE hMutex = (LPHANDLE)malloc(sizeof(LPHANDLE));
	if (hMutex) *hMutex = CreateMutex( NULL, FALSE, NULL);  
	return hMutex;
}

void SysMutex_Delete(SYS_MUTEX m) {
	if (m) CloseHandle(*m); 
	SYS_FREE(m);
}

void SysMutex_Lock(SYS_MUTEX m) {
	if (m) WaitForSingleObject(*m, INFINITE); 
}

void SysMutex_Unlock(SYS_MUTEX m) {
	if (m) ReleaseMutex(*m);
}

#ifdef SYS_SOCKET
/* Socket Functions */
uint32_t Sys_openSockets = 0; 
WSADATA wsaData;

SysSocket * SysSocket_Create(const char * host, int16_t port, uint32_t options) {

   struct addrinfo hints, *p;
   int rval;
   char foundServer = 0;
   SysSocket * res = NULL;
   char portStr[10];
   foundServer =1;
   /* Initialize winsock if we need to */
   if (Sys_openSockets++ == 0) {
	   if (WSAStartup(MAKEWORD(2, 0), &wsaData)) return NULL;
   }
   /* Allocate our twSocket */
   res = (SysSocket *)malloc(sizeof(SysSocket));
   if (!res) return 0;
   memset(res, 0, sizeof(SysSocket));

   /* Set up our address structure and any proxy info */
   res->host = duplicateString(host);
   res->port = port;

   /* If we we have a host, try to resolve it */
   if ((host && strcmp(host,"")) && port) {
	   memset(&hints, 0x00, sizeof(hints));
	   hints.ai_family = PF_UNSPEC;
	   hints.ai_socktype = SOCK_STREAM;
	   hints.ai_protocol = IPPROTO_TCP;

		_itoa_s(port, portStr, 9, 10);
		if (rval = getaddrinfo(host, portStr, &hints, &p) != 0) {
			SysSocket_Delete(res);
			return NULL;
		}

		/*loop through all the results and connect to the first we can*/
		  res->addrInfo = p;
		for(; p != NULL; p = p->ai_next) {
			if ((res->sock = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == INVALID_SOCKET ) {
				continue;
			} else {
				foundServer = 1;
				/*res->addr = p;*/
				memcpy(&res->addr, p, sizeof(struct addrinfo));
				break;
			}
		}
		if (!foundServer) {
			SysSocket_Delete(res);
			return NULL;
		}
   }
	res->state = CLOSED;
   return res;
}

int SysSocket_Connect(SysSocket * s) {
	int res;
	char i = 1;
	if (!s) return -1;
	/*setsockopt(s->sock, SOL_SOCKET, SO_REUSEADDR, &i, sizeof(i));*/
	if (res = connect(s->sock, s->addr.ai_addr, s->addr.ai_addrlen) == -1) {
		int err = 0;
		closesocket(s->sock);
		s->sock = INVALID_SOCKET ;
		err = SysSocket_GetLastError();
		return err ? err : -1;
	}
#ifdef ENABLE_HTTP_PROXY_SUPPORT
	if (s->proxyHost && s->proxyPort > 0) {
		res = connectToProxy(s, NULL);
		if (res) {
			return res;
		}
	}
#endif
	s->state = OPEN;
	return res;
}

int SysSocket_Reconnect(SysSocket * s) {
	if (!s) return -1;
	SysSocket_Close(s);
	if ((s->sock = socket(s->addr.ai_family, s->addr.ai_socktype, s->addr.ai_protocol)) == INVALID_SOCKET ) {
		return -1;
	}
	return SysSocket_Connect(s);
}

int SysSocket_Close(SysSocket * s) {
	if (!s) return -1;
	closesocket(s->sock);
	s->sock = INVALID_SOCKET;
	s->state = CLOSED;
	return 0;
}

int SysSocket_Read(SysSocket * s, char * buf, int len, int timeout) {
	int read = 0;
	int res = 0;
	/*int iter = 0;*/
    
	fd_set readfds;
	struct timeval t;
	if (!s) return -1;
	/* Check for data so we don't block */
    FD_ZERO(&readfds);
    FD_SET(s->sock, &readfds);
    t.tv_sec = timeout / 1000;
    t.tv_usec = (timeout % 1000) * 1000;
	res = select(FD_SETSIZE, &readfds, 0, 0, (timeout < 0) ? 0 : &t);
	if (res < 0) {
		/**** printf("\n\n#################################### Error selecting on socket %d.  Error: %d\n\n", s->sock, twSocket_GetLastError()); ***/
		return res;
	}
    if (res == 0) {
		return 0;
	}
	/* Do our read */
	read = recv(s->sock, buf, len, 0);
	/*printf("###DEBUG###\tRcvd Length:\t%d\n###DEBUG###\tData:\t", read);
	for(iter = 0; iter < read; iter++){
		printf("%X ", (unsigned char) buf[iter]);
	}
	printf("\n");*/
	return read;
}

int SysSocket_WaitFor(SysSocket * s, int timeout) {
    fd_set readfds;
	struct timeval t;
	if (!s) return -1;
	/* Check for data so we don't block */
    FD_ZERO(&readfds);
    FD_SET(s->sock, &readfds);
    t.tv_sec = timeout / 1000;
    t.tv_usec = (timeout % 1000) * 1000;
    if (select(FD_SETSIZE, &readfds, 0, 0, (timeout < 0) ? 0 : &t) <= 0) return 0;
	return 1;
}

int SysSocket_Write(SysSocket * s, char * buf, int len, int timeout) {
	if (!s) return -1;
	/*** TW_LOG_HEX(buf, "Sent Packet: ", len);  ***/
	return send(s->sock, buf, len, 0);
}

int SysSocket_Delete(SysSocket * s) {
	if (!s) return -1;
	SysSocket_Close(s);
	freeaddrinfo(s->addrInfo);
	if (s->host) SYS_FREE(s->host);
	if (s->proxyHost) SYS_FREE(s->proxyHost);
	if (s->proxyPass) SYS_FREE(s->proxyPass);
	if (s->proxyUser) SYS_FREE(s->proxyUser);
	SYS_FREE(s);
	if (--Sys_openSockets == 0) {
	   WSACleanup();
	}
	return  0;
}

int SysSocket_GetLastError() {
	return WSAGetLastError();
}

int SysSocket_ClearProxyInfo(SysSocket * s) {
	struct addrinfo hints, *p;
	int rval;
	char foundServer = 0;
	char portStr[10];
	foundServer = 1;

	if (!s) return SYS_INVALID_PARAM;
	/* CLear out the proxy info */
	if (s->state != CLOSED) SysSocket_Close(s);
	if (s->proxyHost) SYS_FREE(s->proxyHost);
	if (s->proxyUser) SYS_FREE(s->proxyUser);
	if (s->proxyPass) SYS_FREE(s->proxyPass);
	s->proxyHost = NULL;
	s->proxyPort = 0;
	s->proxyUser = NULL;
	s->proxyPass = NULL;

	/* Create the new socket */
	if ((s->host && strcmp(s->host,"")) && s->port) {
		memset(&hints, 0x00, sizeof(hints));
		hints.ai_family = PF_UNSPEC;
		hints.ai_socktype = SOCK_STREAM;
		hints.ai_protocol = IPPROTO_TCP;

		_itoa_s(s->port, portStr, 9, 10);
		if (rval = getaddrinfo(s->host, portStr, &hints, &p) != 0) {
			return SYS_INVALID_PARAM;
		}

		// loop through all the results and connect to the first we can
		s->addrInfo = p;
		for(; p != NULL; p = p->ai_next) {
			if ((s->sock = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == INVALID_SOCKET ) {
				continue;
			} else {
				foundServer = 1;
				memcpy(&s->addr, p, sizeof(struct addrinfo));
				break;
			}
		}
		if (!foundServer) {
			return SYS_INVALID_PARAM;
		}
	}
	s->state = CLOSED;
	return SYS_OK;
}

int SysSocket_SetProxyInfo(SysSocket * s, char * proxyHost, uint16_t proxyPort, char * proxyUser, char * proxyPass) {
	
   struct addrinfo hints, *p;
   int rval;
   char * temp = 0;
   char foundServer = 0;
   char portStr[10];
   foundServer = 1;

	if (!s || !proxyHost || proxyPort == 0) return SYS_INVALID_PARAM;
	temp = duplicateString(proxyHost);
	if (!temp) {
		return SYS_ERROR_ALLOCATING_MEMORY;
	}
   /* Check the proxy address */
   memset(&hints, 0x00, sizeof(hints));
   hints.ai_family = PF_UNSPEC;
   hints.ai_socktype = SOCK_STREAM;
   hints.ai_protocol = IPPROTO_TCP;

	_itoa_s(proxyPort, portStr, 9, 10);
	if (rval = getaddrinfo(proxyHost, portStr, &hints, &p) != 0) {
		return SYS_INVALID_PARAM;
	}
	/* Clean up the old address info */
	SysSocket_Close(s);
	freeaddrinfo(s->addrInfo);

    /* loop through all the results and connect to the first we can */
    s->addrInfo = p;
    for(; p != NULL; p = p->ai_next) {
        if ((s->sock = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
            continue;
        } else {
			foundServer = 1;
			memcpy(&s->addr, p, sizeof(struct addrinfo));
			break;
		}
    }	

	s->proxyHost = temp;
	s->proxyPort = proxyPort;	
	if (proxyUser) {
		s->proxyUser = duplicateString(proxyUser);
		if (!s->proxyUser) {
			return SYS_ERROR_ALLOCATING_MEMORY;
		}
	}
	if (proxyPass) {
		s->proxyPass = duplicateString(proxyPass);
		if (!s->proxyPass) {
			return SYS_ERROR_ALLOCATING_MEMORY;
		}
	}
	return 0;
}

#endif

///* Tasker Functions */
//HANDLE tickTimeHandle = 0;
//HANDLE tickSignal = 0;
//int32_t tickRate = TICKS_PER_MSEC;
//unsigned int thread_id = 0;
//
//extern void tickTimerCallback (void * params); /* Defined in tasker.c */
//
//unsigned int _stdcall  WindowsTimerThread(PVOID lpParameter) {	
//	while (WaitForSingleObject(tickSignal, 0 )) {
//		tickTimerCallback(0);
//		twSleepMsec(*(int *)lpParameter);
//	}
//	thread_id = 0;
//	TW_LOG(TW_ERROR, "twWindows.c:WindowsTimerThread is exiting!!!!");
//	return 0;
//}
//
//void SysTasker_Start() {
//	
//	void * event_name = NULL;
//	event_name = TW_MALLOC(MAX_PATH);
//	if(event_name==NULL){
//		TW_LOG(TW_ERROR, "twWindows.c:twTaskerStart error allocating memory");
//		return;
//	}
//	twGetSystemTimeString((char*)event_name, "%Y-%m-%d %H:%M:%S", MAX_PATH, TRUE, TRUE);
//	tickSignal = CreateEvent( 
//			NULL,               // default security attributes
//			TRUE,               // manual-reset event
//			FALSE,              // initial state is nonsignaled
//			(LPCWSTR)event_name				// object name
//        ); 
//	SYS_FREE(event_name);
//#ifdef WINCE
//	tickTimeHandle = (HANDLE)CreateThread(0, 0, &WindowsTimerThread, &tickRate, 0, &thread_id);
//#else /**WIN32**/
//    tickTimeHandle = (HANDLE)_beginthreadex(0, 0, &WindowsTimerThread, &tickRate, 0, &thread_id);
//#endif 
//}
//
//void SysTasker_Stop() {
//	SetEvent(tickSignal);
//	TW_LOG(TW_INFO, "thread_id- %d", thread_id);
//	//while (thread_id) { //TODO: Vishal: Disabled, as it was getting struck here in 64bit. 
//	if(thread_id) {
//		twSleepMsec(tickRate);
//	}
//	CloseHandle(tickSignal);
//	tickSignal = 0;
//}

/* File Transfer */
#ifndef WINCE
#include <sys/stat.h>
#endif 
//#include "stringUtils.h"

wchar_t * SysconvertToWide( const char * in) {
	wchar_t * tmp = NULL;
	size_t outlen = 0;
	if (!in) return 0;
	/* Get the required number of charaters in the buffer */
	outlen = MultiByteToWideChar(CP_UTF8, 0, in, -1, NULL, 0);
	if (!outlen) return NULL;
	tmp = (wchar_t *)SYS_CALLOC(outlen + 1, 2);
	if (!tmp) return NULL;
	outlen = MultiByteToWideChar(CP_UTF8, 0, in, -1, tmp, outlen);
    if (outlen >=0) {
		return tmp;
	}
	SYS_FREE(tmp);
	return NULL;
}

char * SysconvertToMb(const wchar_t * in) {
	char * tmp = NULL;
	size_t outlen = 0;
	if (!in) return NULL;
	/* Get the required number of charaters in the buffer */
	outlen = WideCharToMultiByte(CP_UTF8, 0, in, lstrlenW(in), NULL, 0, NULL, NULL);
	if (!outlen) return NULL;
	tmp = (char *)SYS_CALLOC(outlen + 1, 1);
	if (!tmp) return NULL;
	outlen = WideCharToMultiByte(CP_UTF8, 0, in, lstrlenW(in), tmp, outlen, NULL, NULL);
	if (outlen >= 0) {
		return tmp;
	}
	SYS_FREE(tmp);
	return NULL;
}

SYS_FILE_HANDLE Sys_win_fopen(const char* name, const char* mode){
	SYS_FILE_HANDLE result = NULL;
	wchar_t * w_name = NULL;
	wchar_t * w_mode = NULL;
	w_name = SysconvertToWide(name);
	if (!w_name) return result;
	w_mode = SysconvertToWide(mode);
	if (!w_mode){
		SYS_FREE(w_name);
		return result;
	}
	result = _wfopen(w_name, w_mode);
	SYS_FREE(w_name);
	SYS_FREE(w_mode);
	return result;
}

SYS_DIR SysDirectory_IterateEntries(char * dirName, SYS_DIR dir, char ** name, uint64_t * size, SYS_DATETIME * lastModified, char * isDirectory, char * isReadOnly) {
	/* Variable decalrations */
	WIN32_FIND_DATA ffd;
	uint64_t filetime = 0;
	/* Parameter check */
	if ((!dir && !dirName) || !name || !size || !lastModified || !isDirectory || !isReadOnly) return 0;
	/* If dir is NULL this is the first pass through and we need to get the first file */
	if (!dir) {
		int len = 0;
		char * tmp = NULL;
		wchar_t * n = NULL;
		HANDLE hFind = 0;
		/* Make sure the directory ends with '\*' */
		len = strlen(dirName);
		if (len > 1 && dirName[len - 1] != '*') {
			int i = 1;
			if (dirName[len - 2] != '\\') i++;
			tmp = (char *)SYS_CALLOC(len + i + 1, 1);
			if (!tmp) return 0;
			strcpy(tmp,dirName);
			tmp[len + i - 2] = '\\';
			tmp[len + i - 1] = '*';	
			dirName = tmp;
		}
		n = SysconvertToWide(tmp);
		/* Find the first file in the directory. */
		hFind = FindFirstFileW(n, (LPWIN32_FIND_DATAW)&ffd);
		SYS_FREE(n);
		if (tmp) SYS_FREE(tmp);
		if (INVALID_HANDLE_VALUE == hFind)  {
			return 0;
		} 
		dir = hFind;
	} else {
		if (!FindNextFileW(dir, (LPWIN32_FIND_DATAW)&ffd)) {
			FindClose(dir);
			return 0;
		}
	}
	/* Fill in the file info details */
	filetime = ((uint64_t)ffd.ftLastWriteTime.dwHighDateTime << 32) + ffd.ftLastWriteTime.dwLowDateTime;
	*lastModified = (SYS_DATETIME)(filetime / 10000 - 11644473600000);
	/* Need to convert back to c string */
	*name = SysconvertToMb((const wchar_t *)ffd.cFileName);
	*isReadOnly = (ffd.dwFileAttributes & FILE_ATTRIBUTE_READONLY) ? TRUE : FALSE;
	*size = ((uint64_t)ffd.nFileSizeHigh << 32) + ffd.nFileSizeLow;
	*isDirectory = (ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ? TRUE : FALSE;
	return dir;
}

int SysDirectory_GetFileInfo(char * filename, uint64_t * size, SYS_DATETIME * lastModified, char * isDirectory, char * isReadOnly) {
#ifdef WINCE
	struct stat s;
#else /**WIN32**/
	struct _stat64 s;
#endif 
	wchar_t *n = NULL;
	n = SysconvertToWide(filename);
	
	if (!n || !size || !lastModified || !isDirectory || !isReadOnly) return SYS_INVALID_PARAM;
#ifdef WINCE
	if (!stat(n,&s))  {
#else /**WIN32**/
	if (!_wstat64(n,&s))  {
#endif 
		*size = s.st_size;
		*lastModified = s.st_mtime * 1000;
		*isDirectory = (s.st_mode & _S_IFDIR) ? TRUE : FALSE ;
		*isReadOnly = (s.st_mode & S_IWRITE) ? FALSE : TRUE;
		SYS_FREE(n);
		return 0;
	}
	SYS_FREE(n);
	return GetLastError();
}

char SysDirectory_FileExists(char * name) {
#ifdef WINCE
	struct stat s;
#else /**WIN32**/
	struct _stat64 s;
#endif 
	wchar_t * n = NULL;
	n = SysconvertToWide(name);
	
	if (!n) return FALSE;
#ifdef WINCE
	if (stat(n,&s))  { //TODO:Soumya Check-Orking Ok Now- earlier if(!stat(n,&s))
#else /**WIN32**/
	if (!_wstat64(n,&s))  {
#endif 
		SYS_FREE(n);
		return TRUE;
	}
	SYS_FREE(n);
	return FALSE;
}

int SysDirectory_CreateFile(char * name) {
	HANDLE res = 0;
	wchar_t * n = NULL;
	n = SysconvertToWide(name);
	if (!n) return SYS_INVALID_PARAM;
    res = CreateFileW(n, GENERIC_WRITE | GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);  
	SYS_FREE(n);
    if (res == INVALID_HANDLE_VALUE) { 
        return GetLastError();
    } 
	CloseHandle(res);
	return 0;
}

int SysDirectory_MoveFile(char * fromName, char * toName) {
	int res = 0;
	wchar_t * from = NULL; 
	wchar_t * to = NULL;

	from = SysconvertToWide(fromName);
	if (!from) return SYS_INVALID_PARAM;
	to = SysconvertToWide(toName);
	if (!to){
		SYS_FREE(from);
		return SYS_INVALID_PARAM;
	}
#ifdef WINCE
	res = MoveFile(from, to);
#else /**WIN32**/
    res = MoveFileExW(from, to, MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH);
#endif


	SYS_FREE(from);
	from = NULL;
	SYS_FREE(to);
	to = NULL;
	return res ? 0 : GetLastError();
}

int SysDirectory_DeleteFile(char * name) {
	int res = 0;
	wchar_t * n = SysconvertToWide(name);
	if (!n) return SYS_INVALID_PARAM;
	res = DeleteFileW(n);
	SYS_FREE(n);
	return res ? 0 : GetLastError();
}

int SysDirectory_CreateDirectory(char * name) {
	int res = 0;
	wchar_t * n = SysconvertToWide(name);
	wchar_t opath[MAX_PATH]; 
	wchar_t *p = NULL; 
	size_t len; 
	if (!n) return SYS_INVALID_PARAM;

	/* If the directory already exists, nothing to do */
	if (SysDirectory_FileExists(name)) {
		SYS_FREE(n);
		return 0;
	}
	memset(opath, 0, MAX_PATH);
    wcsncpy(opath, n, MAX_PATH);
	SYS_FREE(n);
    len = wcslen(opath); 
	if (len == 0) return SYS_INVALID_PARAM;
    /* Remove any trainling delimeter*/
    if (opath[len - 1] == L'/' || opath[len - 1] == L'\\') opath[len - 1] = L'\0'; 
	/* Walk through the path */
    for(p = opath; *p; p++) {
        if(*p == L'/' || *p == L'\\') {
           *p = L'\0';
				if (wcslen(opath) && GetFileAttributesW(opath) == -1) {
					if (!CreateDirectoryW(opath, 0)) {
						if (GetLastError() != ENOENT) {
							return GetLastError();
						}
					}
				}
           *p = L'\\';
        }
	}   
	/* Now we can add the desired directory */  
	if (!CreateDirectoryW(opath, 0)){
		res = GetLastError();
		return (res == ERROR_ALREADY_EXISTS) ? 0 : res;
	}
	return 0;
}

int SysDirectory_DeleteDirectory(char * name) {
	int res = 0;
	wchar_t * n = SysconvertToWide(name);
	if (!n) return SYS_INVALID_PARAM;
	res =RemoveDirectoryW(n);
	SYS_FREE(n);
	return res ? 0: GetLastError();
}

int SysDirectory_GetLastError() {
	return GetLastError();
}
