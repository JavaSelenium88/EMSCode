/*
 *  Copyright 2016, PTC, Inc.
 *
 *  Doubly linked list utilities
 */

#include "Systypes.h"
#include "SysList.h"
#include "SysOSPort.h"

#ifdef _DEBUG
//#include "twLogger.h"
//#include "twMessaging.h"
#include "twApi.h"
extern twApi * tw_api;
#endif

SysList * SysList_Create(Sys_del_func delete_function) {
	SysList * list = (SysList *)SYS_CALLOC(sizeof(SysList), 1);
	if (list) {
		list->mtx = SysMutex_Create();
		if (!list->mtx) {
			SysList_Delete(list);
			list = 0;
		}
		list->delete_function = delete_function;
	}
	return list;
}

int SysList_Delete(struct SysList * list) {
	if (list) {
		SysList_Clear(list);
		SysMutex_Delete(list->mtx);
		SYS_FREE(list);
		return SYS_OK;
	}
	return SYS_INVALID_PARAM;
}


int SysList_Clear(struct SysList *list) {
	struct SysListEntry * entry = NULL;
	if (list) {
		SysMutex_Lock(list->mtx);
		entry = list->first;
		while (entry) {
			SysListEntry * tmp = entry->next;
			if (list->delete_function) {
				list->delete_function(entry->value);
			} else SYS_FREE(entry->value);
			SYS_FREE(entry);
			entry = tmp;
		}
		list->count = 0;
		list->first = NULL;
		list->last = NULL;
		SysMutex_Unlock(list->mtx);
		return SYS_OK;
	}
	return SYS_INVALID_PARAM;
}

int SysList_Add(struct SysList *list, void *value) {
	struct SysListEntry * newEntry = NULL;
	if (list) {
		newEntry = (SysListEntry *)SYS_CALLOC(sizeof(SysListEntry), 1);
		if (!newEntry) return SYS_ERROR_ALLOCATING_MEMORY;
		newEntry->value = value;
		/* Find the last entry */
		SysMutex_Lock(list->mtx);
		if (!list->first) {
			/* This will be the first entry in the list */
			list->first = newEntry;
			list->last = newEntry;
			newEntry->prev = NULL;
			newEntry->next = NULL;
		} else {
			newEntry->prev = list->last;
			newEntry->next = NULL;
			list->last->next = newEntry;
			list->last = newEntry;
		}
		list->count++;
		SysMutex_Unlock(list->mtx);
		return SYS_OK;
	}
	return SYS_INVALID_PARAM;
}

int SysList_Remove(struct SysList *list, struct SysListEntry * entry, char deleteValue) {
	struct SysListEntry * node = NULL;
	void * val = NULL;
	if (!list || !entry) return SYS_INVALID_PARAM;
	/* find the entry */
	SysMutex_Lock(list->mtx);
	node = list->first;
	while (node) {
		if (node == entry) { 
			val = node->value;
			if (node == list->first) list->first = node->next;
			if (node == list->last) list->last = node->prev;
			if (node->prev) node->prev->next = node->next;
			if (node->next) node->next->prev = node->prev;
			break;
		}
		node = node->next;
	}
	if (deleteValue && val) {
		if (list->delete_function) {
			list->delete_function(val);
		}
		else SYS_FREE(val);
	}
	SYS_FREE(entry);
	list->count--;
	SysMutex_Unlock(list->mtx);
	return SYS_OK;
}

SysListEntry * SysList_Next(SysList *list, SysListEntry * entry) {
	struct SysListEntry * node = NULL;
	if (!list || list->count == 0) return NULL;
	/* find the entry */
	SysMutex_Lock(list->mtx);
	node = list->first;
	/* If entry is NULL just return the first entry in the list */
	/* seems simple, but if this or the "next" element has been removed, it isn't */
	if (entry) {
		while (node) {
			if (node == entry) { 
				/* the passed in entry still exists */
				node = node->next;
				break;
			}
			node = node->next;
		}
	}
	SysMutex_Unlock(list->mtx);
	return node;
}

SysListEntry * SysList_GetByIndex(struct SysList *list, int index) {
	SysListEntry * le = NULL;
	int count = 0;
	if (!list) return NULL;
	if (index >= list->count) return NULL;
	le = SysList_Next(list, NULL);
	while (le) {
		if (count++ == index) return le;
		le = SysList_Next(list, le);
	}
	return NULL;
}

int SysList_GetCount(struct SysList *list) {
	int count = 0;
	if (list) {
		SysListEntry * le = NULL;
		le = SysList_Next(list, NULL);
		while (le) {
			count++;
			le = SysList_Next(list, le);
		}
	}
	return count;
}

int SysList_ReplaceValue(struct SysList *list, struct SysListEntry * entry, void * new_value, char dispose) {
	struct SysListEntry * node = NULL;
	if (!list || list->count == 0 || !entry) return SYS_INVALID_PARAM;
	/* find the entry */
	SysMutex_Lock(list->mtx);
	node = list->first;
	/* If entry is NULL just return the first entry in the list */
	/* seems simple, but if this or the "next" element has been removed, it isn't */
	if (entry) {
		while (node) {
			if (node == entry) { 
				if (dispose) {
					if (list->delete_function) list->delete_function(node->value);
					else SYS_FREE(node->value);
				}
				node->value = new_value;
				SysMutex_Unlock(list->mtx);
				return SYS_OK;
			}
			node = node->next;
		}
	}
	SysMutex_Unlock(list->mtx);
	return SYS_LIST_ENTRY_NOT_FOUND;
}

//#ifdef _DEBUG
//void twList_CheckTask(DATETIME now, void * params) {
//	static uint32_t callbackListSize = 0;
//	static uint32_t offlineMessageListSize = 0;
//	static uint64_t offlineMessageSize = 0;
//	static uint32_t responseCallbackListSize = 0;
//	static uint32_t requestCallbackListSize = 0;
//	static uint32_t multipartMessageListSize = 0;
//
//	twMessageHandler * tmh = twMessageHandler_Instance((twWs *) NULL);
//
//	if(tw_api && tw_api->mtx) {
//		twMutex_Lock(tw_api->mtx);
//		callbackListSize = twList_GetCount(tw_api->callbackList);
//		offlineMessageListSize = twList_GetCount(tw_api->offlineMsgList);
//		offlineMessageSize = tw_api->offlineMsgSize;
//		twMutex_Unlock(tw_api->mtx);
//	}
//
//	if(tmh && tmh->mtx) {
//		twMutex_Lock(tmh->mtx);
//		requestCallbackListSize = twList_GetCount(tmh->incomingRequestCallbacks);
//		responseCallbackListSize = twList_GetCount(tmh->responseCallbackList);
//		multipartMessageListSize = twList_GetCount(tmh->multipartMessageList);
//		twMutex_Unlock(tmh->mtx);
//	}
//
//	TW_LOG(TW_INFO, "List Sizes: callback list [%lu], offline message list [%lu], offline message size [%lu]",
//			callbackListSize, offlineMessageListSize, offlineMessageSize);
//	TW_LOG(TW_INFO, "List Sizes: requests list [%lu], response list [%lu], multipart list [%lu]",
//		
//	requestCallbackListSize, responseCallbackListSize, multipartMessageListSize);
//}
//#endif
