/***************************************
 *  Copyright 2016, PTC, Inc.
 ***************************************/

/**
 * \file twWindows-openssl.h
 *
 * \brief Wrappers for Windows-specific functionality using OpenSSL
*/

#ifndef SYS_WINDOWS_H
#define SYS_WINDOWS_H

#include "winsock2.h"
#include "windows.h"
#ifndef WINCE
#include "conio.h"
#endif /**WINCE**/
#include "stdio.h"
#ifdef WINCE
#include "ws2tcpip.h"
#endif


#ifdef __cplusplus
extern "C" {
#endif

/**
 * \name TLS Library
*/
/**
 * \brief Define which pluggable TLS library is used.
 *
 * \note The NO_TLS option turns off encryption altogether which may be useful
 * for debugging but is also <b>not recommended for production environments</b>
 * as it may introduce serious security risks.
*/
#define SYS_TLS_INCLUDE "twOpenSSL.h" 

/**
 * \name Logging
*/
#ifndef TW_LEAN_AND_MEAN
/**
 * \brief The maximum size of the log buffer.
*/
#define SYS_LOG_BUF_SIZE 4096
#define SYS_LOG(level, fmt, ...)  twLog(level, fmt, ##__VA_ARGS__)
#define SYS_LOG_HEX(msg, preamble, length)   twLogHexString(msg, preamble, length)
#define SYS_LOG_MSG(msg, preamble)   twLogMessage(msg, preamble)

/**
 * \name Proxies
*/
#define ENABLE_HTTP_PROXY_SUPPORT
#define USE_NTLM_PROXY

#else /* LEAN AND MEAN */
/**
 * \name Lean and Mean Options
 * \brief  Disables logging.  Can also use this to override other resource
 * /code size impacting functions such as file transfer, offline message store,
 * and tunneling
*/
#define SYS_LOG_BUF_SIZE 1
#define SYS_LOG(level, fmt, ...)
#define SYS_LOG_HEX(msg, preamble, length)
#define SYS_LOG_MSG(msg, preamble) 

#undef OFFLINE_MSG_STORE
#define OFFLINE_MSG_STORE 0
#undef  ENABLE_HTTP_PROXY_SUPPORT
#undef USE_NTLM_PROXY
#undef ENABLE_FILE_XFER
#undef ENABLE_TUNNELING
#endif

/**
 * \brief Date/time definition
*/
typedef DWORD64 SYS_DATETIME;

/**
 * \brief For Windows builds #TW_MUTEX is a LPHANDLE */
#define SYS_MUTEX LPHANDLE

/**
 * \name Sockets
*/
#define IPV4 AF_INET
#define IPV6 AF_INET6
#define SYS_SOCKET_TYPE int
#define SYS_ADDR_INFO struct addrinfo

/**
 * \name Tasks
*/
#define TICKS_PER_MSEC 1

/**
 * \name Memory
*/
#define SYS_MALLOC(a) malloc(a) 
#define SYS_CALLOC(a, b) calloc(a,b)
#define SYS_REALLOC(a, b) realloc(a, b)
#define SYS_FREE(a) free(a)

/**
 * \name File Transfer
*/
#define SYS_FILE_HANDLE			FILE*
#define SYS_FILE_DELIM			'\\'
#define SYS_FILE_DELIM_STR		"\\"
#define SYS_FILE_CASE_SENSITVE	FALSE
#define SYS_DIR					HANDLE 

SYS_FILE_HANDLE					 Sys_win_fopen(const char* name, const char* mode);
#define SYS_FOPEN(a,b)			 Sys_win_fopen(a,b)
#define SYS_FCLOSE(a)			 fclose(a)
#define SYS_FREAD(a,b,c,d)		 fread(a,b,c,d)
#define SYS_FWRITE(a,b,c,d)		 fwrite(a,b,c,d)
#ifdef WINCE
 #define SYS_FSEEK(a,b,c)		 fseek(a,b,c)
 #define SYS_FTELL(a)			 ftell(a)
#else
 #define SYS_FSEEK(a,b,c)		 _fseeki64(a,b,c)
#define SYS_FTELL(a)			 _ftelli64(a)
#endif
#define SYS_FERROR(a)			 ferror(a)

/**
 * \name Threads
*/
#define SYS_THREAD_ID HANDLE  

/**
 * \name Misc
*/
/**
 * \brief Use __forceinline (VC++ specific).
*/
#define INLINE __forceinline
#define snprintf   _snprintf

#ifdef __cplusplus
}
#endif

#endif
