//*****************************************************************************
//
//  Copyright � 2018 ITC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  EMS_Helper.c
//  
//  Subsystem  :  Keysight_EMSHelper
//
//  Description:  Receiving request from Keysight and sending last input timestamp 
//
//*****************************************************************************

#define WIN32_LEAN_AND_MEAN

#include <winsock2.h>
#include <ws2tcpip.h>
#include <signal.h>
#include <ctype.h>
#include <time.h>
#include "EMS_Helper.h"
#include "OS_Utilities.h"


Sys_Int INTR_FLAG = 1;
SOCKET ListenSocket = INVALID_SOCKET;
Sys_Int ClientSocket[MAX_CLIENT];
Sys_Int new_socket = INVALID_SOCKET;

//***********************************Thread*****************************


LastInputCodes GetLastInputTimeUTC(Sys_Char *timebuf) {

	Sys_Char *function = "GetLastInputTimeUTC()";
	SysAppLog(SYS_INFO, MODULE_KEYHOOKS, "%s: Entered", function);
	LASTINPUTINFO last_info;
	last_info.cbSize = sizeof(last_info);
	last_info.dwTime = 0;
	Sys_Int ret = LASTINPUT_SUCCESS;
	DWORD tickCount;
	Sys_Int idleTicks = 0,diff=0;
	time_t now, lastTime;
	struct tm tms;
	
	ret = GetLastInputInfo(&last_info); //Retrieves the time of the last input event.
	if (ret == 0) {  //returns 0 on error
		SysAppLog(SYS_ERROR, MODULE_KEYHOOKS, "%s: GetLastInputInfo is failed with error: %d", function, WSAGetLastError());
		ret = LASTINPUT_FAILED;
	}
	else{
		tickCount = GetTickCount(); //Retrieves the number of milliseconds that have elapsed since the system was started, up to 49.7 days.
		now = time(0); //returns the current time of the system as a time_t value
		if (tickCount >= MAX_DAYS_IN_MSEC)
			SysAppLog(SYS_INFO, MODULE_KEYHOOKS, "%s: The value of tickCount is going to reach to 49.7 days, timer will be reset soon.", function);
		idleTicks = (tickCount - last_info.dwTime) / 1000;
		lastTime = (now - idleTicks); 
		diff = (Sys_Int)(lastTime - lastTickTime); //sometimes if system is idle, lastTime changes +/- 1 second, so fixing that
		if (diff == 1 || diff == -1) {
			//strcpy(timebuf, prevTime);
			Sys_StringnCpy(timebuf, prevTime, strlen(prevTime), strlen(prevTime) + 1); //warning fixes
			ret = LASTINPUT_SUCCESS;
		}
		else {
			//tms = *gmtime(&lastTime); //converts a time_t value to Coordinated Universal Time
			gmtime_s(&tms, &lastTime); //warning fixes
			//sprintf(timebuf, "%04d-%02d-%02d %02d:%02d:%02d", tms.tm_year + 1900, tms.tm_mon + 1, tms.tm_mday, tms.tm_hour, tms.tm_min, tms.tm_sec);
			sprintf_s(timebuf, sizeof(tms),"%04d-%02d-%02d %02d:%02d:%02d", tms.tm_year + 1900, tms.tm_mon + 1, tms.tm_mday, tms.tm_hour, tms.tm_min, tms.tm_sec);
			lastTickTime = lastTime;
			memset(prevTime, 0, DEFAULT_BUFLEN);
			//strcpy(prevTime, timebuf);
			Sys_StringnCpy(prevTime, timebuf, strlen(timebuf), strlen(timebuf) + 1);  //warning fixes
			ret = LASTINPUT_SUCCESS;
		}
	}
	SysAppLog(SYS_INFO, MODULE_KEYHOOKS, "%s: Exited", function);
	return ret;
}

DWORD WINAPI  ThreadFunc(void* data) {

	Sys_Char *function = "ThreadFunc()";
	Sys_Char sendBuf[DEFAULT_BUFLEN];
	Sys_Char ackVal[1];
	Sys_Int iResult = 0;
	Sys_Int ret = LASTINPUT_SUCCESS;
	Sys_Int threadRetrun = SOCKET_SUCCESS;
	Sys_Int iSendResult = 0;
	Sys_Char *inputTime = NULL;  //variable for storing Timestamp
	fd_set readfds;
	Sys_Int max_sd=0, i=0, sd=0, activity=0;


	SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Entered", function);
	inputTime = (Sys_Char *)Sys_Malloc(DEFAULT_BUFLEN);
	if (inputTime == NULL) {
		SysAppLog(SYS_ERROR, MODULE_KEYHOOKS, "%s: Error in allocating memory", function);
		threadRetrun = KEYHOOK_INSUFFICIENT_MEMORY;
	}
	SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Waiting for new connection....", function);

	if (threadRetrun != KEYHOOK_INSUFFICIENT_MEMORY) {
		while (INTR_FLAG) {
			ackVal[0] = 'n';  //revc buffer value
			ret = LASTINPUT_SUCCESS;

			//clear the socket set
			FD_ZERO(&readfds);

			//add master socket to set
			FD_SET(ListenSocket, &readfds);
			//max_sd = ListenSocket;

			//add child sockets to set
			for (i = 0; i < MAX_CLIENT; i++)
			{
				//socket descriptor
				sd = ClientSocket[i];

				//if valid socket descriptor then add to read list
				if (sd > 0)
					FD_SET(sd, &readfds);

				//highest file descriptor number, need it for the select function
				if (sd > max_sd)
					max_sd = sd;
			}
			//wait for an activity on one of the sockets , timeout is NULL , so wait indefinitel,fixing AA-1792
			activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);

			if ((activity < 0) && (errno != EINTR))
			{
				SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Select failed with error: %d", function, WSAGetLastError());
				threadRetrun = SOCKET_SELECT_ERROR;
			}

			//If something happened on the master socket , 
			//then its an incoming connection 
			if (FD_ISSET(ListenSocket, &readfds) && (threadRetrun != SOCKET_SELECT_ERROR)) {
				new_socket = accept(ListenSocket, NULL, NULL);
				if (new_socket < 0) {
					SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Accept failed with error: %d", function, WSAGetLastError());
					closesocket(new_socket);
					threadRetrun = SOCKET_ACCEPT_ERROR;
				}
				else {
					SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Accept success", function);
					
					//add new socket to array of sockets
					for (i = 0; i < MAX_CLIENT; i++)
					{
						//if position is empty
						if (ClientSocket[i] == 0)
						{
							ClientSocket[i] = new_socket;
							SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Adding to list of sockets as %d", function, i);
							break;
						}
					}
				}
			}
			//if its some IO operation on some other socket 
			for (i = 0; i < MAX_CLIENT; i++)
			{
				sd = ClientSocket[i];
				ackVal[0] = 'n';
				if (FD_ISSET(sd, &readfds))
				{
					iResult = recv(sd, ackVal, sizeof(ackVal), 0);
					if (iResult > 0) {
						SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Request received from Keysight_EMS_Agent at socket %d", function, i);
						ret = GetLastInputTimeUTC(inputTime);
						if (ret != LASTINPUT_SUCCESS) {
							SysAppLog(SYS_ERROR, MODULE_KEYHOOKS, "%s: GetLastInputTimeUTC is failed", function);
							threadRetrun = KEYHOOK_TIMESTAMP_ERROR;
						}
						else {
							SysAppLog(SYS_INFO, MODULE_KEYHOOKS, "%s: GetLastInputTimeUTC is success", function);
						}
					}
					else if (iResult == 0) {
						SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Connection closed for socket %d.", function, i);
						SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Waiting for new connection....", function);
						ClientSocket[i] = 0;
					}
					else {
						SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Recv failed with error %d at socket %d", function, WSAGetLastError(), i);
						SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Closing connection for soket.... %d.", function, i);
						iResult = 0;
						//Close the socket and mark as 0 in list for reuse 
						closesocket(sd);
						ClientSocket[i] = 0;
						threadRetrun = SOCKET_RECV_ERROR;
					}

					if (ackVal[0] == 'y' && threadRetrun != KEYHOOK_TIMESTAMP_ERROR) {
						memset(sendBuf, '\0', DEFAULT_BUFLEN);
						//strcpy(sendBuf, keyhook);
						//strcat(sendBuf, "#");
						//strcat(sendBuf, mousehook);
						//strcpy(sendBuf, inputTime);
						Sys_StringnCpy(sendBuf, inputTime, strlen(inputTime), strlen(inputTime) + 1);
						iSendResult = send(sd, sendBuf, DEFAULT_BUFLEN, 0);  //buf len should same in both rx and tx for garbeg avoidance
						if (iSendResult == SOCKET_ERROR) {
							SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Send failed with error %d at socket %d", function, WSAGetLastError(), i);
							SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Closing connection for socket %d.", function, i);
							iResult = 0;
							//Close the socket and mark as 0 in list for reuse 
							closesocket(sd);
							ClientSocket[i] = 0;
							threadRetrun = SOCKET_SEND_ERROR;
						}
						else {
							SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Request has been served to Keysight_EMS_Agent with last input timestamp:%s", function, sendBuf);
						}
					}
				}
			}
			
		}
	}
	if (inputTime) {
		Sys_Free(inputTime);
		inputTime = NULL;
	}
	WSACleanup();
	SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Exited", function);

	return threadRetrun;
}

SocketErrCodes SocketInit(Sys_Char *port) {

	Sys_Char *function = "SocketInit()";
	WSADATA wsaData;
	Sys_Int iResult = 0;
	Sys_Int retSockInit = SOCKET_SUCCESS;
	struct addrinfo *result = NULL;
	struct addrinfo hints;
	Sys_Int recvBuflen = DEFAULT_BUFLEN;
	SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Entered", function);
	// Initialize Winsock
	iResult = WSAStartup(MAKEWORD(2, 2), &wsaData);
	if (iResult != 0) {
		SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: WSAStartup failed with error: %d", function, iResult);
		retSockInit = SOCKET_STARTUP_ERROR;
	}

	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;
	hints.ai_flags = AI_PASSIVE;

	// Resolve the server address and port
	if (iResult == 0) {
		iResult = getaddrinfo(NULL, port, &hints, &result);
		if (iResult != 0) {
			SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Getaddrinfo failed with error: %d,please check for port.", function, iResult);
			WSACleanup();
			retSockInit = SOCKET_ADDR_ERROR;
		}
	}

	//initialise all client_socket[] to 0 so not checked 
	memset(ClientSocket, 0, MAX_CLIENT);

	// Create a SOCKET for connecting to server
	if (iResult == 0) {
		ListenSocket = socket(result->ai_family, result->ai_socktype, result->ai_protocol);
		if (ListenSocket == INVALID_SOCKET) {
			SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Socket failed with error: %ld", function, WSAGetLastError());
			freeaddrinfo(result);
			WSACleanup();
			retSockInit = SOCKET_CREATE_ERROR;
		}
	}

	// Setup the TCP listening socket
	if (ListenSocket != INVALID_SOCKET) {
		iResult = bind(ListenSocket, result->ai_addr, (Sys_Int)result->ai_addrlen);
		if (iResult == SOCKET_ERROR) {
			SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Bind failed with error: %d", function, WSAGetLastError());
			freeaddrinfo(result);
			closesocket(ListenSocket);
			WSACleanup();
			retSockInit = SOCKET_BIND_ERROR;
		}
	}

	if (retSockInit != SOCKET_BIND_ERROR) {
		iResult = listen(ListenSocket, SOMAXCONN);
		if (iResult == SOCKET_ERROR) {
			SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Listen failed with error: %d", function, WSAGetLastError());
			closesocket(ListenSocket);
			freeaddrinfo(result);
			//INTR_FLAG = 0;
			retSockInit = SOCKET_LISTEN_ERROR;
		}
	}
	freeaddrinfo(result);
	if (ListenSocket != INVALID_SOCKET) {
		SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Server Socket created..!!", function);
	}
	else
		SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Unable to create Server Socket..!!", function);

	SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Exited", function);
	return retSockInit;
}



SocketErrCodes __cdecl main(Sys_Int argc, Sys_Char **argv)
{
	ShowWindow(GetConsoleWindow(), SW_HIDE);
	Sys_Int res = HOOK_SUCCESS;
	static  Sys_Char *STR_LOG_FILE_NAME = "Keysight_EMSHelper.log";
	static  Sys_Char *LOGGER_FOLDER_NAME = "Logs";
	Sys_Char *function = "main()";
	//MSG message;
	HANDLE thread;
	Sys_Int iResult = 0;
	Sys_Char *port = NULL;
	Sys_Int i = 0;
	Sys_Int length = 0;
	Sys_Int digit = 0; //for checking if port is numeric or not
	Sys_Int range = 0; // for checking port range
	SysLogErrCodes sysLogRetVal = SYSLOG_SUCCESS;

	Sys_Char *pszLoggFilePath = GetFilePathByName(LOGGER_FOLDER_NAME, STR_LOG_FILE_NAME);
	sysLogRetVal = SysLog_Init(pszLoggFilePath);
	if (sysLogRetVal != SYSLOG_SUCCESS) {
		SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: SysLog_Init() failed!", function);
		res = KEYHOOK_SYS_LOG_FAILURE;
	}
	SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Entered", function);
	signal(SIGINT, IntHandler);
	port = argv[1];
	switch (argc) {
	case 1: port = "27015";
		SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: The socket will be connnected to default port: %s", function, port);
		break;
	case 2: range = atoi(argv[1]);
		
		length = strlen(port);
		for (i = 0; i < length; i++) {
			digit = isdigit(port[i]);
			if (!digit) {
				SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Port must be a positive number.", function);
				res = HOOK_ARGUMENT_ERROR;
				break;
			}
		}
		if (res != HOOK_ARGUMENT_ERROR) {
			if (range < 1024 || range > 49151) {
				SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Port should be in range of 1024 to 49151", function);
				res = HOOK_ARGUMENT_ERROR;
			}
			else
				SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: The socket will be connected to port ..%s", function, port);
		}
			break;
	default : 
		SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Too many arguments supplied", function);
		res = HOOK_ARGUMENT_ERROR; 
		break;

	}
	if (res == HOOK_SUCCESS && res != KEYHOOK_SYS_LOG_FAILURE) {
		//Initailizing socket
		res = SocketInit(port);
		if (res != SOCKET_SUCCESS)//checking return value of Sock_Init()
			SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Error in initailizing socket", function);
		else
			SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Success in initailizing socket", function);
	}
	if (res == SOCKET_SUCCESS) {   //if socket_init success then only enter inside if					   
		//res = CreateKMhook();		//Creating keyhooks
		//if (res != HOOK_SUCCESS)
		//	SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Error in initailizing key & mouse hooks", function);
		//else
		//	SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Success in intializing key & mouse hooks", function);

		//creating thread
		thread = CreateThread(NULL, 0, ThreadFunc, NULL, 0, NULL);
		if (thread) {
			SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Thread created with id-%d", function, thread);
		}
		else
			SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Thread could not be created", function);

		//bRet = GetMessage(&message, NULL, 0, 0);

	/*	while (INTR_FLAG)
		{
			PeekMessage(&message, NULL, 0, 0, PM_REMOVE);
			TranslateMessage(&message);
			DispatchMessage(&message);
			Sleep(10);
		}*/

	
		WaitForSingleObject(thread, INFINITE);
		//DestroyKMhook();
	}
	SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Exited", function);
	SysLog_Uninit();
	return res;
}

void  IntHandler(Sys_Int sig)
{
	Sys_Char *function = "IntHandler()";
	Sys_Int iResult = 0;
	SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Entered", function);
	INTR_FLAG = 0; //To break the While loop

	SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Interrupt handled, Closing socket...", function);
	closesocket((SOCKET)ClientSocket);
	iResult = shutdown((SOCKET)ClientSocket, SD_BOTH);
	if (iResult == SOCKET_ERROR) {
		SysAppLog(SYS_ERROR, MODULE_SOCKET, "%s: Shutdown failed with error: %d", function, WSAGetLastError());
		WSACleanup();
	}
	else
		SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Shutdown success", function);

	SysAppLog(SYS_INFO, MODULE_SOCKET, "%s: Exited", function);
}

//
//HookErrCodes CreateKMhook() {
//
//	Sys_Char *function = "CreateKMhook()";
//	HookErrCodes retVal = HOOK_SUCCESS;
//	SysAppLog(SYS_INFO, MODULE_KEYHOOKS, "%s: Entered", function);
//	hKeyboardHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyboardProc, NULL, 0);
//
//	if (hKeyboardHook == NULL)
//	{
//		retVal = HOOK_KEY_ERROR;
//		SysAppLog(SYS_ERROR, MODULE_KEYHOOKS, "%s: Key Hook could not be install", function);
//		return retVal;
//	}
//	else {
//		SysAppLog(SYS_INFO, MODULE_KEYHOOKS, "%s: Key Hook installed", function);
//	}
//
//	hMouseHook = SetWindowsHookEx(WH_MOUSE_LL, MouseEvent, NULL, 0);
//
//	if (hMouseHook == NULL)
//	{
//		retVal = HOOK_MOUSE_ERROR;
//		SysAppLog(SYS_ERROR, MODULE_KEYHOOKS, "%s: Mouse Hook could not be install", function);
//		return retVal;
//	}
//	else {
//		SysAppLog(SYS_INFO, MODULE_KEYHOOKS, "%s: Mouse Hook installed", function);
//	}
//	SysAppLog(SYS_INFO, MODULE_KEYHOOKS, "%s: Exited", function);
//	return retVal;
//}