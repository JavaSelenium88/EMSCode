#ifndef __SYS_API_H__
#define __SYS_API_H__

#include <stdio.h>
#include <string.h>
#include "Systypes.h"
#include <stdlib.h>


#define TIMESTMAMP_LENGTH 80

#ifdef __cplusplus
extern "C" {
#endif

/** Return the minimum of two values */
#define SYS_MIN(a, b) ((a) < (b) ? (a) : (b))

/** Return the maximum of two values */
#define SYS_MAX(a, b) ((a) > (b) ? (a) : (b))

/** Return the absolute value. */
#define SYS_ABS(a)    ((a) < 0 ? -(a) : (a))

/** Return the sign. */
#define SYS_SIGN(a)   ((a) < 0 ? -1 : 1)

/* Default string operations */
#define Sys_StringLength(s)	strlen(s)
#define Sys_StringCmp(s1, s2)        strcmp(s1, s2)
#define Sys_StringnCmp(s1, s2, n)    strncmp(s1, s2, n)
#define Sys_StringChr(s, c)          strchr(s, c)
#define Sys_StringStr(s, sub)        strstr(s, sub)
#define Sys_StringTok(s1, s2)        strtok(s1, s2)
#ifdef WIN32
#define Sys_StrDup(s)				 _strdup(s)
#else
#define Sys_StrDup(s)				 strdup(s)
#endif



//Sys_Ret_t Sys_StringDup(Sys_Char *pszDest, const Sys_Char *pszSource);

/* Custom string operations */
/** \brief String copy.
 *
 * Copies the `Src` to `Dest`. This version of string copy is safe to use,
 * since the returned string is always null terminated, unlike the standard
 * 'strncpy' versions. The behaviour of passing NULL as the `Src` or `Dest`
 * is undefined.
 *
 * \note `Size` parameter is NOT the same as the last parameter provided in
 * the standard 'strncpy' function. It is different in the sense that it
 * specifies the size of `Dest` buffer and NOT the number of characters to
 * copy. So if, for example, `Size` is specified as 2, then only one
 * character will be copied leaving the other one to terminate the string.
 *
 * \param[out] Dest Buffer to copy the string to. This buffer is always null
 * terminated on return.
 *
 * \param[in] Src Zero-terminated string to copy from.
 *
 * \param[in] Size Size of the `Dest` buffer. If this is zero, SYS_EINVAL is
 * returned.
 *
 * \return Returns one of the following values indicating if the copy is
 * successful or not.
 *
 * \retval SYS_RET_OK Copy is successfull.
 *
 * \retval SYS_EINVAL `Size` is 0 or `Src` string could not fit within
 * the `Dest` buffer and hence was truncated.
 */
Sys_Ret_t Sys_StringCpy(Sys_Char * Dest, const Sys_Char * Src,
	Sys_Size_t Size); //TODO: Vishal: It's crashing, if source and dest length are same. Ideally it should truncate a char and put \0. Test it.

/** \brief Fixed size string copy.
 *
 * Copies the `Src` to `Dest`. This version of string copy is safe to use,
 * since the returned string is always null terminated, unlike the standard
 * 'strncpy' versions. The behaviour of passing NULL as the `Src` or
 * `Dest` is undefined.
 *
 * \note `DestSize` specifies the size of the destination buffer and
 * `NumChars` specifies the number of characters to copy.
 *
 * \param[out] Dest Buffer to copy the string to. This buffer is always null
 * terminated on return.
 *
 * \param[in] Src Zero-terminated string to copy from.
 *
 * \param[in] NumChars Number of characters required to be copied.
 *
 * \param[in] DestSize Size of the `Dest` buffer. If this is zero, SYS_EINVAL
 * is returned.
 *
 * \return Returns one of the following values indicating if the copy is
 * successful or not.
 *
 * \retval SYS_RET_OK Copy is successfull.
 *
 * \retval SYS_EINVAL `Size` is 0 or `NumChars` could not fit within the
 * `Dest` buffer and hence was truncated.
 */
Sys_Ret_t Sys_StringnCpy(Sys_Char * Dest, const Sys_Char * Src,
	Sys_Size_t NumChars, Sys_Size_t DestSize);

/** \brief Case insensitive string compare.
 *
 * Compare the given strings without considering the case.
 *
 * \param[in] Str1 Zero-terminated first string.
 *
 * \param[in] Str2 Zero-terminated second string.
 *
 * \return The return value indicates the relationship between the
 * strings. Return value < 0 implies `Str1` less than `Str2`. Return value
 * 0 implies `Str1` identical to `Str2`. Return value > 0 implies `Str1`
 * greater than `Str2`.
 */
Sys_Int Sys_StringCaseCmp(const Sys_Char* Str1, const Sys_Char* Str2);

/** \brief Case insensitive string compare.
 *
 * Compare the given strings upto the specified number of characters
 * without considering the case.
 *
 * \param[in] Str1 First string.
 *
 * \param[in] Str2 Second string.
 *
 * \param[in] Count Number of characters to compare.
 *
 * \return The return value indicates the relationship between the
 * strings. Return value < 0 implies `Str1` less than `Str2`. Return value
 * 0 implies `Str1` identical to `Str2`. Return value > 0 implies `Str1`
 * greater than `Str2`.
 */
Sys_Int Sys_StringnCaseCmp(const Sys_Char* Str1, const Sys_Char* Str2,
	Sys_Int Count);

/** \brief String concatenation.
 *
 * Concatenates the `Src` to `Dest`. This version of string concatenation is
 * safe to use, since the returned string is always null terminated, unlike
 * the standard 'strncat' versions. The behaviour of passing NULL as the
 * `Src` or `Dest` is undefined.
 *
 * \note `Size` parameter is not the same as the last parameter provided in
 * the standard 'strncat' function. It is different in the sense that it
 * specifies the size of `Dest` buffer and NOT the number of characters to
 * concatenate to the end of `Dest`.
 *
 * \param[out] Dest Zero-terminated string to which the `Src` string is
 * concatenated. This buffer is always null terminated on return.
 *
 * \param[in] Src Zero-terminated string to concatenate.
 *
 * \param[in] Size Size of the `Dest` buffer. If this is zero, SYS_EINVAL is
 * returned.
 *
 * \return Returns one of the following values indicating if the concatenation
 * is successful or not.
 *
 * \retval SYS_RET_OK Concatenation is successfull.
 *
 * \retval SYS_EINVAL `Size` is 0 or `Src` string could not fit within
 * the remaining space of `Dest` buffer and hence was truncated.
 */
Sys_Ret_t Sys_StringCat(Sys_Char * Dest, const Sys_Char * Src, Sys_Size_t Size);

/** Function to return timestamp in  < yyyy-mm-dd hh-mm-ss > format
*  SYS_TIME leght should be equal to or more than TIMESTMAMP_LENGTH */
//Sys_Ret_t  Sys_GetTimeStamp(Sys_Char *SYS_TIME);
Sys_Ret_t  Sys_GetTimeStamp(char * s, const char * format, int length, char msec, char utc);

/** Function to populate freeSpace variable with available free space in location provided by diskPath
*/
Sys_Ret_t Sys_GetFreeDiskSpace(Sys_Char *diskPath, Sys_Ullong *freeSpace);

/* Deafult malloc implementation. */
#define Sys_Malloc(n)          malloc(n)
#define Sys_Calloc(n)          calloc(1, n)
#define Sys_Realloc(x,y)       realloc(x,y)
#define Sys_Free(p)            free(p)

/* Deafult memory operations. */
#define Sys_Memset(d, v, sz)   memset(d, v, sz)
#define Sys_Memcpy(d, s, sz)   memcpy(d, s, sz)
#define Sys_Memcmp(s1, s2, sz) memcmp(s1, s2, sz)
#define Sys_Memmove(d, s, sz)  memmove(d, s, sz)

/* File operations*/
#ifndef WINCE
#ifdef WIN32 /* Windows */
#define Sys_File_Handle			FILE*

#define Sys_Fopen(a,b)			Sys_win_fopen(a,b)
#define Sys_Fclose(a)			fclose(a)
#define Sys_Fread(a,b,c,d)		fread(a,b,c,d)
#define Sys_Fwrite(a,b,c,d)		fwrite(a,b,c,d)
#define Sys_Fseek(a,b,c)		_fseeki64(a,b,c)
#define Sys_Ftell(a)			_ftelli64(a)
#define Sys_Ferror(a)			ferror(a)


#else /* Linux */
#define Sys_File_Handle			FILE*

#define Sys_Fopen(a,b)			fopen(a,b)
#define Sys_Fclose(a)			fclose(a)
#define Sys_Fread(a,b,c,d)		fread(a,b,c,d)
#define Sys_Fwrite(a,b,c,d)		fwrite(a,b,c,d)
#define Sys_Fseek(a,b,c)		fseeko(a,b,c)
#define Sys_Ferror(a)			ferror(a)
#define Sys_Ftell(a)			ftell(a)


#endif
#else /* WINCE */
#define Sys_File_Handle FILE*

#define Sys_Fopen(a,b)			win_fopen(a,b)
#define Sys_Fclose(a)			fclose(a)
#define Sys_Fread(a,b,c,d)		fread(a,b,c,d)
#define Sys_Fwrite(a,b,c,d)		fwrite(a,b,c,d)
#define Sys_Fseek(a,b,c)		fseek(a,b,c)
#define Sys_Ftell(a)			ftell(a)
#define Sys_Ferror(a)			ferror(a)

#endif


/* Default math operations */
#ifndef SYS_DISABLE_DEFAULT_MATHOP
#define Sys_Fabs(val)            fabs(val)
#define Sys_Floor(val)           floor(val)
#define Sys_Ceil(val)            ceil(val)
#define Sys_Fmod(Num, Den)       fmod(Num, Den)
#define Sys_Sqrt(val)            sqrt(val)
#define Sys_Pow(x, y)            pow(val)
#define Sys_Sin(val)             sin(val)
#define Sys_Cos(val)             cos(val)
#define Sys_Tan(val)             tan(val)
#define Sys_Asin(val)            asin(val)
#define Sys_Acos(val)            acos(val)
#define Sys_Atan(Val)            atan(Val)
#define Sys_Atan2(Num, Den)      atan2(Num, Den)
#define Sys_Log(val)             log(val)
#define Sys_Log10(val)           log10(val)
#define Sys_ToRad(val)           (val * SYS_PI / 180.0)
#define Sys_ToDeg(val)           (val * 180.0 / SYS_PI)
#ifdef WIN32
#define Sys_Getch()				 _getch()
#else
#define Sys_Getch()               getch()
#endif /**WIN32**/
#endif

#ifdef __cplusplus
}
#endif

#endif /* __SYS_API_H__ */
