/***************************************
 *  Copyright 2016, PTC, Inc.
 ***************************************/

/**
 * \file twOSPort.h
 * \brief Wrappers for OS-specific functionality
*/

#ifndef SYS_OS_PORT_H
#define SYS_OS_PORT_H
#ifndef WINCE
#include <stdint.h>
#else /**WINCE**/
#include <stdint_ce.h>
#endif 
#include <stdlib.h>
#ifdef WINCE
//#define TW_OS_INCLUDE "SysWindows-openssl.h"
#endif 
//#include "twConfig.h"
//#include "twDefaultSettings.h"
//#include "twDefinitions.h"
#ifdef WIN32
#include "SysWindows-openssl.h"
#else
#include "SysLinux-openssl.h"
#endif
//#include "twLogger.h"

#ifdef __cplusplus
extern "C" {
#endif

/**
 * \name Logging functions
*/
/**
 * \brief See twLogger.h.
*/
enum SysLogLevel;
/**
 * \brief See twLogger.h.
*/
char * SyslevelString(enum SysLogLevel level);
/**
 * \brief See twLogger.h.
*/
void SYS_LOGGING_FUNCTION( enum SysLogLevel level, const char * timestamp, const char * message );

/**
 * \name Time Functions
 *
 * \brief Time is represented as a 64 bit value representing milliseconds since
 * the epoch.
*/
/**
 * \brief Compares two #DATETIME variables to see if one is greater.
 *
 * \param[in]     t1        The #DATETIME to compare against.
 * \param[in]     t1        The #DATETIME to compare with.
 *
 * \return #TRUE if t1 > t2, #FALSE otherwise.
*/ 
char SysTimeGreaterThan(SYS_DATETIME t1, SYS_DATETIME t2);

/**
 * \brief Compares two #DATETIME variables to see if one is smaller.
 *
 * \param[in]     t1        The #DATETIME to compare against.
 * \param[in]     t1        The #DATETIME to compare with.
 *
 * \return #TRUE if t1 < t2, #FALSE otherwise.
*/ 
char SysTimeLessThan(SYS_DATETIME t1, SYS_DATETIME t2);

/**
 * \brief Adds milliseconds to a #DATETIME.
 *
 * \param[in]     t1        The #DATETIME to add to.
 * \param[in]     msec      The number of milliseconds to add.
 *
 * \return \p t1 advanced by \p msec milliseconds.
*/
SYS_DATETIME SysAddMilliseconds(SYS_DATETIME t1, int32_t msec);

/**
 * \brief Gets the current system time.
 *
 * \param[in]     utc       Currently unused.
 *
 * \return The current system time.
*/
SYS_DATETIME SysGetSystemTime(char utc);

/**
 * \brief Gets the current system time in milliseconds.
 *
 * \return The current system time in milliseconds.
*/
uint64_t SysGetSystemMillisecondCount();

/**
 * \brief Gets the current system time as a string.
 *
 * \param[out,in] s         A pointer to the string to write the time to.
 * \param[in]     format    A string describing how to format the time (via
 *                          sprintf()).
 * \param[in]     length    The length of the string.
 * \param[in]     msec      If #TRUE, get time in milliseconds.
 * \param[in]     utc       If #TRUE, get coordinated universal time.
 *
 * \return Nothing.
*/
void SysGetSystemTimeString(char * s, const char * format, int length, char msec, char utc);

/**
 * \brief Converts a #DATETIME to a string.
 *
 * \param[in]     time      The #DATETIME to convert.
 * \param[in,out] s         A pointer to the string to write the time to.
 * \param[in]     format    A string describing how to format the time (via
 *                          sprintf()).
 * \param[in]     length    The length of the string.
 * \param[in]     msec      If #TRUE, get time in milliseconds.
 * \param[in]     utc       If #TRUE, get coordinated universal time.
 *
 * \return Nothing.
*/
void SysGetTimeString(SYS_DATETIME time, char * s, const char * format, int length, char msec, char utc);
void SysSleepMsec(int milliseconds);

/**
 * \name Mutex Functions
*/
/**
 * \brief Creates a new ::SysMutex.
 *
 * \return A pointer to the newly allocated ::SysMutex.
 *
 * \note The calling function will gain ownership of the returned ::SysMutex and
 * is responsible for freeing it via SysMutex_Delete().
*/
SYS_MUTEX SysMutex_Create();

/**
 * \brief Frees all memory associated with a ::SysMutex and all of its owned
 * substructures.
 *
 * \param[in]     m      A pointer to the ::SysMutex to delete.
 *
 * \return Nothing.
*/
void SysMutex_Delete(SYS_MUTEX m);

/**
 * \brief Locks a ::SysMutex.
 *
 * \param[in]     m     A pointer to the ::SysMutex to lock.
 *
 * \return Nothing.
*/
void SysMutex_Lock(SYS_MUTEX m);

/**
 * \brief Unlocks a ::SysMutex.
 *
 * \param[in]     m     A pointer to the ::SysMutex to unlock.
 *
 * \return Nothing.
*/
void SysMutex_Unlock(SYS_MUTEX m);

/**
 * \name Sockets
*/
#define CLOSED (char)0
#define OPEN (char)1

/**
 * \brief ::twSocket base type definition.
*/
typedef struct SysSocket {
	SYS_SOCKET_TYPE sock;     /**< Socket descriptor. **/
	SYS_ADDR_INFO addr;       /**< The address to use **/
	SYS_ADDR_INFO * addrInfo; /**< #TW_ADDR_INFO struct head - use to free. **/
	char state;              /**< The current state of the ::twSocket. **/
	char * host;             /**< The host name of the server. **/
	uint16_t port;           /**< The port the server is listening on. **/
	char * proxyHost;        /**< The host name of the proxy. **/
	uint16_t proxyPort;      /**< The port of the proxy. **/
	char * proxyUser;        /**< The username to use to authenticate with the proxy. **/
	char * proxyPass;        /**< The password to use to authenticate with the proxy. **/
} SysSocket;

#ifndef MSG_NOSIGNAL
/**
 * \brief MSG_NOSIGNAL is not defined on some implementations.
*/
#define MSG_NOSIGNAL 0
#endif

#ifdef SYS_SOCKET
/**
 * \brief Creates a new ::twSocket.
 *
 * \param[in]     host      The host name of the server.
 * \param[in]     port      The port the server is listening on.
 * \param[in]     options   Currently unused.
 *
 * \return A pointer to the newly allocated ::twSocket.
 *
 * \note The calling function will gain ownership of the returned ::twSocket
 * and is responsible for freeing it via twSocket_Delete().
*/
SysSocket * SysSocket_Create(const char * host, int16_t port, uint32_t options);

/**
 * \brief Connects a ::twSocket.
 *
 * \param[in]     s         A pointer to the ::twSocket to connect.
 *
 * \return Upon successful completion, a value of 0 is returned.  Otherwise, a
 * value of -1 is returned.
*/ 
int SysSocket_Connect(SysSocket * s);

/**
 * \brief Reconnects a ::twSocket.
 *
 * \param[in]     s         A pointer to the ::twSocket to reconnect.
 *
 * \return Upon successful completion, a value of 0 is returned.  Otherwise, a
 * value of -1 is returned.
*/
int SysSocket_Reconnect(SysSocket * s);

/**
 * \brief Closes a ::twSocket.
 *
 * \param[in]     s         A pointer to the ::twSocket to close.
 *
 * \return Upon successful completion, a value of 0 is returned.  Otherwise, a
 * value of -1 is returned.
*/
int SysSocket_Close(SysSocket * s);

/**
 * \brief Checks to see if a ::twSocket is ready for I/O.
 *
 * \param[in]     s         A pointer to the ::twSocket to check.
 * \param[in]     timeout   The amount of time (in milliseconds) to wait.
 *
 * \return 0 if ready, 1 if not ready, -1 if an error was encountered.
*/
int SysSocket_WaitFor(SysSocket * s, int timeout);

/**
 * \brief Reads data from a ::twSocket.
 *
 * \param[in]     s         A pointer to the ::twSocket to read from.
 * \param[out]    buf       A buffer to store the read data.
 * \param[in]     len       The length of data to be read.
 * \param[in]     timeout   The amount of time (in milliseconds) to wait for
 *                          I/O.
 *
 * \return The number of bytes read or -1 if an error was encountered.
*/ 
int SysSocket_Read(SysSocket * s, char * buf, int len, int timeout);

/**
 * \brief Writes data to a ::twSocket.
 *
 * \param[in]     s         A pointer to the ::twSocket to write to.
 * \param[in]     buf       A buffer to of data to write.
 * \param[in]     len       The length of data to be written.
 * \param[in]     timeout   The amount of time (in milliseconds) to wait for
 *                          I/O.
 *
 * \return The number of bytes written or -1 if an error was encountered.
*/ 
int SysSocket_Write(SysSocket * s, char * buf, int len, int timeout);

/**
 * \brief Frees all memory associated with a ::twSocket.
 *
 * \param[in]     s         A pointer to the ::twSocket to be deleted.
 *
 * \return 0 on success, -1 if an error was encountered.
*/
int SysSocket_Delete(SysSocket * s);

/**
 * \brief Gets the errno of the last operation.
 *
 * \return The errno of the last operation.
*/
int SysSocket_GetLastError();

/* Enabling proxy support adds ~5KB to the code footprint, #define USE_NTLM_PROXY support adds another ~40KB */
#ifdef ENABLE_HTTP_PROXY_SUPPORT
/**
 * \brief Sets the proxy information of a ::twSocket.
 *
 * \param[in]     s         A pointer to the ::twSocket to be modified.
 * \param[in]     proxyHost The host name of the proxy server.
 * \param[in]     proxyPort The port the proxy server is listening on.
 * \param[in]     proxyUser The user name used to authenticate with the proxy.
 * \param[in]     proxyPass The password used to authenticate with the proxy.
 *
 * \return 0 if successful, positive integral on error code (see twErrors.h) if
 * an error was encountered.
*/
int SysSocket_SetProxyInfo(SysSocket * s, char * proxyHost, uint16_t proxyPort, char * proxyUser, char * proxyPass);

/**
 * \brief Clears the proxy information of a ::twSocket.
 *
 * \param[in]     s         A pointer to the ::twSocket to be modified.
 *
 * \return 0 if successful, positive integral on error code (see twErrors.h) if
 * an error was encountered.
*/
int SysSocket_ClearProxyInfo(SysSocket * s);
#endif

#endif 

/**
 * \name Thread/Task Functions
*/
/**
 * \brief Starts the ::twTasker.
*/
void SysTasker_Start();
/**
 * \brief Stops the ::twTasker.
**/
void SysTasker_Stop();

/**
 * \name File Transfer Functions
*/
/**
 * \brief Gets information about a file.
 *
 * \param[in]     filename      The full path of the file or directory to get
 *                              the information of.
 * \param[out]    size          A pointer to an integer to store the size of
 *                              the file in.
 * \param[out]    lastModified  A pointer to a #DATETIME to store the date/time
 *                              of the last modification to the file in.
 * \param[out]    isDirectory   A pointer to a char to store #TRUE if the file
 *                              is a directory or #FALSE if it isn't.
 * \param[out]    isReadOnly    A pointer to a char to store #TRUE if the file
 *                              is read-only or #FALSE if it isn't.
 *
 * \return 0 on success or an appropriate errno if an error was encountered.
 *
 * \note The calling function will retain ownership of all pointers passed to
 * twDirectory_GetFileInfo().
*/
int SysDirectory_GetFileInfo(char * filename, uint64_t * size, SYS_DATETIME * lastModified, char * isDirectory, char * isReadOnly);

/**
 * \brief Checks to see if a file exists.
 *
 * \param[in]     name          The full path of the file to check.
 *
 * \return #TRUE if the file exists, #FALSE otherwise.
*/
char SysDirectory_FileExists(char * name);

/**
 * \brief Creates a new file.
 *
 * \param[in]     name          The full path of the file to create.
 *
 * \return 0 on success or an appropriate errno if an error was encountered.
*/
int SysDirectory_CreateFile(char * name);

/**
 * \brief Moves an existing file.
 *
 * \param[in]     fromName      The full path of the file to move.
 * \param[in]     toName        The full path to move the file to.
 *
 * \return 0 on success or an appropriate errno if an error was encountered.
*/
int SysDirectory_MoveFile(char * fromName, char * toName);

/**
 * \brief Deletes a file.
 *
 * \param[in]     name          The full path of the file to delete.
 *
 * \return 0 on success or an appropriate errno if an error was encountered.
*/
int SysDirectory_DeleteFile(char * name);

/**
 * \brief Creates a directory.
 *
 * \param[in]     name          The full path of the directory to create.
 *
 * \return 0 on success or an appropriate errno if an error was encountered.
*/
int SysDirectory_CreateDirectory(char * name);

/**
 * \brief Deletes a directory.
 *
 * \param[in]     name          The full path of the directory to delete.
 *
 * \return 0 on success or an appropriate errno if an error was encountered.
*/
int SysDirectory_DeleteDirectory(char * name);

/**
 * \param[in]     dirName       The full path of the directory to iterate
 *                              through.
 * \param[out]    dir           A handle for the directory.
 * \param[out]    name          A pointer to a string to store the name of the
 *                              current entry in.
 * \param[out]    size          A pointer to an integer to store the size of
 *                              the current entry in.
 * \param[out]    lastModified  A pointer to a #DATETIME to store the date/time
 *                              of the last modification to the current entry in.
 * \param[out]    isDirectory   A pointer to a char to store #TRUE if the
 *                              current entry is a directory or #FALSE if it isn't.
 * \param[out]    isReadOnly    A pointer to a char to store #TRUE if the
 *                              current entry is read-only or #FALSE if it isn't.
 *
 * \return A handle to the directory or 0 if either there are no more entries
 * in the directory or an error was encountered.
 *
 * \note If twDirectory_IterateEntries() is called on \p dirName for the first
 * time, the function will open the directory and return a handle to the opened
 * directory.  If there are no more entries in the directory the directory will
 * be closed and the function will return 0.
 * \note The calling function will retain ownership of all pointers passed to
 * twDirectory_IterateEntries().
*/
SYS_DIR twDirectory_IterateEntries(char * dirName, SYS_DIR dir, char ** name, uint64_t * size, 
	SYS_DATETIME * lastModified, char * isDirectory, char * isReadOnly);

/**
 * \brief Gets the errno of the last operation.
 *
 * \return The errno of the last operation.
*/
int SysDirectory_GetLastError();


#ifdef __cplusplus
}
#endif

#endif

