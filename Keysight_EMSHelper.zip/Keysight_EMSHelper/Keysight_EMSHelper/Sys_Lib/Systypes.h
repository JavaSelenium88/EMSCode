/* 
 * System types include file
 *
 */

#ifndef __SYS_TYPES_H__
#define __SYS_TYPES_H__

#include <stdio.h>
#include <sys/stat.h>

/*----------------------------------------------------------------------------
 * Basic data types
 */

/* Data types which does not change across platforms. */
typedef char               Sys_Char;        /**< Same as char type. */
typedef unsigned char      Sys_Byte;        /**< Unsigned 8-bit Integer. */
typedef int                Sys_Int;         /**< Same as int type. */
typedef long               Sys_Long;        /**< Same as long type. */
typedef unsigned int       Sys_Uint;        /**< Same as unsigned int type. */
typedef unsigned long      Sys_Ulong;       /**< Same as unsigned long type. */
typedef unsigned long long Sys_Ullong;		/**< Same as unsigned long long type */
typedef float              Sys_Float;       /**< Single precession data type. */
typedef double             Sys_Double;      /**< Double precession data type. */
typedef int                Sys_Bool;        /**< Boolean type. */
typedef time_t			   Sys_time_t;		/**< Same as time_t type. */
#define SYS_FALSE          ((Sys_Bool) 0)   /**< Boolean false. */
#define SYS_TRUE           ((Sys_Bool) 1)   /**< Boolean true. */

typedef size_t             Sys_Size_t;      /**< Size type. */

/** 
 * Enumeration of various return and cause values used by the system API.
 */
typedef enum Sys_RetTag
{
	SYS_RET_OK         =  0,  /**< Successful. */
	SYS_EINIT          = -1,  /**< Not initialized yet. */
	SYS_EPERM          = -2,  /**< Not permitted. */
	SYS_EIO            = -3,  /**< Hardware error. */
	SYS_EUNKNOWN       = -4,  /**< Unknown error. */
	SYS_EINVAL         = -5,  /**< Invalid argument. */
	SYS_ECONFIG        = -6,  /**< Invalid configuration. */
	SYS_EUNSUPPORTED   = -7,  /**< Unsupported feature. */
	SYS_ENOMEM         = -8,  /**< Out of memory. */
	SYS_ERESOURCE      = -9,  /**< Resource shortage. */
	SYS_ETIMEOUT       = -10, /**< Operation timed out. */
	SYS_EUSERABORT     = -11, /**< User aborted the operation. */
	SYS_EWOULDBLOCK    = -12, /**< Operation would block. */
	SYS_EIOPENDING     = -13, /**< IO Operation is pending. */
	SYS_EINTR          = -14, /**< Operation interrupted. */
	SYS_ENETDOWN       = -15, /**< Network is down. */
	SYS_EADDRINUSE     = -16, /**< Address is in use. */
	SYS_EACCESS        = -17, /**< Access violation. */
	SYS_EBADH          = -18, /**< Not a handle. */
	SYS_EINPROGRESS    = -19, /**< Operation now in progress. */
	SYS_ENOTCONN       = -20, /**< Not yet connected. */
	SYS_ECONNRESET     = -21, /**< Connection has been reset. */
	SYS_EALREADY       = -22, /**< Already present or already in progress. */
	SYS_EISCONN        = -23, /**< Endpoint is already connected. */
	SYS_EADDRNOTAVAIL  = -24, /**< Address not available. */
	SYS_ECONNREFUSED   = -25, /**< Connection has been refused. */
	SYS_ENETUNREACH    = -26, /**< Network not reachable. */
	SYS_EMSGSIZE       = -27, /**< Buffer size is insufficient. */
	SYS_ENOTAVAIL      = -28, /**< Requested data not available. */
	SYS_EBUSY          = -29, /**< Device or resource busy. */
	SYS_EINCOMPLETE    = -30, /**< Information is partial. */
	SYS_EPROTOERR      = -31, /**< Protocol error. */
	SYS_EINVSTATE      = -32, /**< Invalid state error. */
	SYS_ERACE          = -33, /**< Race condition. This may not be an error. */
	SYS_ENOSERVICE     = -34, /**< Requested service is not available. */
	SYS_ERETRYLATER    = -35, /**< Retry at some later time. */
	SYS_ENOSYS         = -36  /**< Not implemented feature. */
}
Sys_Ret_t;

#define SYS_OK 0

/**
* \name General Errors 1xx
*/
#define SYS_UNKNOWN_ERROR 100           /**< Unknown error **/
#define SYS_INVALID_PARAM 101           /**< Invalid parameter **/
#define SYS_ERROR_ALLOCATING_MEMORY 102 /**< Error allocating memory **/
#define SYS_ERROR_CREATING_MTX 103      /**< Error creating mutex **/
#define SYS_ERROR_WRITING_FILE 104
#define SYS_ERROR_READING_FILE 105

#define SYS_LIST_ENTRY_NOT_FOUND 500

#endif /* __SYS_TYPES_H__ */
