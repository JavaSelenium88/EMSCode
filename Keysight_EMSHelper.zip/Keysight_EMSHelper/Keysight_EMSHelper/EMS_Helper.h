//*****************************************************************************
//
//  Copyright � 2018 ITC.  All rights reserved.
//
//*****************************************************************************
//
//  Filename   :  EMS_Helper.h
//  
//  Subsystem  :  Keysight_EMSHelper
//
//  Description:  Declaration of KeyboardProc,MouseEvent etc.
//
//*****************************************************************************

#ifndef _EMS_HELPER_H
#define _EMS_HELPER_H

#include "Sysapi.h"
#include "Systypes.h"
#include "SysLog.h"

//#define TIMESTMAMP_LENGTH 80
#define DEFAULT_BUFLEN 512
#define MAX_DAYS_IN_MSEC 4285440,000  /**< 49.6 days in milisecond */
#define MAX_CLIENT 30 /**max client number that can connect, fixing AA-1792 */

time_t lastTickTime = 0; /**< storing previous tick values*/
Sys_Char prevTime[DEFAULT_BUFLEN]; /**< storing last input time stamp */


//Sys_Char keyhook[DEFAULT_BUFLEN];
//Sys_Char mousehook[DEFAULT_BUFLEN];

//#ifdef WIN32
//HHOOK hKeyboardHook;
//HHOOK hMouseHook;
//#endif /**WIN32**/


typedef enum Hook_Error_Codes_T {
	HOOK_SUCCESS = 0,/**< No error */
	HOOK_ARGUMENT_ERROR = 1, /**< cmd line arguments error*/
	//HOOK_KEY_ERROR = -1, /**< Failure in installing key hook */
	//HOOK_MOUSE_ERROR = -2, /**< Failure in installing mouse hook */
	KEYHOOK_SYS_LOG_FAILURE = -3, /**< Failure in intializing sys logs */
	KEYHOOK_INSUFFICIENT_MEMORY = -4, /**< Memory Allocation failed */
	KEYHOOK_TIMESTAMP_ERROR = -5,
}HookErrCodes;

typedef enum Socket_Error_Codes_T {
	SOCKET_SUCCESS = 0,
	SOCKET_STARTUP_ERROR = 1,
	SOCKET_LISTEN_ERROR = 2,
	SOCKET_ADDR_ERROR = 3,
	SOCKET_CREATE_ERROR = 4,
	SOCKET_BIND_ERROR = 5,
	SOCKET_ACCEPT_ERROR = 6,
	SOCKET_SEND_ERROR = 7,
	SOCKET_RECV_ERROR = 8,
	SOCKET_SELECT_ERROR = 9,
	
}SocketErrCodes;

typedef enum LastInput_Error_Codes_T {

	LASTINPUT_SUCCESS = 0,
	LASTINPUT_FAILED = -1,
	

}LastInputCodes;

#ifdef WIN32
//LRESULT CALLBACK KeyboardProc(Sys_Int nCode,WPARAM wParam,LPARAM lParam);
//LRESULT CALLBACK MouseEvent(Sys_Int nCode, WPARAM wParam, LPARAM lParam);

//HookErrCodes CreateKMhook();
//HookErrCodes DestroyKMhook();

Sys_Int SocketInit(Sys_Char *port);

LastInputCodes GetLastinputTimeUTC(Sys_Char *timebuf); /**< To get the last input time in UTC */

void  IntHandler(Sys_Int sig); /**< Signal Handler */



#endif

#endif // _EMS_HELPER_H_

