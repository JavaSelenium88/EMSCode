/*****************************************************************************
//
//  Copyright � 2018 ITC .  All rights reserved.
//
******************************************************************************
//
//  Filename   :  kmHook.c
//
//  Subsystem  :  Keysight_EMSHelper
//
//  Description: Definition for KeyboardProc, MouseEvent and DestroyKMhook function
//
******************************************************************************/

#undef UNICODE
#define UNICODE
#undef _WINSOCKAPI_
#define _WINSOCKAPI_

#include <windows.h>
#include <tchar.h>
#include <strsafe.h>
#include "kmHook.h"


LRESULT CALLBACK KeyboardProc(Sys_Int nCode, WPARAM wParam, LPARAM lParam)
{
	Sys_Char *function = "CALLBACK KeyboardProc()";
	Sys_Ret_t sysRet = SYS_RET_OK;
	LRESULT RetVal;
	Sys_Char *pTmpArrKeyboard = NULL; /*for storing keyboard timestamp */

	if ((nCode == HC_ACTION) && ((wParam == WM_SYSKEYDOWN) || (wParam == WM_KEYDOWN)))
	{
		pTmpArrKeyboard = (Sys_Char *)Sys_Calloc(TIMESTMAMP_LENGTH);
		Sys_StringnCpy(pTmpArrKeyboard, "yyyy-mm-dd hh-mm-ss  ", (TIMESTMAMP_LENGTH - 1), TIMESTMAMP_LENGTH);
		sysRet = Sys_GetTimeStamp(pTmpArrKeyboard, "%Y-%m-%d %H:%M:%S", 80, 0, 0);
		memset(&keyhook, '\0', DEFAULT_BUFLEN);
		strcpy(keyhook, pTmpArrKeyboard);
		if (sysRet != SYS_RET_OK) {
			SysAppLog(SYS_ERROR, MODULE_KEYHOOKS, "%s: failed to retrieve timestamp!", function);
		}
		//Uncomment below part of the code for printing every Keyboard timestamp
		/*else {
			SysAppLog(SYS_INFO, MODULE_KEYHOOKS, "%s: SysTime- %s", function, pTmpArrKeyboard);
		}*/
	}
	if (pTmpArrKeyboard) {
		Sys_Free(pTmpArrKeyboard);
		pTmpArrKeyboard = NULL;
	}
	
	RetVal = CallNextHookEx(hKeyboardHook, nCode, wParam, lParam);

	return  RetVal;
}


LRESULT CALLBACK MouseEvent(Sys_Int nCode, WPARAM wParam, LPARAM lParam)
{
	Sys_Char *function = "CALLBACK MouseEvent()";
	Sys_Ret_t sysRet = SYS_RET_OK;
	Sys_Char *pTmpArrMouse = NULL; /*for storing mouse timestamp */
	LRESULT RetVal;
	FILE*  fileHandle = NULL;
	
	if ((nCode == HC_ACTION) &&
		((wParam == WM_LBUTTONDOWN) ||
		(wParam == WM_MBUTTONDOWN) ||
			(wParam == WM_RBUTTONDOWN)))
	{
		pTmpArrMouse = (Sys_Char *)Sys_Calloc(TIMESTMAMP_LENGTH);
		Sys_StringnCpy(pTmpArrMouse, "yyyy-mm-dd hh-mm-ss  ", (TIMESTMAMP_LENGTH - 1), TIMESTMAMP_LENGTH);
		sysRet = Sys_GetTimeStamp(pTmpArrMouse, "%Y-%m-%d %H:%M:%S", 80, 0, 0);
	
		memset(&mousehook, '\0', DEFAULT_BUFLEN);
		strcpy(mousehook, pTmpArrMouse);
		if (sysRet != SYS_RET_OK) {
			SysAppLog(SYS_ERROR, MODULE_KEYHOOKS, "%s: failed to retrieve timestamp!", function);
		}
		//Uncomment below part of the code for printing every Mouse timestamp
		/*else {
			SysAppLog(SYS_INFO, MODULE_KEYHOOKS, "%s: SysTime- %s", function, pTmpArrMouse);
		}*/
	}
	if (pTmpArrMouse) {
		Sys_Free(pTmpArrMouse);
		pTmpArrMouse = NULL;
	}

	RetVal = CallNextHookEx(hMouseHook, nCode, wParam, lParam);
	return  RetVal;
}


HookErrCodes DestroyKMhook()
{
	HookErrCodes retVal = HOOK_SUCCESS;
	Sys_Char *function = "DestroyKMhook()";

	SysAppLog(SYS_INFO, MODULE_KEYHOOKS, "%s: Entered", function);

	if (hKeyboardHook)
		UnhookWindowsHookEx(hKeyboardHook);

	if (hMouseHook)
		UnhookWindowsHookEx(hMouseHook);

	SysAppLog(SYS_INFO, MODULE_KEYHOOKS, "%s: Exited", function);
	return retVal;
}
